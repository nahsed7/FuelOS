#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
if [ -f data/fuelos-live.pid ] && kill "$(cat data/fuelos-live.pid)" 2>/dev/null; then
    rm -f data/fuelos-live.pid
    echo "FuelOS Live stopped."
else
    echo "No FuelOS Live PID file found. Stop the foreground process with Ctrl+C."
fi
