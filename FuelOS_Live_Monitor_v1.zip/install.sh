#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PY=$(command -v python3 || command -v python || true)
[ -z "$PY" ] && { echo "Python 3 not found (Termux: pkg install python)"; exit 1; }
"$PY" -c 'import sys; sys.exit(sys.version_info<(3,9))' || { echo "Python >= 3.9 required"; exit 1; }
[ -d .venv ] || "$PY" -m venv .venv
. .venv/bin/activate
pip install --upgrade pip >/dev/null
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
mkdir -p data
python -m app.database
echo "Install complete. Run: ./run.sh"
