"""API + WebSocket tests (need fastapi, httpx installed; skipped otherwise)."""
import unittest

try:
    from fastapi.testclient import TestClient
    from app.main import create_app
    HAVE = True
except Exception:  # pragma: no cover
    HAVE = False


@unittest.skipUnless(HAVE, "fastapi/httpx not installed")
class ApiTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app(":memory:", run_loop=False)
        self.cm = TestClient(self.app)
        self.c = self.cm.__enter__()
        self.sim = self.app.state.sim
        self.app.state.db.execute("INSERT OR REPLACE INTO station_settings VALUES('sim_speed','1')")
        self.app.state.db.commit()

    def tearDown(self):
        self.cm.__exit__(None, None, None)

    def test_dashboard_and_state(self):
        self.assertEqual(self.c.get("/").status_code, 200)
        s = self.c.get("/api/state").json()
        self.assertTrue(s["simulated"])
        self.assertEqual(len(s["pumps"]), 4)

    def test_pos_flow_receipt_and_pdf(self):
        r = self.c.post("/api/transactions", json={"pump_id": 1, "grade": "LP92", "vehicle_reg": "cab-1234", "preset_litres": 10})
        self.assertEqual(r.status_code, 200, r.text)
        tid = r.json()["id"]
        for _ in range(40):
            self.sim.tick(1)
        t = self.c.get(f"/api/transactions/{tid}").json()
        self.assertEqual((t["status"], t["amount_minor"]), ("RECEIPT_GENERATED", 309000))
        self.assertIn("SIMULATED", self.c.get(f"/receipts/{t['receipt_no']}").text)
        self.assertEqual(self.c.get(f"/api/receipts/{t['receipt_no']}/pdf").content[:4], b"%PDF")

    def test_errors(self):
        self.assertEqual(self.c.post("/api/transactions", json={"pump_id": 99, "grade": "LP92"}).status_code, 404)
        self.assertEqual(self.c.post("/api/vehicles", json={"reg": "CAB-1234"}).status_code, 409)

    def test_websocket_delivery_and_reconnect_recovery(self):
        with self.c.websocket_connect("/ws?since=0") as ws:
            while ws.receive_json()["kind"] != "hello":
                pass
            self.sim.authorize(1, "LP92", preset_ml=3000)
            self.sim.tick(1)
            got = []
            while len(got) < 3:
                m = ws.receive_json()
                if m["kind"] == "event":
                    got.append(m["event"])
        seqs = [e["seq"] for e in got]
        self.assertEqual(seqs, sorted(set(seqs)))
        last = seqs[0]
        with self.c.websocket_connect(f"/ws?since={last}") as ws2:  # reconnect: missed events replayed
            replay = []
            while True:
                m = ws2.receive_json()
                if m["kind"] == "hello":
                    break
                replay.append(m["event"]["seq"])
        self.assertEqual(replay[0], last + 1)
        self.assertEqual(len(replay), len(set(replay)))

    def test_concurrent_pumps_via_api(self):
        ids = [self.c.post("/api/transactions", json={"pump_id": p, "grade": g, "preset_litres": 5}).json()["id"]
               for p, g in [(1, "LP92"), (2, "AD"), (3, "SD"), (4, "LP95")]]
        for _ in range(30):
            self.sim.tick(1)
        done = [self.c.get(f"/api/transactions/{i}").json()["status"] for i in ids]
        self.assertEqual(set(done), {"RECEIPT_GENERATED"})
        self.assertTrue(self.c.post("/api/reconcile").json()["consistent"])


if __name__ == "__main__":
    unittest.main()
