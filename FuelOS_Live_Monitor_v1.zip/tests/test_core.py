import unittest

from app.database import connect, init_db, money, seed_demo, set_setting
from app.events import EventBus
from app.services import receipts as rc, reports
from app.simulator import SimError, SimulatedDataSource


def make(seed=1):
    db = connect(":memory:")
    init_db(db)
    seed_demo(db)
    set_setting(db, "sim_speed", "1")
    bus = EventBus(db, SimulatedDataSource.source_id)
    sim = SimulatedDataSource(db, bus, seed=seed)
    sim.start()
    return db, bus, sim


def run(sim, secs=120, step=0.5):
    for _ in range(int(secs / step)):
        sim.tick(step)


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.db, self.bus, self.sim = make()

    def stock(self, code):
        return self.db.execute("SELECT stock_ml FROM tanks t JOIN fuel_grades g ON g.id=t.grade_id WHERE g.code=?", (code,)).fetchone()[0]

    def test_create_pump(self):
        r = self.sim.create_pump(["LP92", "SD"], speed_lpm=30)
        self.assertEqual(r["number"], 5)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM nozzles WHERE pump_id=?", (r["id"],)).fetchone()[0], 2)
        with self.assertRaises(SimError):
            self.sim.create_pump(["NOPE"])

    def test_create_and_edit_vehicle(self):
        vid = reports.add_vehicle(self.db, "abc-1", "Van", "ACME")
        reports.update_vehicle(self.db, vid, "ABC-1", "Truck", "ACME")
        self.assertEqual(reports.vehicle_report(self.db, vid)["vehicle"]["category"], "Truck")
        with self.assertRaises(SimError):
            reports.add_vehicle(self.db, "ABC-1")

    def test_full_lifecycle_totals_inventory_receipt(self):
        before = self.stock("LP92")
        t = self.sim.authorize(1, "LP92", "cab-1234", "WALK_IN", "OP-01", "CASH", preset_ml=10000)
        self.assertEqual(t["status"], "DISPENSING")
        self.sim.tick(5)  # 5s * 667 ml/s = 3335 ml
        mid = self.sim.get_txn(t["id"])
        self.assertEqual(mid["volume_ml"], 3335)
        self.assertEqual(mid["amount_minor"], money(3335, 30900))
        run(self.sim, 30)
        done = self.sim.get_txn(t["id"])
        self.assertEqual(done["status"], "RECEIPT_GENERATED")
        self.assertEqual(done["volume_ml"], 10000)
        self.assertEqual(done["amount_minor"], 309000)  # 10 L x 309.00 exactly
        self.assertEqual(before - self.stock("LP92"), 10000)
        d = rc.receipt_data(self.db, done["receipt_no"])
        html = rc.render_html(d)
        self.assertIn("SIMULATED TEST RECEIPT", html)
        self.assertIn("3,090.00", html)
        self.assertTrue(rc.render_pdf(d).startswith(b"%PDF"))
        self.assertTrue(self.sim.reconcile()["consistent"])

    def test_cancel_does_not_charge_or_deduct(self):
        before = self.stock("AD")
        t = self.sim.authorize(1, "AD", preset_ml=20000)
        self.sim.tick(2)
        c = self.sim.cancel(t["id"])
        self.assertEqual((c["status"], c["amount_minor"]), ("CANCELLED", 0))
        self.assertEqual(self.stock("AD"), before)
        self.assertEqual(self.db.execute("SELECT status FROM pumps WHERE id=1").fetchone()[0], "IDLE")
        with self.assertRaises(SimError):
            self.sim.cancel(t["id"])
        self.assertEqual(reports.analytics(self.db)["cancellations"]["cancelled"], 1)

    def test_pump_busy_and_bad_input(self):
        self.sim.authorize(1, "LP92", preset_ml=5000)
        with self.assertRaises(SimError):
            self.sim.authorize(1, "AD")
        with self.assertRaises(SimError):
            self.sim.authorize(2, "SD")  # no such nozzle
        with self.assertRaises(SimError):
            self.sim.authorize(2, "AD", payment="BITCOIN")

    def test_fault_recover_reconcile(self):
        t = self.sim.authorize(3, "LP95", preset_ml=30000)
        self.sim.tick(5)
        vol = self.sim.get_txn(t["id"])["volume_ml"]
        self.assertGreater(vol, 0)
        self.sim.fault(3, "FAULT")
        self.assertEqual(self.sim.get_txn(t["id"])["status"], "FAULTED")
        run(self.sim, 5)
        self.assertEqual(self.sim.get_txn(t["id"])["volume_ml"], vol)  # frozen while faulted
        with self.assertRaises(SimError):
            self.sim.authorize(3, "LP95")
        self.assertEqual(self.sim.reconcile()["settled"], [])  # pump still faulted
        self.sim.recover(3)
        rep = self.sim.reconcile()
        self.assertEqual(rep["settled"][0]["result"], "RECEIPT_GENERATED")
        self.assertEqual(self.sim.get_txn(t["id"])["volume_ml"], vol)
        self.assertTrue(rep["consistent"])

    def test_comm_loss_with_no_volume_cancels(self):
        t = self.sim.authorize(2, "AD")
        self.sim.fault(2, "COMMUNICATION_LOSS")
        self.assertEqual(self.db.execute("SELECT status FROM pumps WHERE id=2").fetchone()[0], "OFFLINE")
        self.sim.recover(2)
        self.sim.reconcile()
        self.assertEqual(self.sim.get_txn(t["id"])["status"], "CANCELLED")

    def test_concurrent_pumps_unique_ids_and_receipts(self):
        ids = [self.sim.authorize(p, g, preset_ml=15000 + p * 1000)["id"]
               for p, g in [(1, "LP92"), (2, "LP92"), (3, "LP95"), (4, "LP95")]]
        self.assertEqual(len(set(ids)), 4)
        run(self.sim, 60)
        rows = [self.sim.get_txn(i) for i in ids]
        self.assertTrue(all(r["status"] == "RECEIPT_GENERATED" for r in rows))
        self.assertEqual(len({r["receipt_no"] for r in rows}), 4)
        self.assertEqual(sum(r["amount_minor"] for r in rows), self.sim.state()["stats"]["amount_minor"])
        self.assertTrue(self.sim.reconcile()["consistent"])

    def test_stock_reservation_prevents_overselling(self):
        self.db.execute("UPDATE tanks SET stock_ml=50000 WHERE tank_code='TK-1'")
        self.db.execute("DELETE FROM inventory_movements WHERE tank_id=1")
        self.db.execute("INSERT INTO inventory_movements(tank_id,kind,delta_ml,balance_ml,ts) VALUES(1,'OPENING',50000,50000,'x')")
        self.db.commit()
        self.sim.authorize(1, "LP92")  # reserves up to 50 L (pump max 60 L)
        with self.assertRaises(SimError):
            self.sim.authorize(2, "LP92")

    def test_replenish_and_low_stock_event(self):
        self.db.execute("UPDATE tanks SET stock_ml=2100000, capacity_ml=20000000 WHERE tank_code='TK-1'")
        self.db.execute("UPDATE inventory_movements SET delta_ml=2100000, balance_ml=2100000 WHERE tank_id=1")
        self.db.commit()
        self.assertEqual(self.sim.replenish(1, 1000000)["stock_ml"], 3100000)
        with self.assertRaises(SimError):
            self.sim.replenish(1, 99999999)

    def test_events_ordered_unique_and_replayable(self):
        self.sim.authorize(1, "LP92", preset_ml=5000)
        run(self.sim, 30)
        ev = self.bus.history(0, 10000)
        seqs = [e["seq"] for e in ev]
        self.assertEqual(seqs, sorted(seqs))
        self.assertEqual(len({e["event_id"] for e in ev}), len(ev))
        for k in ("event_id", "type", "pump_id", "transaction_id", "ts", "source", "payload", "seq"):
            self.assertIn(k, ev[0])
        types = {e["type"] for e in ev}
        for t in ("TRANSACTION_AUTHORIZED", "DISPENSING_STARTED", "DISPENSING_PROGRESS", "DISPENSING_COMPLETED",
                  "RECEIPT_GENERATED", "INVENTORY_UPDATED", "PUMP_IDLE"):
            self.assertIn(t, types)
        mid = seqs[len(seqs) // 2]
        self.assertEqual([e["seq"] for e in self.bus.history(mid)], [s for s in seqs if s > mid])  # reconnect recovery

    def test_auto_mode_reproducible_with_seed(self):
        def trace(seed):
            db, bus, sim = make(seed)
            set_setting(db, "sim_mode", "auto")
            set_setting(db, "arrival_interval_s", "3")
            set_setting(db, "fault_rate", "0.01")
            run(sim, 300)
            return [(e["type"], e["pump_id"], e["payload"].get("grade"), e["payload"].get("vehicle"))
                    for e in bus.history(0, 100000) if e["type"] in ("TRANSACTION_AUTHORIZED", "PUMP_FAULT")]
        a, b = trace(42), trace(42)
        self.assertGreater(len(a), 5)
        self.assertEqual(a, b)

    def test_auto_mode_many_concurrent_stays_consistent(self):
        set_setting(self.db, "sim_mode", "auto")
        set_setting(self.db, "arrival_interval_s", "1")
        set_setting(self.db, "max_concurrent", "4")
        set_setting(self.db, "fault_rate", "0.02")
        run(self.sim, 600)
        ids = [r[0] for r in self.db.execute("SELECT id FROM transactions")]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertGreater(len(ids), 20)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM receipts").fetchone()[0],
                         self.db.execute("SELECT COUNT(*) FROM transactions WHERE status='RECEIPT_GENERATED'").fetchone()[0])
        self.assertTrue(self.sim.reconcile()["consistent"])

    def test_money_is_integer_exact(self):
        self.assertEqual(money(333, 30900), 10290)   # 0.333 L * 309.00 = 102.897 -> 102.90
        self.assertIsInstance(money(1, 1), int)
        total = sum(money(1000, 30900) for _ in range(1000))
        self.assertEqual(total, 30900 * 1000)

    def test_restart_marks_orphans_faulted(self):
        t = self.sim.authorize(1, "LP92", preset_ml=20000)
        self.sim.tick(3)
        sim2 = SimulatedDataSource(self.db, EventBus(self.db, "SIMULATOR-1"), seed=1)
        sim2.start()
        self.assertEqual(sim2.get_txn(t["id"])["status"], "FAULTED")
        self.assertEqual(sim2.reconcile()["settled"][0]["result"], "RECEIPT_GENERATED")

    def test_readonly_placeholder_not_implemented(self):
        from app.simulator import FutureReadOnlyStationDataSource
        with self.assertRaises(NotImplementedError):
            FutureReadOnlyStationDataSource().start()


if __name__ == "__main__":
    unittest.main()
