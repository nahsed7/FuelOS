"""FuelOS live-only application. No simulator, seed data, or generated readings."""
import asyncio
import json
import logging
import os
import sqlite3
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse
from starlette.routing import Route, WebSocketRoute, Mount
from starlette.staticfiles import StaticFiles
from starlette.websockets import WebSocket, WebSocketDisconnect

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DB_PATH = Path(os.getenv("FUELOS_LIVE_DB", DATA / "fuelos_live.db"))
UI = ROOT / "app" / "live"
STALE_AFTER = float(os.getenv("FUELOS_STALE_SECONDS", "10"))

MQTT_HOST = os.getenv("FUELOS_MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("FUELOS_MQTT_PORT", "1883"))
MQTT_USER = os.getenv("FUELOS_MQTT_USERNAME", "")
MQTT_PASS = os.getenv("FUELOS_MQTT_PASSWORD", "")
MQTT_CLIENT_ID = os.getenv("FUELOS_MQTT_CLIENT_ID", "fuelos-live-monitor")
MQTT_TLS = os.getenv("FUELOS_MQTT_TLS", "false").lower() == "true"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("fuelos.live")

lock = threading.RLock()
db = None
mqtt_client = None
mqtt_connected = False
mqtt_last_error = None
started_at = time.time()
loop_ref = None
ws_clients = set()


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def connect_db():
    global db
    DATA.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL UNIQUE,
        station_id TEXT,
        source_id TEXT,
        event_type TEXT NOT NULL,
        dispenser_id TEXT,
        transaction_id TEXT,
        event_timestamp TEXT,
        received_utc TEXT NOT NULL,
        sequence INTEGER,
        topic TEXT NOT NULL,
        payload TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_events_received ON events(received_utc);
    CREATE TABLE IF NOT EXISTS dispensers (
        station_id TEXT NOT NULL,
        dispenser_id TEXT NOT NULL,
        source_id TEXT,
        status TEXT,
        nozzle_id TEXT,
        transaction_id TEXT,
        litres REAL,
        amount REAL,
        grade TEXT,
        event_timestamp TEXT,
        received_utc TEXT NOT NULL,
        sequence INTEGER,
        payload TEXT NOT NULL,
        PRIMARY KEY(station_id, dispenser_id)
    );
    CREATE TABLE IF NOT EXISTS transactions (
        transaction_id TEXT PRIMARY KEY,
        station_id TEXT,
        dispenser_id TEXT,
        nozzle_id TEXT,
        grade TEXT,
        litres REAL,
        amount REAL,
        completed_timestamp TEXT,
        received_utc TEXT NOT NULL,
        payload TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sources (
        source_id TEXT PRIMARY KEY,
        station_id TEXT,
        connected_seen_utc TEXT,
        last_message_utc TEXT,
        last_error TEXT
    );
    """)
    db.commit()


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def age_seconds(value):
    dt = parse_time(value)
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())


def broadcast(message):
    if loop_ref is None or not ws_clients:
        return
    async def send_all():
        dead = []
        for ws in list(ws_clients):
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            ws_clients.discard(ws)
    try:
        asyncio.run_coroutine_threadsafe(send_all(), loop_ref)
    except RuntimeError:
        pass


def handle_message(client, userdata, msg):
    global mqtt_last_error
    received = utcnow()
    try:
        envelope = json.loads(msg.payload.decode("utf-8"))
        required = ("schema_version", "station_id", "source_id", "event_id",
                    "event_type", "timestamp", "payload")
        missing = [key for key in required if key not in envelope]
        if missing:
            raise ValueError("Missing fields: " + ", ".join(missing))
        if str(envelope["schema_version"]) != "1.0":
            raise ValueError("Unsupported schema_version")
        if not isinstance(envelope["payload"], dict):
            raise ValueError("payload must be a JSON object")

        station = str(envelope["station_id"])
        source = str(envelope["source_id"])
        event_id = str(envelope["event_id"])
        event_type = str(envelope["event_type"])
        dispenser = envelope.get("dispenser_id")
        txn = envelope.get("transaction_id")
        payload = envelope["payload"]
        seq = envelope.get("sequence")
        stamp = str(envelope["timestamp"])

        with lock, db:
            cur = db.execute("""
                INSERT OR IGNORE INTO events
                (event_id,station_id,source_id,event_type,dispenser_id,transaction_id,
                 event_timestamp,received_utc,sequence,topic,payload)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """, (event_id, station, source, event_type, dispenser, txn,
                  stamp, received, seq, msg.topic, json.dumps(envelope)))
            if cur.rowcount == 0:
                return

            db.execute("""
                INSERT INTO sources(source_id,station_id,connected_seen_utc,last_message_utc,last_error)
                VALUES(?,?,?,?,NULL)
                ON CONFLICT(source_id) DO UPDATE SET
                station_id=excluded.station_id,
                last_message_utc=excluded.last_message_utc,
                last_error=NULL
            """, (source, station, received, received))

            if dispenser and event_type in (
                "telemetry", "dispensing_started", "dispensing_progress",
                "dispensing_completed", "fault", "recovered"
            ):
                db.execute("""
                    INSERT INTO dispensers
                    (station_id,dispenser_id,source_id,status,nozzle_id,transaction_id,
                     litres,amount,grade,event_timestamp,received_utc,sequence,payload)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(station_id,dispenser_id) DO UPDATE SET
                    source_id=excluded.source_id,status=excluded.status,
                    nozzle_id=excluded.nozzle_id,transaction_id=excluded.transaction_id,
                    litres=excluded.litres,amount=excluded.amount,grade=excluded.grade,
                    event_timestamp=excluded.event_timestamp,received_utc=excluded.received_utc,
                    sequence=excluded.sequence,payload=excluded.payload
                """, (
                    station, dispenser, source, payload.get("status", event_type),
                    envelope.get("nozzle_id"), txn, payload.get("litres"),
                    payload.get("amount"), payload.get("grade"), stamp, received,
                    seq, json.dumps(payload)
                ))

            if event_type in ("transaction_completed", "dispensing_completed") and txn:
                db.execute("""
                    INSERT INTO transactions
                    (transaction_id,station_id,dispenser_id,nozzle_id,grade,litres,
                     amount,completed_timestamp,received_utc,payload)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(transaction_id) DO NOTHING
                """, (
                    txn, station, dispenser, envelope.get("nozzle_id"),
                    payload.get("grade"), payload.get("litres"),
                    payload.get("amount"), stamp, received, json.dumps(payload)
                ))

        mqtt_last_error = None
        broadcast({"type": "new_message", "event_id": event_id})
    except Exception as exc:
        mqtt_last_error = str(exc)
        log.warning("Rejected MQTT message on %s: %s", msg.topic, exc)


def on_connect(client, userdata, flags, reason_code, properties):
    global mqtt_connected, mqtt_last_error
    mqtt_connected = (int(getattr(reason_code, "value", reason_code)) == 0)
    if mqtt_connected:
        mqtt_last_error = None
        for topic in (
            "station/+/dispenser/+/telemetry",
            "station/+/dispenser/+/events",
            "station/+/dispenser/+/transactions",
            "station/+/status"
        ):
            client.subscribe(topic, qos=1)
        log.info("Connected to MQTT broker %s:%s", MQTT_HOST, MQTT_PORT)
    else:
        mqtt_last_error = f"MQTT connection refused: {reason_code}"


def on_disconnect(client, userdata, disconnect_flags, reason_code, properties):
    global mqtt_connected
    mqtt_connected = False
    log.warning("MQTT disconnected: %s", reason_code)


def start_mqtt():
    global mqtt_client
    try:
        client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2,
            client_id=MQTT_CLIENT_ID,
            protocol=mqtt.MQTTv311
        )
        if MQTT_USER:
            client.username_pw_set(MQTT_USER, MQTT_PASS)
        if MQTT_TLS:
            client.tls_set()
        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = handle_message
        client.reconnect_delay_set(min_delay=1, max_delay=30)
        mqtt_client = client
        client.connect_async(MQTT_HOST, MQTT_PORT, keepalive=30)
        client.loop_start()
    except Exception as exc:
        mqtt_last_error = str(exc)
        log.exception("Could not start MQTT client")


def dashboard_data():
    now = utcnow()
    with lock:
        rows = db.execute("SELECT * FROM dispensers ORDER BY station_id,dispenser_id").fetchall()
        tx_count = db.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        event_count = db.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        latest = db.execute("SELECT MAX(received_utc) FROM events").fetchone()[0]
    dispensers = []
    for r in rows:
        age = age_seconds(r["received_utc"])
        dispensers.append({
            "station_id": r["station_id"],
            "dispenser_id": r["dispenser_id"],
            "freshness": "LIVE" if age is not None and age <= STALE_AFTER else "STALE",
            "data_age_seconds": round(age, 2) if age is not None else None,
            "payload": {
                "status": r["status"], "litres": r["litres"],
                "amount": r["amount"], "grade": r["grade"],
                "nozzle_id": r["nozzle_id"], "transaction_id": r["transaction_id"]
            },
            "event_timestamp": r["event_timestamp"],
            "received_utc": r["received_utc"]
        })
    return {
        "mode": "LIVE DATA ONLY",
        "mqtt_connected": mqtt_connected,
        "mqtt_host": MQTT_HOST,
        "mqtt_port": MQTT_PORT,
        "mqtt_error": mqtt_last_error,
        "stale_after_seconds": STALE_AFTER,
        "dispensers": dispensers,
        "dispenser_count": len(dispensers),
        "live_dispenser_count": sum(x["freshness"] == "LIVE" for x in dispensers),
        "completed_transaction_count": tx_count,
        "event_count": event_count,
        "last_message_received": latest,
        "server_utc": now,
        "uptime_seconds": round(time.time() - started_at, 1)
    }


@asynccontextmanager
async def lifespan(app):
    global loop_ref
    loop_ref = asyncio.get_running_loop()
    connect_db()
    start_mqtt()
    yield
    if mqtt_client:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()
    if db:
        db.close()



def home(request):
    return FileResponse(UI / "templates" / "dashboard.html")


def health(request):
    return JSONResponse({
        "status": "ok",
        "mode": "LIVE DATA ONLY",
        "mqtt_connected": mqtt_connected,
        "mqtt_error": mqtt_last_error,
        "database": str(DB_PATH),
        "uptime_seconds": round(time.time() - started_at, 1)
    })


def dashboard(request):
    return JSONResponse(dashboard_data())


def transactions(request):
    limit = max(1, min(int(request.query_params.get("limit", 200)), 1000))
    with lock:
        rows = db.execute(
            "SELECT * FROM transactions ORDER BY received_utc DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return JSONResponse([dict(r) for r in rows])


def events(request):
    limit = max(1, min(int(request.query_params.get("limit", 200)), 1000))
    with lock:
        rows = db.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return JSONResponse([dict(r) for r in rows])


def sources(request):
    with lock:
        rows = db.execute(
            "SELECT * FROM sources ORDER BY source_id"
        ).fetchall()
    return JSONResponse([dict(r) for r in rows])



async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    ws_clients.add(ws)
    try:
        await ws.send_json({
            "type": "snapshot",
            "data": dashboard_data()
        })
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        ws_clients.discard(ws)


routes = [
    Route("/", home),
    Route("/api/health", health),
    Route("/api/dashboard", dashboard),
    Route("/api/transactions", transactions),
    Route("/api/events", events),
    Route("/api/sources", sources),
    WebSocketRoute("/ws", websocket_endpoint),
    Mount("/static", app=StaticFiles(directory=UI / "static"), name="static"),
]

app = Starlette(routes=routes, lifespan=lifespan)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.live_main:app",
        host=os.getenv("FUELOS_HOST", "127.0.0.1"),
        port=int(os.getenv("FUELOS_PORT", "8001")),
        reload=False
    )
