"""Virtual fuel station: transaction state machine, auto-arrivals, faults, inventory. SIMULATION ONLY."""
import json
import random
import uuid
from datetime import datetime, timezone

from app.database import get_setting, money, utcnow
from .datasource import DataSource

PAYMENTS = ("CASH", "CARD", "ACCOUNT")
CUSTOMERS = ("WALK_IN", "ACCOUNT", "FLEET")
ACTIVE = ("AUTHORIZED", "DISPENSING")


class SimError(Exception):
    def __init__(self, code, msg):
        self.code = code
        super().__init__(msg)


class SimulatedDataSource(DataSource):
    source_id = "SIMULATOR-1"
    HOLD_SECONDS = 3.0

    def __init__(self, db, bus, seed=None):
        self.db, self.bus = db, bus
        self.active, self.hold, self.fault_timers = {}, {}, {}
        self.next_arrival = None
        self.set_seed(seed)

    # ---- helpers
    def setting(self, key, default=""):
        return get_setting(self.db, key, default)

    def set_seed(self, seed=None):
        if seed is None:
            s = self.setting("seed")
            seed = int(s) if str(s).strip() else None
        self.rng = random.Random(seed)
        self.next_arrival = None

    def _pump(self, pid):
        p = self.db.execute("SELECT * FROM pumps WHERE id=?", (pid,)).fetchone()
        if not p:
            raise SimError("NOT_FOUND", f"pump {pid} not found")
        return p

    def _txn(self, tid):
        t = self.db.execute("SELECT * FROM transactions WHERE id=?", (tid,)).fetchone()
        if not t:
            raise SimError("NOT_FOUND", f"transaction {tid} not found")
        return t

    def _set_pump(self, pid, status):
        self.db.execute("UPDATE pumps SET status=? WHERE id=?", (status, pid))

    def get_txn(self, tid) -> dict:
        r = self.db.execute("""SELECT t.*, g.code grade, v.reg vehicle, o.name operator, r.receipt_no, p.number pump_number
            FROM transactions t JOIN fuel_grades g ON g.id=t.grade_id JOIN operators o ON o.id=t.operator_id
            JOIN pumps p ON p.id=t.pump_id LEFT JOIN vehicles v ON v.id=t.vehicle_id
            LEFT JOIN receipts r ON r.transaction_id=t.id WHERE t.id=?""", (tid,)).fetchone()
        if not r:
            raise SimError("NOT_FOUND", f"transaction {tid} not found")
        return dict(r)

    # ---- lifecycle
    def start(self):
        """On (re)start: transactions that lost their in-memory dispensing state become FAULTED (reconcile later)."""
        events = []
        with self.db:
            self.db.execute("UPDATE transactions SET status='FAULTED' WHERE status IN('AUTHORIZED','DISPENSING')")
            self.db.execute("UPDATE pumps SET status='IDLE' WHERE status IN('AUTHORIZED','DISPENSING','COMPLETED','CANCELLED')")
            for p in self.db.execute("SELECT id,available,status FROM pumps ORDER BY id").fetchall():
                if not p["available"]:
                    self._set_pump(p["id"], "OFFLINE")
                elif p["status"] == "IDLE" or p["status"] in ("AUTHORIZED", "DISPENSING", "COMPLETED", "CANCELLED"):
                    events.append(self.bus.record("PUMP_IDLE", p["id"], None, {"reason": "startup"}))
        self.bus.dispatch(events)

    def authorize(self, pump_id, grade, vehicle_reg=None, customer_type="WALK_IN", operator="OP-01",
                  payment="CASH", preset_ml=None) -> dict:
        if payment not in PAYMENTS or customer_type not in CUSTOMERS:
            raise SimError("BAD_REQUEST", "invalid payment category or customer type")
        if preset_ml is not None and preset_ml <= 0:
            raise SimError("BAD_REQUEST", "preset must be positive")
        events, tid = [], f"TX-{datetime.now(timezone.utc):%Y%m%d}-{uuid.uuid4().hex[:8].upper()}"
        with self.db:
            p = self._pump(pump_id)
            if not p["available"]:
                raise SimError("PUMP_UNAVAILABLE", "pump is not available")
            if p["status"] != "IDLE":
                raise SimError("PUMP_BUSY", f"pump is {p['status']}")
            n = self.db.execute("""SELECT n.id nid, n.number, g.id gid, g.price_minor FROM nozzles n
                JOIN fuel_grades g ON g.id=n.grade_id WHERE n.pump_id=? AND g.code=?""", (pump_id, grade)).fetchone()
            if not n:
                raise SimError("BAD_REQUEST", f"pump {p['number']} has no nozzle for grade {grade}")
            tank = self.db.execute("SELECT * FROM tanks WHERE grade_id=?", (n["gid"],)).fetchone()
            reserved = self.db.execute("""SELECT COALESCE(SUM(max_ml),0) FROM transactions
                WHERE status IN('AUTHORIZED','DISPENSING') AND grade_id=?""", (n["gid"],)).fetchone()[0]
            max_ml = min(p["max_txn_ml"], (tank["stock_ml"] - reserved) if tank else 0,
                         preset_ml if preset_ml else p["max_txn_ml"])
            if max_ml <= 0:
                raise SimError("NO_STOCK", f"insufficient simulated stock for {grade}")
            op = operator.strip() or "OP-01"
            self.db.execute("INSERT OR IGNORE INTO operators(name) VALUES(?)", (op,))
            oid = self.db.execute("SELECT id FROM operators WHERE name=?", (op,)).fetchone()[0]
            vid = None
            reg = (vehicle_reg or "").strip().upper()
            if reg:
                self.db.execute("INSERT OR IGNORE INTO vehicles(reg,category,customer,created_at) VALUES(?,?,?,?)",
                                (reg, "Unregistered", "Walk-in", utcnow()))
                vid = self.db.execute("SELECT id FROM vehicles WHERE reg=?", (reg,)).fetchone()[0]
            self.db.execute("""INSERT INTO transactions(id,pump_id,nozzle_id,grade_id,vehicle_id,operator_id,customer_type,
                payment,status,price_minor,max_ml,started_at) VALUES(?,?,?,?,?,?,?,?,'AUTHORIZED',?,?,?)""",
                            (tid, pump_id, n["nid"], n["gid"], vid, oid, customer_type, payment, n["price_minor"], max_ml, utcnow()))
            self._set_pump(pump_id, "AUTHORIZED")
            events.append(self.bus.record("TRANSACTION_AUTHORIZED", pump_id, tid, {
                "nozzle": n["number"], "grade": grade, "vehicle": reg or None, "max_ml": max_ml,
                "price_minor": n["price_minor"], "payment": payment, "operator": op}))
            self.db.execute("UPDATE transactions SET status='DISPENSING' WHERE id=?", (tid,))
            self._set_pump(pump_id, "DISPENSING")
            events.append(self.bus.record("DISPENSING_STARTED", pump_id, tid, {"nozzle": n["number"]}))
        self.active[tid] = {"vol": 0.0}
        self.bus.dispatch(events)
        return self.get_txn(tid)

    def tick(self, dt: float):
        events, done = [], []
        sim = float(self.setting("sim_speed", "1"))
        with self.db:
            rows = self.db.execute("""SELECT t.id,t.pump_id,t.max_ml,t.price_minor,t.volume_ml,p.speed_mlps
                FROM transactions t JOIN pumps p ON p.id=t.pump_id WHERE t.status='DISPENSING' ORDER BY t.started_at""").fetchall()
            for t in rows:
                st = self.active.setdefault(t["id"], {"vol": float(t["volume_ml"])})
                st["vol"] = min(float(t["max_ml"]), st["vol"] + t["speed_mlps"] * sim * dt)
                vol = int(st["vol"])
                amt = money(vol, t["price_minor"])
                self.db.execute("UPDATE transactions SET volume_ml=?, amount_minor=? WHERE id=?", (vol, amt, t["id"]))
                events.append(self.bus.record("DISPENSING_PROGRESS", t["pump_id"], t["id"], {
                    "volume_ml": vol, "amount_minor": amt, "max_ml": t["max_ml"], "flow_mlps": int(t["speed_mlps"] * sim)}))
                if vol >= t["max_ml"]:
                    done.append(t["id"])
        self.bus.dispatch(events)
        for tid in done:
            self.complete(tid, "TARGET_REACHED")
        self._holds(dt)
        self._faults(dt)
        self._auto(dt)

    def complete(self, txn_id, reason="OPERATOR") -> dict:
        t = self._txn(txn_id)
        if t["status"] not in ("DISPENSING", "FAULTED"):
            raise SimError("BAD_STATE", f"cannot complete a {t['status']} transaction")
        vol = int(self.active[txn_id]["vol"]) if txn_id in self.active and t["status"] == "DISPENSING" else t["volume_ml"]
        if vol <= 0:
            return self.cancel(txn_id, "ZERO_VOLUME")
        events, amt, now = [], money(vol, t["price_minor"]), utcnow()
        with self.db:
            self.db.execute("UPDATE transactions SET status='COMPLETED', volume_ml=?, amount_minor=?, completed_at=? WHERE id=?",
                            (vol, amt, now, txn_id))
            events.append(self.bus.record("DISPENSING_COMPLETED", t["pump_id"], txn_id,
                                          {"volume_ml": vol, "amount_minor": amt, "reason": reason}))
            tank = self.db.execute("SELECT * FROM tanks WHERE grade_id=?", (t["grade_id"],)).fetchone()
            new = tank["stock_ml"] - vol
            self.db.execute("UPDATE tanks SET stock_ml=? WHERE id=?", (new, tank["id"]))  # CHECK rejects negative stock
            self.db.execute("INSERT INTO inventory_movements(tank_id,transaction_id,kind,delta_ml,balance_ml,ts) VALUES(?,?,?,?,?,?)",
                            (tank["id"], txn_id, "SALE", -vol, new, now))
            events.append(self.bus.record("INVENTORY_UPDATED", t["pump_id"], txn_id, {
                "tank": tank["tank_code"], "stock_ml": new, "low": new <= tank["low_threshold_ml"]}))
            self.db.execute("UPDATE transactions SET status='POS_RECORDED' WHERE id=?", (txn_id,))
            events.append(self.bus.record("POS_RECORDED", t["pump_id"], txn_id, {"amount_minor": amt, "payment": t["payment"]}))
            n = self.db.execute("SELECT COALESCE(MAX(id),0)+1 FROM receipts").fetchone()[0]
            rno = f"R{now[:10].replace('-', '')}-{n:06d}"
            self.db.execute("INSERT INTO receipts(receipt_no,transaction_id,created_at) VALUES(?,?,?)", (rno, txn_id, now))
            self.db.execute("UPDATE transactions SET status='RECEIPT_GENERATED' WHERE id=?", (txn_id,))
            events.append(self.bus.record("RECEIPT_GENERATED", t["pump_id"], txn_id, {"receipt_no": rno, "simulated": True}))
            if self._pump(t["pump_id"])["status"] in ("AUTHORIZED", "DISPENSING"):
                self._set_pump(t["pump_id"], "COMPLETED")
                self.hold[t["pump_id"]] = self.HOLD_SECONDS
        self.active.pop(txn_id, None)
        self.bus.dispatch(events)
        return self.get_txn(txn_id)

    def cancel(self, txn_id, reason="OPERATOR") -> dict:
        """Cancel without sale. Any partially dispensed volume is recorded but not charged or deducted (simulated)."""
        t = self._txn(txn_id)
        if t["status"] not in ("AUTHORIZED", "DISPENSING", "FAULTED"):
            raise SimError("BAD_STATE", f"cannot cancel a {t['status']} transaction")
        vol = int(self.active[txn_id]["vol"]) if txn_id in self.active else t["volume_ml"]
        events = []
        with self.db:
            self.db.execute("UPDATE transactions SET status='CANCELLED', volume_ml=?, amount_minor=0, cancelled_reason=? WHERE id=?",
                            (vol, reason, txn_id))
            events.append(self.bus.record("TRANSACTION_CANCELLED", t["pump_id"], txn_id, {"reason": reason, "volume_ml": vol}))
            if self._pump(t["pump_id"])["status"] in ("AUTHORIZED", "DISPENSING"):
                self._set_pump(t["pump_id"], "IDLE")
                events.append(self.bus.record("PUMP_IDLE", t["pump_id"], None, {}))
        self.active.pop(txn_id, None)
        self.bus.dispatch(events)
        return self.get_txn(txn_id)

    # ---- faults / recovery / reconciliation
    def fault(self, pump_id, kind="FAULT") -> dict:
        if kind not in ("FAULT", "COMMUNICATION_LOSS"):
            raise SimError("BAD_REQUEST", "kind must be FAULT or COMMUNICATION_LOSS")
        events = []
        with self.db:
            p = self._pump(pump_id)
            if p["status"] in ("FAULT", "OFFLINE"):
                raise SimError("BAD_STATE", f"pump already {p['status']}")
            t = self.db.execute("SELECT id FROM transactions WHERE pump_id=? AND status IN('AUTHORIZED','DISPENSING')", (pump_id,)).fetchone()
            if t:
                self.db.execute("UPDATE transactions SET status='FAULTED' WHERE id=?", (t["id"],))
                self.active.pop(t["id"], None)
            self._set_pump(pump_id, "FAULT" if kind == "FAULT" else "OFFLINE")
            events.append(self.bus.record("PUMP_FAULT", pump_id, t["id"] if t else None, {"kind": kind}))
        self.hold.pop(pump_id, None)
        self.bus.dispatch(events)
        return {"pump_id": pump_id, "kind": kind}

    def recover(self, pump_id) -> dict:
        events = []
        with self.db:
            p = self._pump(pump_id)
            if p["status"] not in ("FAULT", "OFFLINE") or not p["available"]:
                raise SimError("BAD_STATE", "pump is not in a recoverable state")
            self._set_pump(pump_id, "IDLE")
            events += [self.bus.record("PUMP_RECOVERED", pump_id, None, {}), self.bus.record("PUMP_IDLE", pump_id, None, {})]
        self.bus.dispatch(events)
        return {"pump_id": pump_id, "status": "IDLE"}

    def reconcile(self) -> dict:
        """Settle FAULTED transactions on pumps that are back online (complete if volume>0 else cancel) and verify
        each tank's stock equals its movement ledger."""
        settled = []
        rows = self.db.execute("""SELECT t.id FROM transactions t JOIN pumps p ON p.id=t.pump_id
            WHERE t.status='FAULTED' AND p.status NOT IN('FAULT','OFFLINE')""").fetchall()
        for r in rows:
            res = self.complete(r["id"], "RECONCILED")
            settled.append({"id": r["id"], "result": res["status"]})
        tanks = [{"tank": x["tank_code"], "stock_ml": x["stock_ml"], "ledger_ml": x["ledger"], "ok": x["stock_ml"] == x["ledger"]}
                 for x in self.db.execute("""SELECT t.tank_code,t.stock_ml,COALESCE(SUM(m.delta_ml),0) ledger FROM tanks t
                 LEFT JOIN inventory_movements m ON m.tank_id=t.id GROUP BY t.id""")]
        return {"settled": settled, "tanks": tanks, "consistent": all(t["ok"] for t in tanks)}

    # ---- configuration operations
    def create_pump(self, grades, speed_lpm=40, max_txn_l=60) -> dict:
        events = []
        with self.db:
            num = self.db.execute("SELECT COALESCE(MAX(number),0)+1 FROM pumps").fetchone()[0]
            cur = self.db.execute("INSERT INTO pumps(station_id,number,speed_mlps,max_txn_ml,created_at) VALUES(1,?,?,?,?)",
                                  (num, round(speed_lpm * 1000 / 60), int(max_txn_l * 1000), utcnow()))
            pid = cur.lastrowid
            for i, code in enumerate(grades, 1):
                g = self.db.execute("SELECT id FROM fuel_grades WHERE code=?", (code,)).fetchone()
                if not g:
                    raise SimError("BAD_REQUEST", f"unknown grade {code}")
                self.db.execute("INSERT INTO nozzles(pump_id,number,grade_id) VALUES(?,?,?)", (pid, i, g["id"]))
            if not grades:
                raise SimError("BAD_REQUEST", "a pump needs at least one nozzle")
            events.append(self.bus.record("PUMP_IDLE", pid, None, {"reason": "created"}))
        self.bus.dispatch(events)
        return {"id": pid, "number": num}

    def set_available(self, pump_id, available: bool):
        events = []
        with self.db:
            p = self._pump(pump_id)
            if p["status"] in ACTIVE:
                raise SimError("PUMP_BUSY", "pump is in a transaction")
            self.db.execute("UPDATE pumps SET available=? WHERE id=?", (1 if available else 0, pump_id))
            if not available:
                self._set_pump(pump_id, "OFFLINE")
            elif p["status"] == "OFFLINE":
                self._set_pump(pump_id, "IDLE")
                events.append(self.bus.record("PUMP_IDLE", pump_id, None, {}))
        self.bus.dispatch(events)

    def replenish(self, tank_id, ml) -> dict:
        if ml <= 0:
            raise SimError("BAD_REQUEST", "quantity must be positive")
        events = []
        with self.db:
            tk = self.db.execute("SELECT * FROM tanks WHERE id=?", (tank_id,)).fetchone()
            if not tk:
                raise SimError("NOT_FOUND", "tank not found")
            if tk["stock_ml"] + ml > tk["capacity_ml"]:
                raise SimError("BAD_REQUEST", "exceeds tank capacity")
            new = tk["stock_ml"] + ml
            self.db.execute("UPDATE tanks SET stock_ml=? WHERE id=?", (new, tank_id))
            self.db.execute("INSERT INTO inventory_movements(tank_id,kind,delta_ml,balance_ml,ts) VALUES(?,?,?,?,?)",
                            (tank_id, "REPLENISH", ml, new, utcnow()))
            events.append(self.bus.record("INVENTORY_UPDATED", None, None, {
                "tank": tk["tank_code"], "stock_ml": new, "low": new <= tk["low_threshold_ml"], "replenished_ml": ml}))
        self.bus.dispatch(events)
        return {"tank": tk["tank_code"], "stock_ml": new}

    # ---- timers, faults, automatic mode
    def _holds(self, dt):
        events = []
        with self.db:
            for pid in list(self.hold):
                self.hold[pid] -= dt
                if self.hold[pid] <= 0:
                    del self.hold[pid]
                    if self._pump(pid)["status"] == "COMPLETED":
                        self._set_pump(pid, "IDLE")
                        events.append(self.bus.record("PUMP_IDLE", pid, None, {}))
        self.bus.dispatch(events)

    def _faults(self, dt):
        rate = float(self.setting("fault_rate", "0") or 0)
        if self.setting("sim_mode") == "auto" and rate > 0:
            for r in self.db.execute("SELECT id FROM pumps WHERE status='DISPENSING' ORDER BY id").fetchall():
                if self.rng.random() < rate * dt:
                    self.fault(r["id"], "FAULT")
                    self.fault_timers[r["id"]] = self.rng.uniform(5, 15)
        for pid in list(self.fault_timers):
            self.fault_timers[pid] -= dt
            if self.fault_timers[pid] <= 0:
                del self.fault_timers[pid]
                try:
                    self.recover(pid)
                    self.reconcile()
                except SimError:
                    pass

    def _interval(self):
        return max(0.5, self.rng.expovariate(1.0 / max(0.1, float(self.setting("arrival_interval_s", "8")))))

    def _auto(self, dt):
        if self.setting("sim_mode") != "auto":
            return
        h = datetime.now().hour
        if not int(self.setting("hours_start", "0")) <= h < int(self.setting("hours_end", "24")):
            return
        if self.next_arrival is None:
            self.next_arrival = self._interval()
        self.next_arrival -= dt
        if self.next_arrival > 0:
            return
        self.next_arrival = self._interval()
        busy = self.db.execute("SELECT COUNT(*) FROM transactions WHERE status IN('AUTHORIZED','DISPENSING')").fetchone()[0]
        if busy >= int(self.setting("max_concurrent", "3")):
            return
        pumps = [r[0] for r in self.db.execute("SELECT id FROM pumps WHERE available=1 AND status='IDLE' ORDER BY id")]
        if not pumps:
            return
        pid = self.rng.choice(pumps)
        codes = [r[0] for r in self.db.execute("""SELECT g.code FROM nozzles n JOIN fuel_grades g ON g.id=n.grade_id
            WHERE n.pump_id=? ORDER BY n.number""", (pid,))]
        weights = json.loads(self.setting("grade_weights", "{}") or "{}")
        grade = self.rng.choices(codes, weights=[float(weights.get(c, 1)) for c in codes])[0]
        regs = [r[0] for r in self.db.execute("SELECT reg FROM vehicles ORDER BY id")]
        walkin = self.rng.random() * 100 < float(self.setting("walkin_pct", "30")) or not regs
        reg = None if walkin else self.rng.choice(regs)
        cust = self.rng.choice(CUSTOMERS) if reg else "WALK_IN"
        pay = "ACCOUNT" if cust == "ACCOUNT" else self.rng.choice(("CASH", "CARD"))
        preset = self.rng.choice((None, 5000, 10000, 20000, 30000, 40000))
        ops = [r[0] for r in self.db.execute("SELECT name FROM operators ORDER BY id")]
        try:
            self.authorize(pid, grade, reg, cust, self.rng.choice(ops) if ops else "OP-01", pay, preset)
        except SimError:
            pass

    # ---- snapshots
    def state(self) -> dict:
        pumps = []
        for p in self.db.execute("SELECT * FROM pumps ORDER BY id").fetchall():
            noz = [dict(n) for n in self.db.execute("""SELECT n.id,n.number,g.code grade,g.name grade_name,g.price_minor
                FROM nozzles n JOIN fuel_grades g ON g.id=n.grade_id WHERE n.pump_id=? ORDER BY n.number""", (p["id"],))]
            t = self.db.execute("""SELECT t.id,t.status,t.volume_ml,t.amount_minor,t.max_ml,t.price_minor,g.code grade,v.reg vehicle
                FROM transactions t JOIN fuel_grades g ON g.id=t.grade_id LEFT JOIN vehicles v ON v.id=t.vehicle_id
                WHERE t.pump_id=? AND t.status IN('AUTHORIZED','DISPENSING','FAULTED') ORDER BY t.started_at DESC LIMIT 1""",
                                (p["id"],)).fetchone()
            pumps.append({"id": p["id"], "number": p["number"], "status": p["status"], "available": bool(p["available"]),
                          "speed_lpm": round(p["speed_mlps"] * 60 / 1000, 1), "max_txn_ml": p["max_txn_ml"],
                          "nozzles": noz, "txn": dict(t) if t else None})
        c = {k: sum(1 for p in pumps if p["status"] in v) for k, v in
             {"active": ("AUTHORIZED", "DISPENSING"), "idle": ("IDLE", "COMPLETED", "CANCELLED"),
              "offline": ("OFFLINE",), "fault": ("FAULT",)}.items()}
        today = utcnow()[:10]
        s = self.db.execute("""SELECT COUNT(*) n, COALESCE(SUM(volume_ml),0) ml, COALESCE(SUM(amount_minor),0) amt
            FROM transactions WHERE status='RECEIPT_GENERATED' AND substr(completed_at,1,10)=?""", (today,)).fetchone()
        st = self.db.execute("SELECT * FROM stations WHERE id=1").fetchone()
        recent = [dict(r) for r in self.db.execute("""SELECT t.id,t.status,t.volume_ml,t.amount_minor,t.payment,t.started_at,
            t.completed_at,p.number pump,g.code grade,v.reg vehicle,r.receipt_no FROM transactions t
            JOIN pumps p ON p.id=t.pump_id JOIN fuel_grades g ON g.id=t.grade_id LEFT JOIN vehicles v ON v.id=t.vehicle_id
            LEFT JOIN receipts r ON r.transaction_id=t.id ORDER BY t.started_at DESC LIMIT 10""")]
        return {"simulated": True, "source": self.source_id, "station": dict(st), "pumps": pumps, "pump_counts": c,
                "stats": {"count": s["n"], "volume_ml": s["ml"], "amount_minor": s["amt"], "day_utc": today},
                "recent": recent, "last_seq": self.bus.last_seq(), "mode": self.setting("sim_mode")}
