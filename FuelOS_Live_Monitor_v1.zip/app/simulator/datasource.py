"""Data-source interface. The monitoring layer only consumes standardized events from the EventBus,
so a real source can replace the simulator without frontend changes."""
from abc import ABC, abstractmethod


class DataSource(ABC):
    source_id = "UNDEFINED"

    @abstractmethod
    def start(self): ...

    @abstractmethod
    def tick(self, dt: float): ...

    @abstractmethod
    def state(self) -> dict: ...


class FutureReadOnlyStationDataSource(DataSource):
    """PLACEHOLDER ONLY. A future, manufacturer-AUTHORIZED, READ-ONLY adapter would translate vendor data
    into the same standardized events. It must never send control or dispensing commands. Not implemented."""
    source_id = "READONLY-PLACEHOLDER"

    def start(self):
        raise NotImplementedError("Read-only station integration is not implemented.")

    def tick(self, dt):
        raise NotImplementedError

    def state(self):
        raise NotImplementedError
