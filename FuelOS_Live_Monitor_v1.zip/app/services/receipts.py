"""Simulated receipt generation (HTML + PDF)."""
import html
import io

from app.database import fmt_money

BANNER = "*** SIMULATED TEST RECEIPT - NOT A VALID TAX DOCUMENT ***"


def receipt_data(db, receipt_no):
    r = db.execute("""SELECT r.receipt_no, r.created_at, t.*, p.number pump_no, n.number nozzle_no, g.name grade_name,
        v.reg vehicle, o.name operator, s.name station, s.code station_code, s.address, s.currency
        FROM receipts r JOIN transactions t ON t.id=r.transaction_id JOIN pumps p ON p.id=t.pump_id
        JOIN nozzles n ON n.id=t.nozzle_id JOIN fuel_grades g ON g.id=t.grade_id JOIN operators o ON o.id=t.operator_id
        JOIN stations s ON s.id=p.station_id LEFT JOIN vehicles v ON v.id=t.vehicle_id WHERE r.receipt_no=?""",
                   (receipt_no,)).fetchone()
    return dict(r) if r else None


def lines(d):
    cur = d["currency"]
    return [("Station", d["station"]), ("Station ID", d["station_code"]), ("Address", d["address"]),
            ("Receipt No", d["receipt_no"]), ("Transaction", d["id"]), ("Date (UTC)", d["completed_at"][:19].replace("T", " ")),
            ("Pump / Nozzle", f"{d['pump_no']} / {d['nozzle_no']}"), ("Fuel grade", d["grade_name"]),
            ("Quantity", f"{d['volume_ml'] / 1000:.3f} L"), ("Unit price", f"{cur} {fmt_money(d['price_minor'])} /L"),
            ("TOTAL", f"{cur} {fmt_money(d['amount_minor'])}"), ("Vehicle", d["vehicle"] or "N/A"),
            ("Operator", d["operator"]), ("Payment", d["payment"] + " (not processed)")]


def render_html(d):
    rows = "".join(f"<tr><td>{html.escape(k)}</td><td>{html.escape(str(v))}</td></tr>" for k, v in lines(d))
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Receipt {html.escape(d['receipt_no'])}</title>
<style>body{{font-family:'Courier New',monospace;max-width:340px;margin:20px auto;color:#000}}
.b{{border:2px solid #000;padding:6px;text-align:center;font-weight:bold;margin:10px 0}}
td{{padding:2px 4px;vertical-align:top}}td:first-child{{font-weight:bold}}
@media print{{.np{{display:none}}}}</style></head><body>
<div class="b">{BANNER}</div><table>{rows}</table><div class="b">SIMULATION - NO REAL FUEL OR PAYMENT</div>
<p class="np"><button onclick="window.print()">Print / Save as PDF</button>
<a href="/api/receipts/{html.escape(d['receipt_no'])}/pdf">Download PDF</a></p></body></html>"""


def render_pdf(d) -> bytes:
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(80 * mm, 170 * mm))
    y = 160 * mm
    c.setFont("Courier-Bold", 7)
    c.drawCentredString(40 * mm, y, "SIMULATED TEST RECEIPT")
    y -= 4 * mm
    c.drawCentredString(40 * mm, y, "NOT A VALID TAX DOCUMENT")
    y -= 7 * mm
    for k, v in lines(d):
        c.setFont("Courier-Bold", 7.5)
        c.drawString(4 * mm, y, k + ":")
        c.setFont("Courier", 7.5)
        c.drawString(27 * mm, y, str(v)[:30])
        y -= 5.5 * mm
    c.setFont("Courier-Bold", 7)
    c.drawCentredString(40 * mm, y - 3 * mm, "SIMULATION - NO REAL FUEL OR PAYMENT")
    c.save()
    return buf.getvalue()
