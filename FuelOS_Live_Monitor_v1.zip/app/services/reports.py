"""Vehicles, analytics and reporting queries."""
from datetime import datetime, timedelta, timezone

from app.database import utcnow
from app.simulator.engine import SimError

DONE = "t.status='RECEIPT_GENERATED'"


def add_vehicle(db, reg, category="Car", customer="Walk-in"):
    reg = reg.strip().upper()
    if not reg:
        raise SimError("BAD_REQUEST", "registration required")
    try:
        with db:
            cur = db.execute("INSERT INTO vehicles(reg,category,customer,created_at) VALUES(?,?,?,?)", (reg, category, customer, utcnow()))
    except Exception as e:
        raise SimError("CONFLICT", f"vehicle {reg} already exists") from e
    return cur.lastrowid


def update_vehicle(db, vid, reg, category, customer):
    reg = reg.strip().upper()
    try:
        with db:
            cur = db.execute("UPDATE vehicles SET reg=?,category=?,customer=? WHERE id=?", (reg, category, customer, vid))
    except Exception as e:
        raise SimError("CONFLICT", "registration already used") from e
    if not cur.rowcount:
        raise SimError("NOT_FOUND", "vehicle not found")


def list_vehicles(db):
    return [dict(r) for r in db.execute("""SELECT v.*, COUNT(t.id) transactions, COALESCE(SUM(t.volume_ml),0) volume_ml,
        COALESCE(SUM(t.amount_minor),0) amount_minor FROM vehicles v
        LEFT JOIN transactions t ON t.vehicle_id=v.id AND t.status='RECEIPT_GENERATED' GROUP BY v.id ORDER BY v.reg""")]


def vehicle_report(db, vid):
    v = db.execute("SELECT * FROM vehicles WHERE id=?", (vid,)).fetchone()
    if not v:
        raise SimError("NOT_FOUND", "vehicle not found")
    tx = [dict(r) for r in db.execute("""SELECT t.id,t.completed_at,t.volume_ml,t.amount_minor,t.payment,g.code grade,r.receipt_no
        FROM transactions t JOIN fuel_grades g ON g.id=t.grade_id LEFT JOIN receipts r ON r.transaction_id=t.id
        WHERE t.vehicle_id=? AND t.status='RECEIPT_GENERATED' ORDER BY t.completed_at DESC""", (vid,))]
    return {"vehicle": dict(v), "transactions": tx, "total_volume_ml": sum(x["volume_ml"] for x in tx),
            "total_amount_minor": sum(x["amount_minor"] for x in tx)}


def list_transactions(db, status=None, vehicle=None, limit=200):
    sql = """SELECT t.id,t.status,t.volume_ml,t.amount_minor,t.price_minor,t.payment,t.started_at,t.completed_at,t.cancelled_reason,
        p.number pump,g.code grade,v.reg vehicle,o.name operator,r.receipt_no FROM transactions t
        JOIN pumps p ON p.id=t.pump_id JOIN fuel_grades g ON g.id=t.grade_id JOIN operators o ON o.id=t.operator_id
        LEFT JOIN vehicles v ON v.id=t.vehicle_id LEFT JOIN receipts r ON r.transaction_id=t.id WHERE 1=1"""
    args = []
    if status:
        sql += " AND t.status=?"
        args.append(status)
    if vehicle:
        sql += " AND v.reg=?"
        args.append(vehicle.upper())
    return [dict(r) for r in db.execute(sql + " ORDER BY t.started_at DESC LIMIT ?", args + [limit])]


def analytics(db, period="day"):
    days = {"day": 1, "week": 7, "month": 30}.get(period)
    if not days:
        raise SimError("BAD_REQUEST", "period must be day, week or month")
    since = (datetime.now(timezone.utc) - timedelta(days=days - 1)).strftime("%Y-%m-%d")
    rows = lambda sql: [dict(r) for r in db.execute(sql, (since,))]  # noqa: E731
    base = f"FROM transactions t WHERE {DONE} AND substr(t.completed_at,1,10)>=?"
    tot = db.execute(f"SELECT COUNT(*) n, COALESCE(SUM(volume_ml),0) ml, COALESCE(SUM(amount_minor),0) amt, COALESCE(AVG(volume_ml),0) avg_ml {base}", (since,)).fetchone()
    started = db.execute("SELECT COUNT(*) FROM transactions WHERE substr(started_at,1,10)>=?", (since,)).fetchone()[0]
    cancelled = db.execute("SELECT COUNT(*) FROM transactions WHERE status='CANCELLED' AND substr(started_at,1,10)>=?", (since,)).fetchone()[0]
    return {"period": period, "since": since,
            "totals": {"count": tot["n"], "volume_ml": tot["ml"], "amount_minor": tot["amt"], "avg_volume_ml": round(tot["avg_ml"])},
            "cancellations": {"cancelled": cancelled, "started": started,
                              "rate_pct": round(100 * cancelled / started, 1) if started else 0,
                              "reasons": rows("SELECT COALESCE(cancelled_reason,'?') reason, COUNT(*) n FROM transactions t WHERE t.status='CANCELLED' AND substr(t.started_at,1,10)>=? GROUP BY 1")},
            "daily": rows(f"SELECT substr(t.completed_at,1,10) day, COUNT(*) n, SUM(volume_ml) volume_ml, SUM(amount_minor) amount_minor {base} GROUP BY 1 ORDER BY 1"),
            "hourly": rows(f"SELECT substr(t.completed_at,12,2) hour, COUNT(*) n, SUM(volume_ml) volume_ml {base} GROUP BY 1 ORDER BY 1"),
            "by_grade": rows(f"SELECT g.code grade, COUNT(*) n, SUM(t.volume_ml) volume_ml, SUM(t.amount_minor) amount_minor {base.replace('FROM transactions t', 'FROM transactions t JOIN fuel_grades g ON g.id=t.grade_id')} GROUP BY g.code"),
            "by_pump": rows(f"SELECT p.number pump, COUNT(*) n, SUM(t.volume_ml) volume_ml, SUM(t.amount_minor) amount_minor {base.replace('FROM transactions t', 'FROM transactions t JOIN pumps p ON p.id=t.pump_id')} GROUP BY p.number ORDER BY p.number"),
            "by_vehicle": rows(f"SELECT v.reg, COUNT(*) n, SUM(t.volume_ml) volume_ml, SUM(t.amount_minor) amount_minor {base.replace('FROM transactions t', 'FROM transactions t JOIN vehicles v ON v.id=t.vehicle_id')} GROUP BY v.reg ORDER BY 4 DESC LIMIT 15")}
