"""FuelOS application: REST API + WebSocket event stream + static UI. SIMULATION ONLY."""
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path

from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from app import config
from app.database import connect, init_db, seed_demo, set_setting, utcnow
from app.events import EventBus
from app.models.schemas import (FaultIn, PriceIn, PumpIn, PumpPatch, ReplenishIn, SettingsIn, StartTxn,
                                StationIn, TankPatch, VehicleIn)
from app.services import receipts as rc, reports
from app.simulator import SimError, SimulatedDataSource

log = logging.getLogger("fuelos")
HERE = Path(__file__).resolve().parent
SETTING_KEYS = {"sim_mode", "sim_speed", "arrival_interval_s", "max_concurrent", "fault_rate", "seed",
                "hours_start", "hours_end", "walkin_pct", "grade_weights"}
CODES = {"NOT_FOUND": 404, "BAD_REQUEST": 422, "CONFLICT": 409}


def to_minor(s: str) -> int:
    try:
        d = (Decimal(str(s)) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        raise SimError("BAD_REQUEST", "invalid amount")
    if d < 0:
        raise SimError("BAD_REQUEST", "amount must not be negative")
    return int(d)


def litres_to_ml(x: float) -> int:
    return int((Decimal(str(x)) * 1000).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def create_app(db_path=None, run_loop=True) -> FastAPI:
    db = connect(db_path or config.DB_PATH)
    init_db(db)
    seed_demo(db)
    bus = EventBus(db, SimulatedDataSource.source_id)
    sim = SimulatedDataSource(db, bus)
    started = time.time()

    async def loop():
        last = time.monotonic()
        while True:
            await asyncio.sleep(config.TICK_SECONDS)
            now = time.monotonic()
            dt, last = now - last, now
            try:
                sim.tick(dt)
            except Exception:  # keep the engine alive
                log.exception("tick failed")

    @asynccontextmanager
    async def lifespan(_):
        sim.start()
        task = asyncio.create_task(loop()) if run_loop else None
        yield
        if task:
            task.cancel()

    app = FastAPI(title="FuelOS (simulation)", lifespan=lifespan)
    app.state.db, app.state.sim, app.state.bus = db, sim, bus

    @app.exception_handler(SimError)
    async def _sim_err(_, e: SimError):
        return JSONResponse({"detail": str(e), "code": e.code}, status_code=CODES.get(e.code, 409))

    # ---- state & health
    @app.get("/api/state")
    async def state():
        return sim.state()

    @app.get("/api/health")
    async def health():
        lat = list(bus.latency_ms)
        return {"simulated": True, "source": sim.source_id, "uptime_s": round(time.time() - started),
                "ws_clients": len(bus.subs), "last_seq": bus.last_seq(), "server_time": utcnow(),
                "server_dispatch_latency_ms": {"avg": round(sum(lat) / len(lat), 3) if lat else None,
                                               "max": round(max(lat), 3) if lat else None, "samples": len(lat)}}

    # ---- transactions
    @app.post("/api/transactions")
    async def start_txn(b: StartTxn):
        preset = litres_to_ml(b.preset_litres) if b.preset_litres else None
        return sim.authorize(b.pump_id, b.grade, b.vehicle_reg, b.customer_type, b.operator, b.payment, preset)

    @app.post("/api/transactions/{tid}/complete")
    async def complete(tid: str):
        return sim.complete(tid)

    @app.post("/api/transactions/{tid}/cancel")
    async def cancel(tid: str):
        return sim.cancel(tid)

    @app.get("/api/transactions")
    async def txns(status: str = None, vehicle: str = None, limit: int = Query(200, le=1000)):
        return reports.list_transactions(db, status, vehicle, limit)

    @app.get("/api/transactions/{tid}")
    async def txn(tid: str):
        return sim.get_txn(tid)

    # ---- pumps
    @app.post("/api/pumps")
    async def new_pump(b: PumpIn):
        return sim.create_pump(b.grades, b.speed_lpm, b.max_txn_litres)

    @app.patch("/api/pumps/{pid}")
    async def patch_pump(pid: int, b: PumpPatch):
        sim._pump(pid)
        with db:
            if b.speed_lpm is not None:
                db.execute("UPDATE pumps SET speed_mlps=? WHERE id=?", (max(1, round(b.speed_lpm * 1000 / 60)), pid))
            if b.max_txn_litres is not None:
                db.execute("UPDATE pumps SET max_txn_ml=? WHERE id=?", (litres_to_ml(b.max_txn_litres), pid))
        if b.available is not None:
            sim.set_available(pid, b.available)
        return {"ok": True}

    @app.post("/api/pumps/{pid}/fault")
    async def fault(pid: int, b: FaultIn):
        return sim.fault(pid, b.kind)

    @app.post("/api/pumps/{pid}/recover")
    async def recover(pid: int):
        return sim.recover(pid)

    @app.post("/api/reconcile")
    async def reconcile():
        return sim.reconcile()

    # ---- receipts
    @app.get("/api/receipts")
    async def receipts():
        return [dict(r) for r in db.execute("""SELECT r.receipt_no,r.created_at,t.id txn,t.amount_minor,t.volume_ml,v.reg vehicle
            FROM receipts r JOIN transactions t ON t.id=r.transaction_id LEFT JOIN vehicles v ON v.id=t.vehicle_id
            ORDER BY r.id DESC LIMIT 200""")]

    @app.get("/receipts/{no}", response_class=HTMLResponse)
    async def receipt_page(no: str):
        d = rc.receipt_data(db, no)
        if not d:
            raise SimError("NOT_FOUND", "receipt not found")
        return rc.render_html(d)

    @app.get("/api/receipts/{no}/pdf")
    async def receipt_pdf(no: str):
        d = rc.receipt_data(db, no)
        if not d:
            raise SimError("NOT_FOUND", "receipt not found")
        try:
            pdf = rc.render_pdf(d)
        except ImportError:
            return JSONResponse({"detail": "reportlab not installed; use browser print-to-PDF on /receipts/<no>"}, status_code=501)
        return Response(pdf, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{no}.pdf"'})

    # ---- vehicles
    @app.get("/api/vehicles")
    async def vehicles():
        return reports.list_vehicles(db)

    @app.post("/api/vehicles")
    async def add_vehicle(b: VehicleIn):
        return {"id": reports.add_vehicle(db, b.reg, b.category, b.customer)}

    @app.put("/api/vehicles/{vid}")
    async def edit_vehicle(vid: int, b: VehicleIn):
        reports.update_vehicle(db, vid, b.reg, b.category, b.customer)
        return {"ok": True}

    @app.get("/api/vehicles/{vid}/report")
    async def vehicle_report(vid: int):
        return reports.vehicle_report(db, vid)

    # ---- inventory
    @app.get("/api/tanks")
    async def tanks():
        out = [dict(r) for r in db.execute("""SELECT t.*, g.code grade, g.name grade_name FROM tanks t
            JOIN fuel_grades g ON g.id=t.grade_id ORDER BY t.id""")]
        for t in out:
            t["low"] = t["stock_ml"] <= t["low_threshold_ml"]
        return out

    @app.post("/api/tanks/{tid}/replenish")
    async def replenish(tid: int, b: ReplenishIn):
        return sim.replenish(tid, litres_to_ml(b.litres))

    @app.put("/api/tanks/{tid}")
    async def tank_cap(tid: int, b: TankPatch):
        cap = litres_to_ml(b.capacity_litres)
        try:
            with db:
                cur = db.execute("UPDATE tanks SET capacity_ml=?, low_threshold_ml=? WHERE id=?", (cap, cap // 10, tid))
        except Exception as e:
            raise SimError("BAD_REQUEST", "capacity cannot be below current stock") from e
        if not cur.rowcount:
            raise SimError("NOT_FOUND", "tank not found")
        return {"ok": True}

    # ---- analytics / events
    @app.get("/api/analytics")
    async def analytics(period: str = "day"):
        return reports.analytics(db, period)

    @app.get("/api/events")
    async def events(since: int = 0, limit: int = Query(200, le=5000), type: str = None, latest: bool = False):
        if latest:
            rows = db.execute("SELECT seq FROM transaction_events ORDER BY seq DESC LIMIT 1 OFFSET ?", (limit - 1,)).fetchone()
            since = max(since, (rows[0] - 1) if rows else 0)
        return bus.history(since, limit, type)

    # ---- configuration
    @app.get("/api/config")
    async def get_config():
        return {"station": dict(db.execute("SELECT * FROM stations WHERE id=1").fetchone()),
                "grades": [dict(r) for r in db.execute("SELECT * FROM fuel_grades ORDER BY id")],
                "settings": {r[0]: r[1] for r in db.execute("SELECT key,value FROM station_settings")},
                "operators": [r[0] for r in db.execute("SELECT name FROM operators ORDER BY id")]}

    @app.put("/api/config/station")
    async def put_station(b: StationIn):
        with db:
            db.execute("UPDATE stations SET name=?,address=?,currency=? WHERE id=1", (b.name, b.address, b.currency.upper()))
        return {"ok": True}

    @app.put("/api/grades/{gid}")
    async def put_price(gid: int, b: PriceIn):
        with db:
            cur = db.execute("UPDATE fuel_grades SET price_minor=? WHERE id=?", (to_minor(b.price), gid))
        if not cur.rowcount:
            raise SimError("NOT_FOUND", "grade not found")
        return {"ok": True}

    @app.put("/api/config/settings")
    async def put_settings(b: SettingsIn):
        bad = set(b.settings) - SETTING_KEYS
        if bad:
            raise SimError("BAD_REQUEST", f"unknown settings: {sorted(bad)}")
        for k, v in b.settings.items():
            set_setting(db, k, v)
        if "seed" in b.settings:
            sim.set_seed()
        return {"ok": True}

    # ---- WebSocket: replay missed events from history, then stream live
    @app.websocket("/ws")
    async def ws(websocket: WebSocket, since: int = 0):
        await websocket.accept()
        q = bus.subscribe()  # subscribe BEFORE replay so nothing is missed; duplicates are skipped by seq
        last = since
        try:
            while True:
                batch = bus.history(last, 1000)
                if not batch:
                    break
                for ev in batch:
                    await websocket.send_json({"kind": "event", "event": ev})
                    last = ev["seq"]
            await websocket.send_json({"kind": "hello", "source": sim.source_id, "simulated": True, "last_seq": last})
            while True:
                try:
                    ev = await asyncio.wait_for(q.get(), config.HEARTBEAT_SECONDS)
                except asyncio.TimeoutError:
                    await websocket.send_json({"kind": "heartbeat", "ts": utcnow(), "last_seq": last})
                    continue
                if ev["seq"] <= last:
                    continue
                await websocket.send_json({"kind": "event", "event": ev})
                last = ev["seq"]
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            bus.unsubscribe(q)

    app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")

    @app.get("/")
    async def index():
        return FileResponse(HERE / "templates" / "index.html")

    return app


if __name__ == "__main__":
    import uvicorn
    host = config.check_bind()
    print(f"FuelOS (SIMULATION) starting at http://{host}:{config.PORT}")
    if host not in ("127.0.0.1", "localhost", "::1"):
        print("WARNING: LAN binding enabled and the app has no authentication.")
    uvicorn.run(create_app(), host=host, port=config.PORT, log_level="info")
