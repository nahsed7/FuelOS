'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const M = m => (m / 100).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
const Lt = ml => (ml / 1000).toFixed(2);
const T = ts => ts ? ts.slice(11, 19) : '';
async function api(path, opt = {}) {
  const r = await fetch('/api' + path, {headers: {'Content-Type': 'application/json'}, ...opt, body: opt.body ? JSON.stringify(opt.body) : undefined});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail || r.statusText));
  return j;
}
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { alert(e.message); } };

let S = null, H = null, CUR = 'overview', feed = [], lat = [], lastSeq = 0, lastBeat = 0, ws = null, retry = 0, charts = [], posMsg = '';
const PAGES = [['overview','Overview'],['dispensers','Live Dispensers'],['forecourt','Virtual Forecourt'],['pos','POS / Cashier'],['transactions','Transactions'],
  ['receipts','Receipts'],['vehicles','Vehicles'],['inventory','Inventory'],['analytics','Analytics'],['events','Event Logs'],['config','Station Configuration']];
$('#links').innerHTML = PAGES.map(([k, n]) => `<a href="#${k}" data-p="${k}"><span>${n}</span></a>`).join('');

// ---------- connection / events
function setConn() {
  const age = Date.now() - lastBeat, open = ws && ws.readyState === 1;
  const st = !open ? ['off', 'OFFLINE'] : age > 12000 ? ['stale', 'STALE'] : ['live', 'LIVE'];
  $('#conn').className = 'pill ' + st[0]; $('#conn').textContent = st[1];
  const a = lat.length ? Math.round(lat.reduce((x, y) => x + y, 0) / lat.length) : null;
  $('#lat').textContent = a === null ? '' : `delivery latency avg ${a} ms (client clock vs server UTC stamp)`;
  $('#clock').textContent = new Date().toISOString().slice(0, 19).replace('T', ' ') + ' UTC';
}
function connect() {
  ws = new WebSocket((location.protocol === 'https:' ? 'wss' : 'ws') + '://' + location.host + '/ws?since=' + lastSeq);
  ws.onopen = () => { retry = 0; lastBeat = Date.now(); setConn(); };
  ws.onmessage = e => { lastBeat = Date.now(); const m = JSON.parse(e.data); if (m.kind === 'event') onEvent(m.event); };
  ws.onclose = () => { setConn(); setTimeout(connect, Math.min(10000, 500 * 2 ** retry++)); };
}
setInterval(() => { if (ws && ws.readyState === 1 && Date.now() - lastBeat > 15000) ws.close(); setConn(); }, 1000);  // heartbeat watchdog
function onEvent(ev) {
  if (ev.seq <= lastSeq) return;  // duplicate / replay protection
  lastSeq = ev.seq; lat.push(Math.max(0, Date.now() - Date.parse(ev.ts))); if (lat.length > 50) lat.shift();
  feed.unshift(ev); if (feed.length > 300) feed.pop();
  if (ev.type === 'DISPENSING_PROGRESS' && S) {
    const p = S.pumps.find(p => p.id === ev.pump_id);
    if (p && p.txn) { p.status = 'DISPENSING'; p.txn.volume_ml = ev.payload.volume_ml; p.txn.amount_minor = ev.payload.amount_minor; liveRender(); return; }
  }
  scheduleRefresh();
}
let rt = null;
function scheduleRefresh() { clearTimeout(rt); rt = setTimeout(async () => { S = await api('/state'); liveRender(true); }, 150); }
function liveRender(full) {
  if (['overview', 'dispensers', 'forecourt'].includes(CUR)) PAGEFN[CUR]();
  else if (CUR === 'pos') posLive();
  else if (CUR === 'events') evTable();
  else if (full && ['transactions', 'receipts', 'inventory', 'analytics'].includes(CUR)) PAGEFN[CUR]();
}
async function loadHealth() { try { H = await api('/health'); if (CUR === 'overview') PAGEFN.overview(); } catch (e) {} }

// ---------- shared widgets
const kpi = (n, v) => `<div class="kpi"><span>${n}</span><b>${v}</b></div>`;
const badge = s => `<span class="badge ${s}">${s}</span>`;
function pumpCard(p, ctl) {
  const t = p.txn, pct = t ? Math.min(100, 100 * t.volume_ml / t.max_ml) : 0;
  return `<div class="card st-${p.status}"><div class="row"><b>Pump ${p.number}</b>${badge(p.status)}</div>
  <small>${p.nozzles.map(n => `N${n.number} ${n.grade} @ ${M(n.price_minor)}`).join(' · ')}</small>
  ${t ? `<div class="big">${Lt(t.volume_ml)} L</div><div>${M(t.amount_minor)} ${S.station.currency}</div><div class="bar"><i style="width:${pct}%"></i></div>
  <small>${esc(t.id)} ${esc(t.vehicle || '')} ${t.status === 'FAULTED' ? '(awaiting reconcile)' : ''}</small>` : `<div class="big muted">—</div><small>${p.speed_lpm} L/min</small>`}
  ${ctl ? `<div class="row" style="margin-top:6px"><button class="sm bad" data-act="fault" data-id="${p.id}" data-kind="FAULT">Fault</button>
  <button class="sm bad" data-act="fault" data-id="${p.id}" data-kind="COMMUNICATION_LOSS">Comm loss</button>
  <button class="sm ok" data-act="recover" data-id="${p.id}">Recover</button></div>` : ''}</div>`;
}
const feedHtml = n => `<div class="feed">${feed.slice(0, n).map(e => `<div class="ev"><time>${T(e.ts)}</time><b>${e.type}</b> ${e.pump_id ? 'P' + e.pump_id : ''} ${e.transaction_id ? esc(e.transaction_id.slice(-8)) : ''}</div>`).join('') || '<small>Waiting for events…</small>'}</div>`;
const txTable = rows => `<div class="scroll"><table><tr><th>Transaction</th><th>Started (UTC)</th><th>Pump</th><th>Grade</th><th>Vehicle</th><th>Litres</th><th>Amount</th><th>Pay</th><th>Status</th><th>Receipt</th></tr>
 ${rows.map(r => `<tr><td>${esc(r.id)}</td><td>${esc((r.started_at || '').slice(0, 19).replace('T', ' '))}</td><td>${r.pump}</td><td>${r.grade}</td><td>${esc(r.vehicle || '')}</td><td>${Lt(r.volume_ml)}</td><td>${M(r.amount_minor)}</td><td>${r.payment}</td><td>${badge(r.status)}</td>
 <td>${r.receipt_no ? `<a href="/receipts/${r.receipt_no}" target="_blank">${r.receipt_no}</a>` : ''}</td></tr>`).join('') || '<tr><td colspan=10><small>None</small></td></tr>'}</table></div>`;
const V = h => { $('#view').innerHTML = h; };
function killCharts() { charts.forEach(c => c.destroy()); charts = []; }

// ---------- pages
const PAGEFN = {
  overview() {
    if (!S) return; const st = S.stats, c = S.pump_counts, lt = lat.length ? Math.round(lat.reduce((a, b) => a + b, 0) / lat.length) + ' ms' : '–';
    V(`<h2>Overview</h2><div class="kpis">${kpi('Litres today (UTC day)', Lt(st.volume_ml) + ' L')}${kpi('Value today', M(st.amount_minor) + ' ' + S.station.currency)}${kpi('Completed txns', st.count)}
    ${kpi('Active', c.active)}${kpi('Idle', c.idle)}${kpi('Offline', c.offline)}${kpi('Fault', c.fault)}${kpi('Uptime', H ? Math.floor(H.uptime_s / 60) + ' min' : '–')}
    ${kpi('Comms', $('#conn').textContent + (H ? ` · ${H.ws_clients} client(s)` : ''))}${kpi('Delivery latency (client)', lt)}${kpi('Server dispatch', H && H.server_dispatch_latency_ms.avg !== null ? H.server_dispatch_latency_ms.avg + ' ms' : '–')}</div>
    <div class="grid2"><section><h3>Dispensers</h3><div class="cards">${S.pumps.map(p => pumpCard(p)).join('')}</div></section><section><h3>Live event feed</h3>${feedHtml(30)}</section></div>
    <section><h3>Recent transactions</h3>${txTable(S.recent)}</section>`);
  },
  dispensers() { if (S) V(`<h2>Live Dispensers</h2><div class="cards">${S.pumps.map(p => pumpCard(p, true)).join('')}</div>
    <p><button data-act="reconcile">Reconcile interrupted transactions</button></p><div id="rec"></div>`); },
  forecourt() { if (S) V(`<h2>Virtual Forecourt</h2><div class="forecourt">${S.pumps.map(p => `<div class="island"><div class="canopy"></div>
    <div class="car">${p.txn && p.status === 'DISPENSING' ? '🚗' : p.status === 'FAULT' ? '⚠️' : ''}</div>${pumpCard(p)}</div>`).join('')}</div>`); },
  async pos() {
    S = S || await api('/state'); const vs = await api('/vehicles'), ops = (await api('/config')).operators;
    V(`<h2>POS / Cashier</h2><section><div class="form">
    <label>Dispenser<select id="pp">${S.pumps.map(p => `<option value="${p.id}" ${p.status !== 'IDLE' ? 'disabled' : ''}>Pump ${p.number} (${p.status})</option>`).join('')}</select></label>
    <label>Fuel grade<select id="pg"></select></label>
    <label>Vehicle registration<input id="pv" list="vl" placeholder="e.g. CAB-1234"><datalist id="vl">${vs.map(v => `<option value="${esc(v.reg)}">`).join('')}</datalist></label>
    <label>Customer type<select id="pc"><option value="WALK_IN">Walk-in</option><option value="ACCOUNT">Account</option><option value="FLEET">Fleet</option></select></label>
    <label>Operator<input id="po" list="ol" value="${esc(ops[0] || 'OP-01')}"><datalist id="ol">${ops.map(o => `<option value="${esc(o)}">`).join('')}</datalist></label>
    <label>Payment (not processed)<select id="py"><option>CASH</option><option>CARD</option><option>ACCOUNT</option></select></label>
    <label>Preset litres (optional)<input id="pl" type="number" min="0" step="0.5"></label>
    <button class="ok" data-act="start">Start simulated transaction</button></div><div id="posmsg" class="msg">${posMsg}</div></section><section><h3>Active transactions</h3><div id="poslive"></div></section>`);
    const fill = () => { const p = S.pumps.find(p => p.id == $('#pp').value); $('#pg').innerHTML = p ? p.nozzles.map(n => `<option value="${n.grade}">${n.grade} — ${n.grade_name} (${M(n.price_minor)})</option>`).join('') : ''; };
    $('#pp').onchange = fill; const first = S.pumps.find(p => p.status === 'IDLE'); if (first) $('#pp').value = first.id; fill(); posLive();
  },
  async transactions() {
    const st = $('#fs') ? $('#fs').value : '', rows = await api('/transactions?limit=300' + (st ? '&status=' + st : ''));
    V(`<h2>Transactions</h2><p><select id="fs" onchange="PAGEFN.transactions()"><option value="">All</option>${['RECEIPT_GENERATED','CANCELLED','FAULTED','DISPENSING'].map(s => `<option ${s === st ? 'selected' : ''}>${s}</option>`).join('')}</select></p><section>${txTable(rows)}</section>`);
  },
  async receipts() {
    const rows = await api('/receipts');
    V(`<h2>Receipts <small>(simulated test receipts)</small></h2><section><table><tr><th>Receipt</th><th>Created (UTC)</th><th>Transaction</th><th>Vehicle</th><th>Litres</th><th>Amount</th><th></th></tr>
    ${rows.map(r => `<tr><td>${r.receipt_no}</td><td>${r.created_at.slice(0, 19).replace('T', ' ')}</td><td>${esc(r.txn)}</td><td>${esc(r.vehicle || '')}</td><td>${Lt(r.volume_ml)}</td><td>${M(r.amount_minor)}</td>
    <td><a href="/receipts/${r.receipt_no}" target="_blank">Print view</a> · <a href="/api/receipts/${r.receipt_no}/pdf">PDF</a></td></tr>`).join('') || '<tr><td colspan=7><small>No receipts yet</small></td></tr>'}</table></section>`);
  },
  async vehicles() {
    const vs = await api('/vehicles');
    V(`<h2>Vehicles</h2><section><div class="form"><input type="hidden" id="vid"><label>Registration<input id="vr"></label><label>Category<select id="vc">${['Car','Van','Truck','Bus','Motorcycle','Three-wheeler','Unregistered'].map(c => `<option>${c}</option>`).join('')}</select></label>
    <label>Company / customer<input id="vu" value="Walk-in"></label><button class="ok" data-act="vsave">Save vehicle</button></div></section>
    <section><table><tr><th>Reg</th><th>Category</th><th>Customer</th><th>Txns</th><th>Litres</th><th>Spend</th><th></th></tr>${vs.map(v => `<tr><td>${esc(v.reg)}</td><td>${esc(v.category)}</td><td>${esc(v.customer)}</td><td>${v.transactions}</td><td>${Lt(v.volume_ml)}</td><td>${M(v.amount_minor)}</td>
    <td><button class="sm" data-act="vedit" data-id="${v.id}" data-reg="${esc(v.reg)}" data-cat="${esc(v.category)}" data-cu="${esc(v.customer)}">Edit</button> <button class="sm" data-act="vrep" data-id="${v.id}">Report</button></td></tr>`).join('')}</table></section><div id="vrep"></div>`);
  },
  async inventory() {
    const ts = await api('/tanks');
    V(`<h2>Inventory <small>(simulated tanks — not certified measurement)</small></h2><div class="cards">${ts.map(t => `<div class="card ${t.low ? 'st-FAULT' : 'st-IDLE'}"><div class="row"><b>${t.tank_code} · ${t.grade}</b>${t.low ? '<span class="badge FAULT">LOW STOCK</span>' : ''}</div>
    <div class="big">${Lt(t.stock_ml)} L</div><div class="bar ${t.low ? 'low' : 'ok'}"><i style="width:${100 * t.stock_ml / t.capacity_ml}%"></i></div><small>capacity ${Lt(t.capacity_ml)} L · alert ≤ ${Lt(t.low_threshold_ml)} L</small>
    <div style="margin-top:6px"><button class="sm" data-act="repl" data-id="${t.id}">Replenish…</button></div></div>`).join('')}</div>
    <p><button data-act="reconcile">Verify tank stock vs ledger</button></p><div id="rec"></div>`);
  },
  async analytics() {
    const per = $('#per') ? $('#per').value : 'day', a = await api('/analytics?period=' + per); killCharts(); const t = a.totals, c = a.cancellations;
    V(`<h2>Analytics</h2><p><select id="per" onchange="PAGEFN.analytics()">${['day','week','month'].map(p => `<option ${p === per ? 'selected' : ''}>${p}</option>`).join('')}</select> <small>from ${a.since} (UTC)</small></p>
    <div class="kpis">${kpi('Transactions', t.count)}${kpi('Litres', Lt(t.volume_ml))}${kpi('Value', M(t.amount_minor))}${kpi('Avg qty / txn', Lt(t.avg_volume_ml) + ' L')}${kpi('Cancelled', c.cancelled + ' (' + c.rate_pct + '%)')}</div>
    <div class="charts"><section><h3>Hourly litres</h3><canvas id="c1"></canvas></section><section><h3>Fuel grade (litres)</h3><canvas id="c2"></canvas></section><section><h3>Pump litres</h3><canvas id="c3"></canvas></section></div>
    <div class="grid2"><section><h3>Daily totals</h3><table><tr><th>Day</th><th>Txns</th><th>Litres</th><th>Amount</th></tr>${a.daily.map(d => `<tr><td>${d.day}</td><td>${d.n}</td><td>${Lt(d.volume_ml)}</td><td>${M(d.amount_minor)}</td></tr>`).join('')}</table></section>
    <section><h3>Vehicle-wise expenditure</h3><table><tr><th>Reg</th><th>Txns</th><th>Litres</th><th>Spend</th></tr>${a.by_vehicle.map(d => `<tr><td>${esc(d.reg)}</td><td>${d.n}</td><td>${Lt(d.volume_ml)}</td><td>${M(d.amount_minor)}</td></tr>`).join('')}</table></section></div>
    <section><h3>Pump statistics</h3><table><tr><th>Pump</th><th>Txns</th><th>Litres</th><th>Amount</th></tr>${a.by_pump.map(d => `<tr><td>${d.pump}</td><td>${d.n}</td><td>${Lt(d.volume_ml)}</td><td>${M(d.amount_minor)}</td></tr>`).join('')}</table></section>
    <section><h3>Cancellations by reason</h3>${c.reasons.map(r => `${esc(r.reason)}: ${r.n}`).join(' · ') || '<small>none</small>'}</section>`);
    if (typeof Chart === 'undefined') { document.querySelectorAll('.charts canvas').forEach(c => c.replaceWith(Object.assign(document.createElement('small'), {textContent: 'Chart.js CDN unavailable offline — see tables.'}))); return; }
    const mk = (id, type, labels, data) => charts.push(new Chart($(id), {type, data: {labels, datasets: [{data, backgroundColor: ['#3498db','#1abc9c','#f1c40f','#e74c3c','#9b59b6','#2ecc71']}]}, options: {plugins: {legend: {display: type === 'doughnut'}}, animation: false}}));
    mk('#c1', 'bar', a.hourly.map(h => h.hour + ':00'), a.hourly.map(h => h.volume_ml / 1000)); mk('#c2', 'doughnut', a.by_grade.map(g => g.grade), a.by_grade.map(g => g.volume_ml / 1000)); mk('#c3', 'bar', a.by_pump.map(p => 'P' + p.pump), a.by_pump.map(p => p.volume_ml / 1000));
  },
  async events() {
    const hist = await api('/events?latest=true&limit=200'); const seen = new Set(feed.map(e => e.seq)); hist.reverse().forEach(e => { if (!seen.has(e.seq)) feed.push(e); }); feed.sort((a, b) => b.seq - a.seq);
    V(`<h2>Event Logs</h2><p><select id="ef" onchange="evTable()"><option value="">All types</option>${[...new Set(feed.map(e => e.type))].sort().map(t => `<option>${t}</option>`).join('')}</select> <small>last_seq ${lastSeq} · reconnects resume from this sequence</small></p><section class="scroll" id="evt"></section>`); evTable();
  },
  async config() {
    const c = await api('/config'); S = S || await api('/state'); const tanks = await api('/tanks'), st = c.station, s = c.settings;
    V(`<h2>Station Configuration</h2><section><h3>Station</h3><div class="form" id="f-st"><label>Name<input data-k="name" value="${esc(st.name)}"></label><label>Address<input data-k="address" value="${esc(st.address)}"></label><label>Currency<input data-k="currency" value="${esc(st.currency)}"></label><button data-act="saveStation">Save</button></div></section>
    <section><h3>Fuel grades &amp; prices (per litre)</h3><div class="form">${c.grades.map(g => `<label>${g.code} ${esc(g.name)}<input class="gp" data-id="${g.id}" value="${(g.price_minor / 100).toFixed(2)}"></label>`).join('')}<button data-act="savePrices">Save prices</button></div></section>
    <section><h3>Pumps</h3><table><tr><th>#</th><th>Nozzles</th><th>Speed L/min</th><th>Max txn L</th><th>Available</th><th></th></tr>${S.pumps.map(p => `<tr data-pid="${p.id}"><td>${p.number}</td><td>${p.nozzles.map(n => n.grade).join(', ')}</td><td><input class="ps" size=5 value="${p.speed_lpm}"></td><td><input class="pm" size=5 value="${p.max_txn_ml / 1000}"></td><td><input class="pa" type="checkbox" ${p.available ? 'checked' : ''}></td><td><button class="sm" data-act="savePump" data-id="${p.id}">Save</button></td></tr>`).join('')}</table>
    <div class="form" style="margin-top:8px"><label>New pump nozzle 1<select id="np1">${c.grades.map(g => `<option>${g.code}</option>`).join('')}</select></label><label>Nozzle 2<select id="np2"><option value="">(none)</option>${c.grades.map(g => `<option>${g.code}</option>`).join('')}</select></label><button class="ok" data-act="addPump">Add pump</button></div></section>
    <section><h3>Tank capacities (litres)</h3><div class="form">${tanks.map(t => `<label>${t.tank_code} ${t.grade}<input class="tc" data-id="${t.id}" value="${t.capacity_ml / 1000}"></label>`).join('')}<button data-act="saveTanks">Save</button></div></section>
    <section><h3>Simulation</h3><div class="form" id="f-sim"><label>Mode<select data-k="sim_mode"><option ${s.sim_mode === 'manual' ? 'selected' : ''}>manual</option><option ${s.sim_mode === 'auto' ? 'selected' : ''}>auto</option></select></label>
    ${[['sim_speed','Dispensing speed multiplier'],['arrival_interval_s','Mean arrival interval (s)'],['max_concurrent','Max simultaneous txns'],['fault_rate','Fault probability / s'],['walkin_pct','Walk-in % (no reg)'],['hours_start','Operating hour start'],['hours_end','Operating hour end'],['seed','Random seed (blank = random)'],['grade_weights','Grade weights JSON e.g. {"LP92":3}']].map(([k, l]) => `<label>${l}<input data-k="${k}" value="${esc(s[k])}"></label>`).join('')}<button data-act="saveSim">Save simulation settings</button></div></section>`);
  }
};
function evTable() {
  const f = $('#ef') ? $('#ef').value : '', rows = feed.filter(e => !f || e.type === f).slice(0, 200);
  const el = $('#evt'); if (el) el.innerHTML = `<table><tr><th>Seq</th><th>Time (UTC)</th><th>Type</th><th>Pump</th><th>Transaction</th><th>Source</th><th>Payload</th></tr>${rows.map(e => `<tr><td>${e.seq}</td><td>${T(e.ts)}</td><td>${e.type}</td><td>${e.pump_id ?? ''}</td><td>${esc(e.transaction_id || '')}</td><td>${e.source}</td><td><small>${esc(JSON.stringify(e.payload))}</small></td></tr>`).join('')}</table>`;
}
function posLive() {
  const el = $('#poslive'); if (!el || !S) return; const act = S.pumps.filter(p => p.txn && ['AUTHORIZED', 'DISPENSING', 'FAULTED'].includes(p.txn.status));
  el.innerHTML = act.map(p => `<div class="row" style="margin-bottom:8px"><div style="flex:1">Pump ${p.number} · ${p.txn.grade} · ${esc(p.txn.vehicle || 'no reg')} · <b>${Lt(p.txn.volume_ml)} L</b> · ${M(p.txn.amount_minor)} ${badge(p.txn.status)}<div class="bar"><i style="width:${100 * p.txn.volume_ml / p.txn.max_ml}%"></i></div></div>
  <button class="ok" data-act="complete" data-id="${p.txn.id}">Complete &amp; receipt</button><button class="bad" data-act="cancel" data-id="${p.txn.id}">Cancel</button></div>`).join('') || '<small>No active transactions</small>';
}

// ---------- actions
const val = (r, sel) => [...r.querySelectorAll(sel)];
const ACTS = {
  async start() { const b = {pump_id: +$('#pp').value, grade: $('#pg').value, vehicle_reg: $('#pv').value || null, customer_type: $('#pc').value, operator: $('#po').value, payment: $('#py').value, preset_litres: $('#pl').value ? +$('#pl').value : null};
    const t = await api('/transactions', {method: 'POST', body: b}); posMsg = `Started ${t.id}`; $('#posmsg').textContent = posMsg; S = await api('/state'); posLive(); },
  async complete(d) { const t = await api(`/transactions/${d.id}/complete`, {method: 'POST'}); posMsg = ''; $('#posmsg').innerHTML = `Completed ${esc(t.id)} — receipt <a target="_blank" href="/receipts/${t.receipt_no}">${t.receipt_no}</a> · <a href="/api/receipts/${t.receipt_no}/pdf">PDF</a>`; scheduleRefresh(); },
  async cancel(d) { await api(`/transactions/${d.id}/cancel`, {method: 'POST'}); scheduleRefresh(); },
  async fault(d) { await api(`/pumps/${d.id}/fault`, {method: 'POST', body: {kind: d.kind}}); },
  async recover(d) { await api(`/pumps/${d.id}/recover`, {method: 'POST'}); },
  async reconcile() { const r = await api('/reconcile', {method: 'POST'}); const el = $('#rec'); if (el) el.innerHTML = `<section>Settled: ${r.settled.length} · Ledger ${r.consistent ? 'CONSISTENT' : 'MISMATCH'}<br>${r.tanks.map(t => `${t.tank}: stock ${Lt(t.stock_ml)} L / ledger ${Lt(t.ledger_ml)} L ${t.ok ? '✔' : '✘'}`).join('<br>')}</section>`; },
  async vsave() { const id = $('#vid').value, b = {reg: $('#vr').value, category: $('#vc').value, customer: $('#vu').value}; await api(id ? '/vehicles/' + id : '/vehicles', {method: id ? 'PUT' : 'POST', body: b}); PAGEFN.vehicles(); },
  vedit(d) { $('#vid').value = d.id; $('#vr').value = d.reg; $('#vc').value = d.cat; $('#vu').value = d.cu; },
  async vrep(d) { const r = await api(`/vehicles/${d.id}/report`); $('#vrep').innerHTML = `<section><h3>Report: ${esc(r.vehicle.reg)}</h3>Total ${Lt(r.total_volume_ml)} L · ${M(r.total_amount_minor)}<table><tr><th>Date</th><th>Grade</th><th>Litres</th><th>Amount</th><th>Receipt</th></tr>${r.transactions.map(t => `<tr><td>${t.completed_at.slice(0, 19)}</td><td>${t.grade}</td><td>${Lt(t.volume_ml)}</td><td>${M(t.amount_minor)}</td><td>${t.receipt_no}</td></tr>`).join('')}</table></section>`; },
  async repl(d) { const l = prompt('Litres to add (simulated delivery):', '5000'); if (l) { await api(`/tanks/${d.id}/replenish`, {method: 'POST', body: {litres: +l}}); PAGEFN.inventory(); } },
  async saveStation() { const b = {}; val(document, '#f-st [data-k]').forEach(i => b[i.dataset.k] = i.value); await api('/config/station', {method: 'PUT', body: b}); S = await api('/state'); alert('Saved'); },
  async savePrices() { for (const i of val(document, '.gp')) await api('/grades/' + i.dataset.id, {method: 'PUT', body: {price: i.value}}); S = await api('/state'); alert('Saved'); },
  async savePump(d) { const r = $(`tr[data-pid="${d.id}"]`); await api('/pumps/' + d.id, {method: 'PATCH', body: {speed_lpm: +r.querySelector('.ps').value, max_txn_litres: +r.querySelector('.pm').value, available: r.querySelector('.pa').checked}}); S = await api('/state'); alert('Saved'); },
  async addPump() { const g = [$('#np1').value, $('#np2').value].filter(Boolean); await api('/pumps', {method: 'POST', body: {grades: g}}); S = await api('/state'); PAGEFN.config(); },
  async saveTanks() { for (const i of val(document, '.tc')) await api('/tanks/' + i.dataset.id, {method: 'PUT', body: {capacity_litres: +i.value}}); alert('Saved'); },
  async saveSim() { const b = {}; val(document, '#f-sim [data-k]').forEach(i => b[i.dataset.k] = i.value); await api('/config/settings', {method: 'PUT', body: {settings: b}}); alert('Saved'); }
};
document.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b) guard(ACTS[b.dataset.act])(b.dataset); });

// ---------- router / boot
async function nav() {
  CUR = (location.hash || '#overview').slice(1); if (!PAGEFN[CUR]) CUR = 'overview'; killCharts();
  document.querySelectorAll('#links a').forEach(a => a.classList.toggle('on', a.dataset.p === CUR));
  try { S = S || await api('/state'); await PAGEFN[CUR](); } catch (e) { V(`<div class="msg">Error: ${esc(e.message)}</div>`); }
}
window.addEventListener('hashchange', nav);
(async () => { S = await api('/state'); lastSeq = Math.max(0, S.last_seq - 50); await loadHealth(); connect(); nav(); setInterval(loadHealth, 5000); })();
