const $ = id => document.getElementById(id);
const fmt = (v, digits=2) => v === null || v === undefined ? "—" : Number(v).toLocaleString(undefined,{maximumFractionDigits:digits});
const esc = v => String(v ?? "—").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function setConnection(ok){
  $("connection").textContent = ok ? "● MQTT CONNECTED" : "● DISCONNECTED";
  $("connection").style.color = ok ? "var(--green)" : "var(--red)";
  $("connection").style.borderColor = ok ? "#285b49" : "#56313c";
  $("connection").style.background = ok ? "#14251f" : "#251922";
  $("sideDot").style.background = ok ? "var(--green)" : "var(--red)";
  $("sideStatus").textContent = ok ? "SOURCE CONNECTED" : "SOURCE DISCONNECTED";
}
function age(v){return v == null ? "—" : `${fmt(v,1)} s`;}
function renderDashboard(d){
  setConnection(!!d.mqtt_connected);
  $("pumpCount").textContent=fmt(d.dispenser_count,0);
  $("liveCount").textContent=fmt(d.live_dispenser_count,0);
  $("txCount").textContent=fmt(d.completed_transaction_count,0);
  $("eventCount").textContent=fmt(d.event_count,0);
  $("brokerState").textContent=d.mqtt_connected?"Connected":"Disconnected";
  $("brokerState").className=d.mqtt_connected?"good":"bad";
  $("brokerHost").textContent=`${d.mqtt_host}:${d.mqtt_port}`;
  $("lastMessage").textContent=d.last_message_received||"No messages received";
  $("staleThreshold").textContent=`${d.stale_after_seconds}s`;
  $("uptime").textContent=`${fmt(d.uptime_seconds,0)}s`;
  $("sourceError").textContent=d.mqtt_error||"No source error reported.";
  $("pumpRows").innerHTML=d.dispensers.length?d.dispensers.map(p=>{
    const x=p.payload||{},live=p.freshness==="LIVE";
    return `<tr><td><b>${esc(p.dispenser_id)}</b></td><td>${esc(p.station_id)}</td><td class="state ${live?'good':'bad'}">${esc(x.status||p.freshness)}</td><td>${esc(x.grade)}</td><td>${fmt(x.litres,3)}</td><td>${fmt(x.amount)}</td><td class="${live?'good':'warn'}">${age(p.data_age_seconds)}</td></tr>`;
  }).join(""):`<tr><td colspan="7" class="empty">No dispenser telemetry received. Waiting for an external source…</td></tr>`;
}
async function loadTables(){
  try{
    const [tr,ev]=await Promise.all([fetch("/api/transactions").then(r=>r.json()),fetch("/api/events").then(r=>r.json())]);
    $("txRows").innerHTML=tr.length?tr.slice(0,12).map(t=>`<tr><td>${esc(t.transaction_id)}</td><td>${esc(t.dispenser_id)}</td><td>${fmt(t.litres,3)}</td><td>${fmt(t.amount)}</td></tr>`).join(""):`<tr><td colspan="4" class="empty">No completed transactions received.</td></tr>`;
    $("eventRows").innerHTML=ev.length?ev.slice(0,15).map(e=>`<tr><td>${esc(e.received_utc)}</td><td>${esc(e.event_type)}</td><td>${esc(e.station_id)}</td><td>${esc(e.dispenser_id)}</td><td>${esc(e.transaction_id)}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">No events received.</td></tr>`;
  }catch(e){}
}
async function refresh(){
  try{const r=await fetch("/api/dashboard",{cache:"no-store"});renderDashboard(await r.json());await loadTables();}
  catch(e){setConnection(false);}
}
function tick(){ $("clock").textContent=new Date().toISOString().replace("T"," ").slice(0,19)+" UTC"; }
tick();setInterval(tick,1000);refresh();setInterval(refresh,2000);
try{
  const scheme=location.protocol==="https:"?"wss":"ws";
  const ws=new WebSocket(`${scheme}://${location.host}/ws`);
  ws.onmessage=()=>refresh();
  ws.onclose=()=>setTimeout(()=>location.reload(),5000);
}catch(e){}
