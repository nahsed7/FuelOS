"""Persistent, ordered event bus. Source-agnostic: any DataSource publishes standardized events here."""
import asyncio
import json
import time
import uuid
from collections import deque

from app.database import utcnow


class EventBus:
    def __init__(self, db, source: str):
        self.db, self.source = db, source
        self.subs = set()
        self.latency_ms = deque(maxlen=200)  # server-side record->dispatch latency

    def record(self, type, pump_id=None, transaction_id=None, payload=None) -> dict:
        """Persist an event (caller controls commit so it can join a DB transaction). Call dispatch() after commit."""
        eid, ts, payload = str(uuid.uuid4()), utcnow(), payload or {}
        cur = self.db.execute(
            "INSERT INTO transaction_events(event_id,type,pump_id,transaction_id,ts,source,payload) VALUES(?,?,?,?,?,?,?)",
            (eid, type, pump_id, transaction_id, ts, self.source, json.dumps(payload)))
        return {"seq": cur.lastrowid, "event_id": eid, "type": type, "pump_id": pump_id,
                "transaction_id": transaction_id, "ts": ts, "source": self.source, "payload": payload,
                "_t": time.perf_counter()}

    def dispatch(self, events):
        for ev in events:
            self.latency_ms.append((time.perf_counter() - ev["_t"]) * 1000)
            out = {k: v for k, v in ev.items() if k != "_t"}
            for q in list(self.subs):
                q.put_nowait(out)

    def publish(self, type, pump_id=None, transaction_id=None, payload=None) -> dict:
        with self.db:
            ev = self.record(type, pump_id, transaction_id, payload)
        self.dispatch([ev])
        return ev

    def subscribe(self) -> asyncio.Queue:
        q = asyncio.Queue()
        self.subs.add(q)
        return q

    def unsubscribe(self, q):
        self.subs.discard(q)

    def history(self, after_seq=0, limit=1000, type=None) -> list:
        sql, args = "SELECT * FROM transaction_events WHERE seq>?", [after_seq]
        if type:
            sql += " AND type=?"
            args.append(type)
        rows = self.db.execute(sql + " ORDER BY seq LIMIT ?", args + [limit]).fetchall()
        return [{"seq": r["seq"], "event_id": r["event_id"], "type": r["type"], "pump_id": r["pump_id"],
                 "transaction_id": r["transaction_id"], "ts": r["ts"], "source": r["source"],
                 "payload": json.loads(r["payload"])} for r in rows]

    def last_seq(self) -> int:
        return self.db.execute("SELECT COALESCE(MAX(seq),0) FROM transaction_events").fetchone()[0]
