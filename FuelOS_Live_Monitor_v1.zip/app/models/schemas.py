"""Pydantic request models."""
from typing import Optional

from pydantic import BaseModel, Field


class StartTxn(BaseModel):
    pump_id: int
    grade: str
    vehicle_reg: Optional[str] = None
    customer_type: str = "WALK_IN"
    operator: str = "OP-01"
    payment: str = "CASH"
    preset_litres: Optional[float] = Field(default=None, gt=0)


class VehicleIn(BaseModel):
    reg: str
    category: str = "Car"
    customer: str = "Walk-in"


class FaultIn(BaseModel):
    kind: str = "FAULT"


class PumpIn(BaseModel):
    grades: list[str]
    speed_lpm: float = Field(default=40, gt=0)
    max_txn_litres: float = Field(default=60, gt=0)


class PumpPatch(BaseModel):
    speed_lpm: Optional[float] = Field(default=None, gt=0)
    max_txn_litres: Optional[float] = Field(default=None, gt=0)
    available: Optional[bool] = None


class StationIn(BaseModel):
    name: str
    address: str = ""
    currency: str = "LKR"


class PriceIn(BaseModel):
    price: str


class TankPatch(BaseModel):
    capacity_litres: float = Field(gt=0)


class ReplenishIn(BaseModel):
    litres: float = Field(gt=0)


class SettingsIn(BaseModel):
    settings: dict[str, str]
