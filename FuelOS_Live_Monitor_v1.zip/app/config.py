"""Runtime configuration (environment / .env)."""
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


def _load_env():
    f = BASE / ".env"
    if f.exists():
        for line in f.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()
HOST = os.getenv("FUELOS_HOST", "127.0.0.1")
PORT = int(os.getenv("FUELOS_PORT", "8000"))
ALLOW_LAN = os.getenv("FUELOS_ALLOW_LAN", "0") == "1"
_db = Path(os.getenv("FUELOS_DB", "data/fuelos.db"))
DB_PATH = _db if _db.is_absolute() else BASE / _db
TICK_SECONDS = 0.5
HEARTBEAT_SECONDS = 5.0


def check_bind(host: str = None, allow_lan: bool = None) -> str:
    """Refuse non-loopback binding unless LAN access was explicitly enabled."""
    host = host or HOST
    allow_lan = ALLOW_LAN if allow_lan is None else allow_lan
    if host not in ("127.0.0.1", "localhost", "::1") and not allow_lan:
        raise SystemExit(f"Refusing to bind to {host}: set FUELOS_ALLOW_LAN=1 to allow LAN access "
                         "(the app has no authentication; use only on a trusted network).")
    return host
