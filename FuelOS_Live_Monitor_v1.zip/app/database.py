"""SQLite schema, helpers and demo seed data. Money = integer minor units, volume = integer millilitres."""
import sqlite3
import sys
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS stations(id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '', currency TEXT NOT NULL DEFAULT 'LKR', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS fuel_grades(id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  price_minor INTEGER NOT NULL CHECK(price_minor>=0), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tanks(id INTEGER PRIMARY KEY, tank_code TEXT NOT NULL UNIQUE,
  grade_id INTEGER NOT NULL UNIQUE REFERENCES fuel_grades(id), capacity_ml INTEGER NOT NULL CHECK(capacity_ml>0),
  stock_ml INTEGER NOT NULL CHECK(stock_ml>=0), low_threshold_ml INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, CHECK(stock_ml<=capacity_ml));
CREATE TABLE IF NOT EXISTS pumps(id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL REFERENCES stations(id),
  number INTEGER NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'IDLE' CHECK(status IN('OFFLINE','IDLE','AUTHORIZED','DISPENSING','COMPLETED','FAULT','CANCELLED')),
  available INTEGER NOT NULL DEFAULT 1 CHECK(available IN(0,1)),
  speed_mlps INTEGER NOT NULL DEFAULT 667 CHECK(speed_mlps>0), max_txn_ml INTEGER NOT NULL DEFAULT 60000 CHECK(max_txn_ml>0),
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS nozzles(id INTEGER PRIMARY KEY, pump_id INTEGER NOT NULL REFERENCES pumps(id) ON DELETE CASCADE,
  number INTEGER NOT NULL, grade_id INTEGER NOT NULL REFERENCES fuel_grades(id), UNIQUE(pump_id,number));
CREATE TABLE IF NOT EXISTS vehicles(id INTEGER PRIMARY KEY, reg TEXT NOT NULL UNIQUE, category TEXT NOT NULL DEFAULT 'Car',
  customer TEXT NOT NULL DEFAULT 'Walk-in', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS operators(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS transactions(id TEXT PRIMARY KEY, pump_id INTEGER NOT NULL REFERENCES pumps(id),
  nozzle_id INTEGER NOT NULL REFERENCES nozzles(id), grade_id INTEGER NOT NULL REFERENCES fuel_grades(id),
  vehicle_id INTEGER REFERENCES vehicles(id), operator_id INTEGER NOT NULL REFERENCES operators(id),
  customer_type TEXT NOT NULL CHECK(customer_type IN('WALK_IN','ACCOUNT','FLEET')),
  payment TEXT NOT NULL CHECK(payment IN('CASH','CARD','ACCOUNT')),
  status TEXT NOT NULL CHECK(status IN('AUTHORIZED','DISPENSING','COMPLETED','POS_RECORDED','RECEIPT_GENERATED','CANCELLED','FAULTED')),
  price_minor INTEGER NOT NULL CHECK(price_minor>=0), volume_ml INTEGER NOT NULL DEFAULT 0 CHECK(volume_ml>=0),
  amount_minor INTEGER NOT NULL DEFAULT 0 CHECK(amount_minor>=0), max_ml INTEGER NOT NULL CHECK(max_ml>0),
  started_at TEXT NOT NULL, completed_at TEXT, cancelled_reason TEXT);
CREATE INDEX IF NOT EXISTS ix_tx_status ON transactions(status);
CREATE INDEX IF NOT EXISTS ix_tx_pump ON transactions(pump_id);
CREATE INDEX IF NOT EXISTS ix_tx_vehicle ON transactions(vehicle_id);
CREATE INDEX IF NOT EXISTS ix_tx_completed ON transactions(completed_at);
CREATE TABLE IF NOT EXISTS transaction_events(seq INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL, pump_id INTEGER, transaction_id TEXT, ts TEXT NOT NULL, source TEXT NOT NULL, payload TEXT NOT NULL DEFAULT '{}');
CREATE INDEX IF NOT EXISTS ix_ev_type ON transaction_events(type);
CREATE INDEX IF NOT EXISTS ix_ev_tx ON transaction_events(transaction_id);
CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY, receipt_no TEXT NOT NULL UNIQUE,
  transaction_id TEXT NOT NULL UNIQUE REFERENCES transactions(id), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS inventory_movements(id INTEGER PRIMARY KEY, tank_id INTEGER NOT NULL REFERENCES tanks(id),
  transaction_id TEXT REFERENCES transactions(id), kind TEXT NOT NULL CHECK(kind IN('OPENING','SALE','REPLENISH')),
  delta_ml INTEGER NOT NULL, balance_ml INTEGER NOT NULL, ts TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_inv_tank ON inventory_movements(tank_id);
CREATE TABLE IF NOT EXISTS station_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""

DEFAULT_SETTINGS = {"sim_mode": "manual", "sim_speed": "3", "arrival_interval_s": "8", "max_concurrent": "3",
                    "fault_rate": "0", "seed": "", "hours_start": "0", "hours_end": "24",
                    "walkin_pct": "30", "grade_weights": "{}"}


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def money(volume_ml: int, price_minor: int) -> int:
    """Amount in minor units for volume_ml at price_minor per litre (integer arithmetic, half-up)."""
    return (volume_ml * price_minor + 500) // 1000


def fmt_money(minor: int) -> str:
    sign, m = ("-" if minor < 0 else ""), abs(minor)
    return f"{sign}{m // 100:,}.{m % 100:02d}"


def connect(path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    if str(path) != ":memory:":
        conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db(conn):
    conn.executescript(SCHEMA)


def get_setting(db, key, default=""):
    r = db.execute("SELECT value FROM station_settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else DEFAULT_SETTINGS.get(key, default)


def set_setting(db, key, value):
    with db:
        db.execute("INSERT INTO station_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                   (key, str(value)))


def seed_demo(db):
    """Idempotent demo data. Prices are DEMO values only."""
    if db.execute("SELECT COUNT(*) FROM stations").fetchone()[0]:
        return
    t = utcnow()
    with db:
        db.execute("INSERT INTO stations(code,name,address,currency,created_at) VALUES('FOS-SIM-001','FuelOS Demo Station (SIMULATED)','1 Demo Road, Negombo','LKR',?)", (t,))
        grades = [("LP92", "Petrol 92", 30900), ("LP95", "Petrol 95", 37100),
                  ("AD", "Auto Diesel", 28900), ("SD", "Super Diesel", 36100)]
        for c, n, p in grades:
            db.execute("INSERT INTO fuel_grades(code,name,price_minor,created_at) VALUES(?,?,?,?)", (c, n, p, t))
        gid = {r["code"]: r["id"] for r in db.execute("SELECT id,code FROM fuel_grades")}
        for i, (c, cap, stock) in enumerate([("LP92", 20000000, 15000000), ("LP95", 10000000, 7000000),
                                             ("AD", 20000000, 14000000), ("SD", 10000000, 6000000)], 1):
            db.execute("INSERT INTO tanks(tank_code,grade_id,capacity_ml,stock_ml,low_threshold_ml,created_at) VALUES(?,?,?,?,?,?)",
                       (f"TK-{i}", gid[c], cap, stock, cap // 10, t))
            tid = db.execute("SELECT id FROM tanks WHERE tank_code=?", (f"TK-{i}",)).fetchone()[0]
            db.execute("INSERT INTO inventory_movements(tank_id,kind,delta_ml,balance_ml,ts) VALUES(?,?,?,?,?)",
                       (tid, "OPENING", stock, stock, t))
        layout = {1: ["LP92", "AD"], 2: ["LP92", "AD"], 3: ["LP95", "SD"], 4: ["LP92", "LP95"]}
        for num, codes in layout.items():
            db.execute("INSERT INTO pumps(station_id,number,created_at) VALUES(1,?,?)", (num, t))
            pid = db.execute("SELECT id FROM pumps WHERE number=?", (num,)).fetchone()[0]
            for n, c in enumerate(codes, 1):
                db.execute("INSERT INTO nozzles(pump_id,number,grade_id) VALUES(?,?,?)", (pid, n, gid[c]))
        for reg, cat, cust in [("CAB-1234", "Car", "Walk-in"), ("WP KA-5678", "Van", "Lanka Logistics"),
                               ("NB-4321", "Truck", "Lanka Logistics"), ("LJ-9087", "Motorcycle", "Walk-in"),
                               ("PA-2210", "Bus", "City Transit"), ("KV-7765", "Car", "Walk-in")]:
            db.execute("INSERT INTO vehicles(reg,category,customer,created_at) VALUES(?,?,?,?)", (reg, cat, cust, t))
        for n in ("OP-01 Kasun", "OP-02 Nimali", "OP-03 Ruwan"):
            db.execute("INSERT INTO operators(name) VALUES(?)", (n,))
        for k, v in DEFAULT_SETTINGS.items():
            db.execute("INSERT OR IGNORE INTO station_settings(key,value) VALUES(?,?)", (k, v))


if __name__ == "__main__":
    from app import config
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = connect(config.DB_PATH)
    init_db(c)
    seed_demo(c)
    print("Database ready:", config.DB_PATH)
