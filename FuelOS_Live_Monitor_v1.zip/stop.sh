#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ -f data/fuelos.pid ] && kill "$(cat data/fuelos.pid)" 2>/dev/null; then rm -f data/fuelos.pid; echo "FuelOS stopped."; else echo "FuelOS not running."; fi
