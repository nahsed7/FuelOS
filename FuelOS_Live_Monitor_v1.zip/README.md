# FuelOS — simulated fuel station + live monitoring

**Simulation software only.** No real dispenser connection, payment processing or hardware control. Every receipt/UI view is labelled simulated.

## Install / run / test
```
./install.sh        # venv, deps, DB init + demo data
./run.sh            # http://127.0.0.1:8000
./stop.sh
python -m unittest discover -s tests -v
```
LAN access: set `FUELOS_ALLOW_LAN=1` and `FUELOS_HOST=0.0.0.0` in `.env`. There is **no authentication** — trusted networks only.
Termux: `pkg install python rust binutils` (pydantic-core builds from source) or use `pkg install python-pydantic`.

## Layout
`app/simulator` engine + DataSource interface (`SimulatedDataSource`, `FutureReadOnlyStationDataSource` placeholder) · `app/events` persisted ordered event bus ·
`app/services` receipts/reports · `app/main.py` REST + `/ws` · `app/static`, `app/templates` UI · `tests/`.

## Design notes
- Money: integer minor units; volume: integer millilitres; `amount = round_half_up(ml × price/L ÷ 1000)`.
- Events carry `seq` (SQLite AUTOINCREMENT), UUID `event_id`, UTC `ts`, `source`. `/ws?since=N` replays missed events from the DB, then streams live; clients drop `seq <= last`.
- Completion (tank deduction, ledger row, POS record, receipt) is one SQLite transaction. Tank stock is reserved per active transaction so concurrent pumps cannot oversell.
- Cancelling mid-dispense records the partial volume but charges and deducts nothing (simulated policy). Fault/comm-loss freezes the transaction as FAULTED; **Reconcile** settles it (complete if volume > 0, else cancel) once the pump has recovered.
- Latency shown = client clock − server UTC stamp (needs synced clocks) plus server record→dispatch time. Not zero.
