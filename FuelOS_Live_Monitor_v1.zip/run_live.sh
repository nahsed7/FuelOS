#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
source .venv/bin/activate
mkdir -p data
exec python -m app.live_main
