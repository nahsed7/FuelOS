# FuelStationLab

Three separate components:

- virtual-dispenser: independent virtual station and dispenser.
- fuelos: live MQTT monitoring application; no simulator or fake-data fallback.
- machine-protocol: shared message contract.

The virtual dispenser publishes messages. FuelOS consumes messages.
Neither application imports the other's internal code.

Development broker: local Mosquitto on 127.0.0.1:1883.
