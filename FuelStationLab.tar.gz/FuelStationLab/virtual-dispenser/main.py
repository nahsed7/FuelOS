import asyncio
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

STATION = os.getenv("STATION_ID", "STATION-01")
PUMP = "PUMP-01"
BROKER = os.getenv("MQTT_HOST", "127.0.0.1")
PORT = int(os.getenv("MQTT_PORT", "1883"))

app = FastAPI(title="Virtual Dispenser")
state = {
    "status": "IDLE",
    "transaction_id": None,
    "grade": None,
    "unit_price": 0.0,
    "litres": 0.0,
    "amount": 0.0,
    "target_litres": 20.0,
    "totalizer_litres": 12500.0,
    "flow_lpm": 35.0,
    "last_receipt": None,
}
sequence = 0
mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)


def now():
    return datetime.now(timezone.utc).isoformat()


def publish(event_type, payload):
    global sequence
    sequence += 1
    message = {
        "schema_version": "1.0",
        "station_id": STATION,
        "source_id": "VIRTUAL-DISPENSER-01",
        "event_id": str(uuid.uuid4()),
        "sequence": sequence,
        "event_type": event_type,
        "timestamp_utc": now(),
        "dispenser_id": PUMP,
        "payload": payload,
    }
    topic = f"station/{STATION}/dispenser/{PUMP}/telemetry"
    if event_type != "telemetry":
        topic = f"station/{STATION}/dispenser/{PUMP}/events"
    try:
        mqtt_client.publish(topic, json.dumps(message), qos=1)
    except Exception as exc:
        print("MQTT publish error:", exc)


def snapshot():
    return dict(state)


@app.on_event("startup")
async def startup():
    mqtt_client.connect_async(BROKER, PORT, 60)
    mqtt_client.loop_start()
    asyncio.create_task(engine())


@app.on_event("shutdown")
async def shutdown():
    mqtt_client.loop_stop()
    mqtt_client.disconnect()


async def engine():
    while True:
        if state["status"] == "DISPENSING":
            increment = state["flow_lpm"] / 60
            state["litres"] = round(state["litres"] + increment, 3)
            state["totalizer_litres"] = round(
                state["totalizer_litres"] + increment, 3
            )
            state["amount"] = round(
                state["litres"] * state["unit_price"], 2
            )

            if state["litres"] >= state["target_litres"]:
                state["litres"] = state["target_litres"]
                state["amount"] = round(
                    state["litres"] * state["unit_price"], 2
                )
                state["status"] = "COMPLETED"
                receipt = {
                    "receipt_number": "TEST-" + str(uuid.uuid4())[:8].upper(),
                    "transaction_id": state["transaction_id"],
                    "station_id": STATION,
                    "dispenser_id": PUMP,
                    "fuel_grade": state["grade"],
                    "litres": state["litres"],
                    "unit_price": state["unit_price"],
                    "total": state["amount"],
                    "timestamp_utc": now(),
                    "notice": "SIMULATED RECEIPT — NOT VALID FOR PAYMENT",
                }
                state["last_receipt"] = receipt
                publish("dispensing_completed", receipt)

        publish("telemetry", snapshot())
        await asyncio.sleep(1)


class StartRequest(BaseModel):
    grade: str = "Diesel"
    unit_price: float = 320.0
    target_litres: float = 20.0


@app.get("/api/state")
def get_state():
    return snapshot()


@app.post("/api/start")
def start(request: StartRequest):
    if state["status"] == "DISPENSING":
        return {"ok": False, "error": "Dispenser is already dispensing"}
    if request.unit_price <= 0 or request.target_litres <= 0:
        return {"ok": False, "error": "Price and target litres must be positive"}

    state.update({
        "status": "DISPENSING",
        "transaction_id": str(uuid.uuid4()),
        "grade": request.grade,
        "unit_price": request.unit_price,
        "litres": 0.0,
        "amount": 0.0,
        "target_litres": request.target_litres,
    })
    publish("dispensing_started", snapshot())
    return {"ok": True, "state": snapshot()}


@app.post("/api/stop")
def stop():
    if state["status"] != "DISPENSING":
        return {"ok": False, "error": "No active dispensing transaction"}
    state["status"] = "CANCELLED"
    publish("dispensing_cancelled", snapshot())
    return {"ok": True, "state": snapshot()}


@app.get("/api/receipt")
def receipt():
    return state["last_receipt"] or {"message": "No completed transaction yet"}


@app.get("/", response_class=HTMLResponse)
def home():
    return HTML

HTML = """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Virtual Dispenser</title>
<style>
body{font:16px Arial;background:#101923;color:#edf3f8;margin:30px}
main{max-width:850px;margin:auto}.panel{background:#1c2b3a;padding:22px;
border-radius:12px;margin:15px 0}button,input,select{padding:12px;margin:5px;
border-radius:6px;border:0}button{cursor:pointer;background:#27b48b;color:#071b16}
.stop{background:#e36b6b;color:#210909}pre{white-space:pre-wrap}
.big{font-size:32px;font-weight:bold}.muted{color:#a9bac8}
</style></head><body><main>
<h1>Virtual Fuel Dispenser</h1>
<p class="muted">Independent simulator · All transactions and receipts are simulated</p>
<div class="panel"><div class="muted">DISPENSER STATUS</div>
<div id="status" class="big">Connecting...</div>
<p>Volume: <b id="litres">0</b> L</p>
<p>Amount: <b id="amount">0</b></p>
<p>Totalizer: <b id="totalizer">0</b> L</p>
<p>Transaction: <span id="tx">—</span></p></div>
<div class="panel"><h2>Start a transaction</h2>
<label>Fuel grade <select id="grade"><option>Diesel</option>
<option>Petrol 92</option><option>Petrol 95</option></select></label>
<label>Price per litre <input id="price" type="number" value="320"></label>
<label>Target litres <input id="target" type="number" value="20"></label>
<button onclick="start()">Start dispensing</button>
<button class="stop" onclick="stop()">Stop / cancel</button>
</div>
<div class="panel"><h2>Last receipt</h2><pre id="receipt">No receipt yet</pre></div>
</main><script>
async function refresh(){
 try{
  const r=await fetch('/api/state');const s=await r.json();
  document.getElementById('status').textContent=s.status;
  document.getElementById('litres').textContent=s.litres.toFixed(3);
  document.getElementById('amount').textContent=s.amount.toFixed(2);
  document.getElementById('totalizer').textContent=s.totalizer_litres.toFixed(3);
  document.getElementById('tx').textContent=s.transaction_id||'—';
  const q=await fetch('/api/receipt');const rec=await q.json();
  document.getElementById('receipt').textContent=JSON.stringify(rec,null,2);
 }catch(e){document.getElementById('status').textContent='APPLICATION ERROR';}
}
async function start(){
 const body={grade:document.getElementById('grade').value,
 unit_price:Number(document.getElementById('price').value),
 target_litres:Number(document.getElementById('target').value)};
 const r=await fetch('/api/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 const x=await r.json();if(!x.ok)alert(x.error);refresh();
}
async function stop(){
 const r=await fetch('/api/stop',{method:'POST'});const x=await r.json();
 if(!x.ok)alert(x.error);refresh();
}
setInterval(refresh,500);refresh();
</script></body></html>
"""
