# FuelStationLab Machine Protocol

Protocol version: 1.0
Transport: MQTT
Encoding: UTF-8 JSON
QoS: 1

Topics:
station/{station_id}/dispenser/{dispenser_id}/telemetry
station/{station_id}/dispenser/{dispenser_id}/events

Required envelope fields:
- schema_version
- station_id
- source_id
- event_id
- sequence
- event_type
- timestamp_utc
- dispenser_id
- payload

FuelOS accepts schema version 1.0 only.
event_id must be unique.
sequence is monotonically increasing per source.
timestamp_utc is the source event timestamp.
FuelOS separately records its own receive timestamp.

Important:
MQTT is the laboratory integration transport, not a claim that
physical fuel dispensers natively speak MQTT. A real installation
requires a manufacturer-approved interface and qualified integration.
