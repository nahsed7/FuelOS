import json
import os
import sqlite3
import threading
from datetime import datetime, timezone

import paho.mqtt.client as mqtt
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

BROKER = os.getenv("MQTT_HOST", "127.0.0.1")
PORT = int(os.getenv("MQTT_PORT", "1883"))
DB = os.getenv("FUELOS_DB", "fuelos.db")

app = FastAPI(title="FuelOS Live Monitoring")
lock = threading.Lock()
connected = False
last_message_received = None

db = sqlite3.connect(DB, check_same_thread=False)
db.row_factory = sqlite3.Row

with db:
    db.execute("""
        CREATE TABLE IF NOT EXISTS events(
            event_id TEXT PRIMARY KEY,
            station_id TEXT,
            source_id TEXT,
            sequence INTEGER,
            event_type TEXT,
            timestamp_utc TEXT,
            received_utc TEXT,
            topic TEXT,
            payload TEXT
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS latest_dispenser(
            dispenser_id TEXT PRIMARY KEY,
            station_id TEXT,
            source_id TEXT,
            event_timestamp TEXT,
            received_timestamp TEXT,
            payload TEXT
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS transactions(
            transaction_id TEXT PRIMARY KEY,
            station_id TEXT,
            dispenser_id TEXT,
            completed_timestamp TEXT,
            receipt_data TEXT
        )
    """)


def utcnow():
    return datetime.now(timezone.utc)


def on_connect(client, userdata, flags, reason_code, properties):
    global connected
    connected = (reason_code == 0)
    if connected:
        client.subscribe("station/+/dispenser/+/telemetry", qos=1)
        client.subscribe("station/+/dispenser/+/events", qos=1)
        print("FuelOS connected to MQTT; subscribed to station feeds")
    else:
        print("MQTT connection rejected:", reason_code)


def on_disconnect(client, userdata, disconnect_flags, reason_code, properties):
    global connected
    connected = False
    print("MQTT disconnected:", reason_code)


def on_message(client, userdata, message):
    global last_message_received
    received = utcnow().isoformat()

    try:
        data = json.loads(message.payload.decode("utf-8"))
        required = [
            "schema_version", "station_id", "source_id", "event_id",
            "sequence", "event_type", "timestamp_utc",
            "dispenser_id", "payload"
        ]
        if not all(key in data for key in required):
            print("Rejected message: missing required fields")
            return
        if data["schema_version"] != "1.0":
            print("Rejected unsupported schema:", data["schema_version"])
            return
        if not isinstance(data["payload"], dict):
            print("Rejected message: payload must be an object")
            return

        with lock:
            cursor = db.execute("""
                INSERT OR IGNORE INTO events
                (event_id,station_id,source_id,sequence,event_type,
                 timestamp_utc,received_utc,topic,payload)
                VALUES(?,?,?,?,?,?,?,?,?)
            """, (
                data["event_id"], data["station_id"], data["source_id"],
                data["sequence"], data["event_type"], data["timestamp_utc"],
                received, message.topic, json.dumps(data["payload"])
            ))

            # A duplicate event ID is ignored.
            if cursor.rowcount == 0:
                return

            last_message_received = received

            if data["event_type"] == "telemetry":
                db.execute("""
                    INSERT INTO latest_dispenser
                    (dispenser_id,station_id,source_id,event_timestamp,
                     received_timestamp,payload)
                    VALUES(?,?,?,?,?,?)
                    ON CONFLICT(dispenser_id) DO UPDATE SET
                    station_id=excluded.station_id,
                    source_id=excluded.source_id,
                    event_timestamp=excluded.event_timestamp,
                    received_timestamp=excluded.received_timestamp,
                    payload=excluded.payload
                """, (
                    data["dispenser_id"], data["station_id"],
                    data["source_id"], data["timestamp_utc"],
                    received, json.dumps(data["payload"])
                ))

            if data["event_type"] == "dispensing_completed":
                p = data["payload"]
                txid = p.get("transaction_id")
                if txid:
                    db.execute("""
                        INSERT OR IGNORE INTO transactions
                        (transaction_id,station_id,dispenser_id,
                         completed_timestamp,receipt_data)
                        VALUES(?,?,?,?,?)
                    """, (
                        txid, data["station_id"], data["dispenser_id"],
                        data["timestamp_utc"], json.dumps(p)
                    ))
            db.commit()

    except Exception as exc:
        print("Message processing error:", exc)


client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_disconnect = on_disconnect
client.on_message = on_message


@app.on_event("startup")
async def startup():
    client.connect_async(BROKER, PORT, 60)
    client.loop_start()


@app.on_event("shutdown")
async def shutdown():
    client.loop_stop()
    client.disconnect()
    db.close()


@app.get("/api/dashboard")
def dashboard():
    with lock:
        rows = db.execute(
            "SELECT * FROM latest_dispenser ORDER BY dispenser_id"
        ).fetchall()
        tx_count = db.execute(
            "SELECT COUNT(*) FROM transactions"
        ).fetchone()[0]
        event_count = db.execute(
            "SELECT COUNT(*) FROM events"
        ).fetchone()[0]

    dispensers = []
    now = utcnow()
    for row in rows:
        received = datetime.fromisoformat(row["received_timestamp"])
        age = max(0, (now - received).total_seconds())
        payload = json.loads(row["payload"])
        dispensers.append({
            "dispenser_id": row["dispenser_id"],
            "station_id": row["station_id"],
            "source_id": row["source_id"],
            "data_age_seconds": round(age, 1),
            "freshness": "LIVE" if age <= 5 else "STALE",
            "event_timestamp": row["event_timestamp"],
            "payload": payload,
        })

    return {
        "mqtt_connected": connected,
        "last_message_received": last_message_received,
        "event_count": event_count,
        "completed_transaction_count": tx_count,
        "dispensers": dispensers,
    }


@app.get("/api/events")
def events(limit: int = 100):
    limit = max(1, min(limit, 500))
    with lock:
        rows = db.execute(
            "SELECT * FROM events ORDER BY received_utc DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [dict(row) for row in rows]


@app.get("/api/transactions")
def transactions(limit: int = 100):
    limit = max(1, min(limit, 500))
    with lock:
        rows = db.execute(
            "SELECT * FROM transactions ORDER BY completed_timestamp DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [dict(row) for row in rows]


@app.get("/", response_class=HTMLResponse)
def home():
    return HTML

HTML = open("dashboard.html", encoding="utf-8").read()
