"use strict";

const { SimulationAdapter } = require("./simulation-adapter");
const { PhysicalAdapter } = require("./physical-adapter");
const { SOURCE } = require("../telemetry/schema");

/** Exactly one adapter feeds the store — simulation and physical data never mix. */
function createAdapter(source, store) {
  if (source === SOURCE.SIMULATION) return new SimulationAdapter(store);
  if (source === SOURCE.PHYSICAL) return new PhysicalAdapter(store);
  throw new Error(`DATA_SOURCE must be "simulation" or "physical" (got "${source}")`);
}

module.exports = { createAdapter };
