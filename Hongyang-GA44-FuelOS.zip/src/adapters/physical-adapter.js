"use strict";

const { STATUS } = require("../telemetry/schema");
const { physical, positionIds, runtime } = require("../config");
const log = require("../logger").child("physical");

/**
 * PhysicalAdapter — READ-ONLY integration point for the real
 * Hongyang CMD1687SK-GA44.
 *
 * STATUS: NOT IMPLEMENTED. Hongyang does not publish the dispenser's
 * communication protocol. Until a manufacturer-documented interface (or a
 * documented forecourt-controller API) is obtained, this adapter does NOT
 * open any port, does NOT generate data, and reports "not_configured".
 *
 * Safety rules enforced here (see docs/PHYSICAL_INTEGRATION.md):
 *   - read-only: every command is rejected;
 *   - no start/stop, preset, price change, relay/valve/motor control;
 *   - no calibration writes;
 *   - only documented decoders may be registered.
 *
 * To complete it, implement a decoder with the interface below and register
 * it in DECODERS. The decoder must translate frames into the canonical
 * telemetry schema (src/telemetry/schema.js) and must never transmit
 * anything other than the documented read/poll requests.
 *
 *   interface Decoder {
 *     name: string;                       // documented protocol name + version
 *     documentation: string;              // reference to the manufacturer document
 *     open(transportConfig, onFrame, onError): Promise<void>;   // read-only link
 *     close(): Promise<void>;
 *     decode(frame): { [positionId]: rawPosition } | null;
 *   }
 */
const DECODERS = {
  // e.g. "hongyang-<doc-version>": require("./decoders/hongyang-<doc-version>")
};

class ReadOnlyError extends Error {
  constructor() {
    super("Physical device mode is READ-ONLY: control commands are disabled");
    this.status = 403;
  }
}

class PhysicalAdapter {
  constructor(store) {
    this.store = store;
    this.kind = "physical";
    this.readOnly = true;
    this.decoder = null;
  }

  async start() {
    // Publish an explicit OFFLINE state — never fabricated readings.
    const offline = Object.fromEntries(positionIds.map(id => [id, { status: STATUS.OFFLINE }]));
    this.store.ingest(offline, { settings: { currency: "—", nominalFlowLpm: null, products: {} } });
    this.store.connection.lastDataAt = null; // seeding is not device data

    const factory = DECODERS[physical.protocol];
    if (!physical.protocol || !factory) {
      const detail = physical.protocol
        ? `No documented decoder registered for protocol "${physical.protocol}"`
        : "No documented dispenser protocol configured (PHYSICAL_PROTOCOL unset)";
      this.store.setConnection("not_configured", detail);
      log.warn(`${detail}. No data will be shown. See docs/PHYSICAL_INTEGRATION.md`);
      return;
    }

    this.decoder = factory;
    this.store.setConnection("connecting", `${factory.name} via ${physical.transport}`);
    try {
      await this.decoder.open(physical, frame => this.onFrame(frame), err => this.onError(err));
      this.store.setConnection("connected", `${factory.name} via ${physical.transport}`);
    } catch (err) {
      this.onError(err);
    }
  }

  onFrame(frame) {
    const decoded = this.decoder.decode(frame);
    if (decoded) this.store.ingest(decoded);
  }

  onError(err) {
    log.error("Physical link error", err);
    this.store.setConnection("disconnected", err.message);
    // Reconnect with back-off; reads only.
    clearTimeout(this.retry);
    this.retry = setTimeout(() => this.start(), Math.max(runtime.staleAfterMs, 5000));
  }

  stop() {
    clearTimeout(this.retry);
    return this.decoder?.close?.();
  }

  command() {
    throw new ReadOnlyError();
  }

  updateSettings() {
    throw new ReadOnlyError();
  }

  describe() {
    return {
      kind: this.kind,
      readOnly: true,
      implemented: Boolean(this.decoder),
      transport: physical.transport || null,
      protocol: physical.protocol || null,
      registeredDecoders: Object.keys(DECODERS)
    };
  }
}

module.exports = { PhysicalAdapter, ReadOnlyError };
