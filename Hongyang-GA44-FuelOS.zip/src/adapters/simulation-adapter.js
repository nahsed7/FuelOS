"use strict";

const crypto = require("crypto");
const { STATUS, round } = require("../telemetry/schema");
const { positions: positionMeta, positionIds, initialTotalizers, simulationDefaults, runtime } = require("../config");
const { JsonFile } = require("../persistence");
const log = require("../logger").child("sim");

class CommandError extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
  }
}

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/**
 * SimulationAdapter — generates SIMULATED telemetry for the four GA44
 * positions. Volume is integrated from flow rate, amount derives from
 * volume × the unit price locked at session start, and the totalizer
 * increments by exactly the dispensed volume, so all figures stay consistent.
 */
class SimulationAdapter {
  constructor(store) {
    this.store = store;
    this.kind = "simulation";
    this.readOnly = false;
    this.file = new JsonFile(runtime.dataDir, "simulator-state.json");
    this.dirty = false;
    this.timer = null;
    this.saveTimer = null;
    this.lastTick = Date.now();
    this.t0 = Date.now();

    const saved = this.file.load() || {};
    this.settings = {
      ...structuredClone(simulationDefaults),
      ...(saved.settings || {}),
      products: { ...structuredClone(simulationDefaults.products), ...(saved.settings?.products || {}) }
    };

    this.state = {};
    for (const id of positionIds) {
      this.state[id] = {
        status: STATUS.IDLE,
        nozzleLifted: false,
        volume: 0,
        amount: 0,
        flowRate: 0,
        unitPrice: this.priceFor(id),
        totalizer: Number(saved.totalizers?.[id] ?? initialTotalizers[id]),
        preset: null,
        sessionId: null,
        sessionStartedAt: null,
        sessionStartMs: 0,
        activeMs: 0,          // accumulated dispensing time for ramp-up
        runSinceMs: 0,
        totalizerAtStart: 0,
        fault: null,
        phase: (positionIds.indexOf(id) + 1) * 1.7
      };
    }
    store.transactions = Array.isArray(saved.transactions) ? saved.transactions : [];
  }

  priceFor(id) {
    return this.settings.products[positionMeta[id].product].unitPrice;
  }

  start() {
    this.store.setConnection("simulated", "Internal simulation engine — no physical device");
    this.publish();
    this.timer = setInterval(() => this.tick(), runtime.tickMs);
    this.saveTimer = setInterval(() => this.persist(), 5000);
    log.info("Simulation adapter started (SIMULATED telemetry)");
  }

  stop() {
    clearInterval(this.timer);
    clearInterval(this.saveTimer);
    this.persist(true);
  }

  persist(force = false) {
    if (!this.dirty && !force) return;
    this.dirty = false;
    this.file.save({
      savedAt: new Date().toISOString(),
      note: "SIMULATED values — not readings from the physical dispenser",
      settings: this.settings,
      totalizers: Object.fromEntries(positionIds.map(id => [id, this.state[id].totalizer])),
      transactions: this.store.transactions
    });
  }

  // ---------------------------------------------------------------- physics

  pumpLoad() {
    const load = {};
    for (const id of positionIds) {
      const pump = positionMeta[id].pump;
      load[pump] = (load[pump] || 0) + (this.state[id].status === STATUS.DISPENSING ? 1 : 0);
    }
    return load;
  }

  tick() {
    const now = Date.now();
    const dt = clamp((now - this.lastTick) / 1000, 0, 2);
    this.lastTick = now;
    const load = this.pumpLoad();
    const t = (now - this.t0) / 1000;

    for (const id of positionIds) {
      const s = this.state[id];
      if (s.status !== STATUS.DISPENSING) {
        s.flowRate = 0;
        continue;
      }
      s.activeMs += dt * 1000;

      // Nominal flow, shared-pump derating, solenoid soft-start ramp and a
      // small smooth (deterministic) hydraulic variation.
      let flow = this.settings.nominalFlowLpm;
      if (load[positionMeta[id].pump] > 1) flow *= this.settings.sharedPumpFlowFactor;
      const ramp = clamp((now - s.runSinceMs) / 1000 / this.settings.rampSeconds, 0.08, 1);
      flow *= ramp;
      flow *= 1 + 0.012 * Math.sin(t * 0.9 + s.phase) + 0.007 * Math.sin(t * 2.3 + s.phase * 2);

      const targetVolume = this.presetVolume(s);
      if (targetVolume != null && targetVolume - s.volume < this.settings.slowdownLitres) {
        flow *= this.settings.slowdownFactor;
      }

      let added = (flow / 60) * dt;
      if (targetVolume != null && s.volume + added >= targetVolume) {
        added = Math.max(0, targetVolume - s.volume);
      }

      s.flowRate = flow;
      s.volume += added;
      s.totalizer += added;
      // Amount is computed from the metered volume at 0.001 L resolution so
      // volume × unit price always reproduces the displayed amount.
      s.amount = round(round(s.volume, 3) * s.unitPrice, 2);
      this.dirty = true;

      if (targetVolume != null && s.volume >= targetVolume - 1e-9) {
        this.complete(id, "preset_reached");
      }
    }
    this.publish();
  }

  presetVolume(s) {
    if (!s.preset) return null;
    return s.preset.type === "amount" ? s.preset.value / s.unitPrice : s.preset.value;
  }

  publish() {
    const now = Date.now();
    const raw = {};
    for (const id of positionIds) {
      const s = this.state[id];
      raw[id] = {
        ...s,
        sessionDurationS: s.sessionStartMs ? (now - s.sessionStartMs) / 1000 : 0,
        lastUpdate: new Date(now).toISOString()
      };
      if ([STATUS.COMPLETED, STATUS.IDLE].includes(s.status) && s.sessionEndMs) {
        raw[id].sessionDurationS = (s.sessionEndMs - s.sessionStartMs) / 1000;
      }
    }
    const pumps = {};
    for (const id of positionIds) {
      const { pump, product } = positionMeta[id];
      pumps[pump] ??= { id: pump, product, productName: this.settings.products[product].name, serves: [], running: false };
      pumps[pump].serves.push(id);
      if (this.state[id].status === STATUS.DISPENSING) pumps[pump].running = true;
    }
    this.store.ingest(raw, { pumps, settings: this.settings });
  }

  // --------------------------------------------------------------- commands

  /** Executes a simulator command. Throws CommandError when not allowed. */
  command(id, action, body = {}) {
    const s = this.state[id];
    if (!s) throw new CommandError(`Unknown dispensing position "${id}"`, 404);
    const handler = {
      lift: () => this.lift(id),
      hang: () => this.hang(id),
      start: () => this.startSession(id, body.preset),
      pause: () => this.pause(id),
      resume: () => this.resume(id),
      stop: () => this.complete(id, "operator_stop"),
      reset: () => this.reset(id),
      fault: () => this.fault(id, body.code),
      "clear-fault": () => this.clearFault(id),
      offline: () => this.setOffline(id),
      online: () => this.setOnline(id)
    }[action];
    if (!handler) throw new CommandError(`Unknown action "${action}"`, 400);
    handler();
    log.info(`${id} ← ${action}${body.preset ? ` preset=${JSON.stringify(body.preset)}` : ""} → ${s.status}`);
    this.publish();
    return s.status;
  }

  assertUsable(id) {
    const s = this.state[id];
    if (s.status === STATUS.OFFLINE) throw new CommandError(`${id} is offline`);
    if (s.status === STATUS.FAULT) throw new CommandError(`${id} is in fault (${s.fault?.code}); clear the fault first`);
  }

  lift(id) {
    const s = this.state[id];
    this.assertUsable(id);
    if (s.nozzleLifted) return;
    s.nozzleLifted = true;
    // Lifting the nozzle clears the previous sale from the display.
    Object.assign(s, {
      status: STATUS.NOZZLE_REMOVED, volume: 0, amount: 0, flowRate: 0, preset: null,
      sessionId: null, sessionStartedAt: null, sessionStartMs: 0, sessionEndMs: 0,
      unitPrice: this.priceFor(id)
    });
  }

  hang(id) {
    const s = this.state[id];
    if (!s.nozzleLifted) return;
    if (s.status === STATUS.DISPENSING || s.status === STATUS.PAUSED) this.complete(id, "nozzle_hung_up");
    s.nozzleLifted = false;
    if (s.status !== STATUS.FAULT && s.status !== STATUS.OFFLINE) s.status = STATUS.IDLE;
  }

  startSession(id, preset) {
    const s = this.state[id];
    this.assertUsable(id);
    if (!s.nozzleLifted) throw new CommandError(`${id}: lift the nozzle before authorising`);
    if (s.status === STATUS.DISPENSING) throw new CommandError(`${id} is already dispensing`);
    if (s.status === STATUS.PAUSED) return this.resume(id);

    let parsedPreset = null;
    if (preset && Number(preset.value) > 0) {
      parsedPreset = { type: preset.type === "amount" ? "amount" : "volume", value: Number(preset.value) };
    }
    const now = Date.now();
    Object.assign(s, {
      status: STATUS.DISPENSING,
      volume: 0, amount: 0,
      unitPrice: this.priceFor(id),              // price locked for the session
      preset: parsedPreset,
      sessionId: `SIM-${id}-${now.toString(36).toUpperCase()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`,
      sessionStartedAt: new Date(now).toISOString(),
      sessionStartMs: now, sessionEndMs: 0,
      runSinceMs: now, activeMs: 0,
      totalizerAtStart: s.totalizer
    });
  }

  pause(id) {
    const s = this.state[id];
    if (s.status !== STATUS.DISPENSING) throw new CommandError(`${id} is not dispensing`);
    s.status = STATUS.PAUSED;
    s.flowRate = 0;
  }

  resume(id) {
    const s = this.state[id];
    if (s.status !== STATUS.PAUSED) throw new CommandError(`${id} is not paused`);
    s.status = STATUS.DISPENSING;
    s.runSinceMs = Date.now();
  }

  complete(id, reason) {
    const s = this.state[id];
    if (s.status !== STATUS.DISPENSING && s.status !== STATUS.PAUSED) {
      if (reason === "operator_stop") throw new CommandError(`${id} has no active sale to stop`);
      return;
    }
    const now = Date.now();
    s.status = STATUS.COMPLETED;
    s.flowRate = 0;
    s.sessionEndMs = now;
    this.dirty = true;
    if (s.volume > 0) {
      this.store.addTransaction({
        id: s.sessionId,
        position: id,
        side: positionMeta[id].side,
        product: positionMeta[id].product,
        productName: this.settings.products[positionMeta[id].product].name,
        volume: round(s.volume, 3),
        amount: round(s.amount, 2),
        unitPrice: s.unitPrice,
        currency: this.settings.currency,
        preset: s.preset,
        startedAt: s.sessionStartedAt,
        endedAt: new Date(now).toISOString(),
        durationS: round((now - s.sessionStartMs) / 1000, 1),
        totalizerStart: round(s.totalizerAtStart, 3),
        totalizerEnd: round(s.totalizer, 3),
        endReason: reason,
        source: "simulation"
      });
    }
  }

  reset(id) {
    const s = this.state[id];
    if (s.status === STATUS.DISPENSING || s.status === STATUS.PAUSED) this.complete(id, "reset");
    Object.assign(s, {
      status: s.status === STATUS.OFFLINE ? STATUS.OFFLINE : STATUS.IDLE,
      nozzleLifted: false, volume: 0, amount: 0, flowRate: 0, preset: null, fault: null,
      sessionId: null, sessionStartedAt: null, sessionStartMs: 0, sessionEndMs: 0
    });
  }

  fault(id, code = "E-SIM-01") {
    const s = this.state[id];
    if (s.status === STATUS.DISPENSING || s.status === STATUS.PAUSED) this.complete(id, "fault");
    s.status = STATUS.FAULT;
    s.flowRate = 0;
    s.fault = { code: String(code).slice(0, 24), message: "Simulated fault (injected from FuelOS)", at: new Date().toISOString() };
  }

  clearFault(id) {
    const s = this.state[id];
    if (s.status !== STATUS.FAULT) throw new CommandError(`${id} has no active fault`);
    s.fault = null;
    s.status = s.nozzleLifted ? STATUS.NOZZLE_REMOVED : STATUS.IDLE;
  }

  setOffline(id) {
    const s = this.state[id];
    if (s.status === STATUS.DISPENSING || s.status === STATUS.PAUSED) this.complete(id, "offline");
    s.status = STATUS.OFFLINE;
    s.flowRate = 0;
  }

  setOnline(id) {
    const s = this.state[id];
    if (s.status !== STATUS.OFFLINE) return;
    s.status = s.nozzleLifted ? STATUS.NOZZLE_REMOVED : STATUS.IDLE;
  }

  updateSettings({ nominalFlowLpm, products, positionId, price } = {}) {
    if (nominalFlowLpm !== undefined) {
      const v = Number(nominalFlowLpm);
      if (!Number.isFinite(v)) throw new CommandError("nominalFlowLpm must be a number", 400);
      this.settings.nominalFlowLpm = clamp(v, this.settings.minFlowLpm, this.settings.maxFlowLpm);
    }
    // Legacy form: price per channel → applies to that channel's product.
    if (positionId && positionMeta[positionId] && price !== undefined) {
      products = { ...(products || {}), [positionMeta[positionId].product]: { unitPrice: price } };
    }
    for (const [pid, p] of Object.entries(products || {})) {
      const target = this.settings.products[pid];
      if (!target) throw new CommandError(`Unknown product "${pid}"`, 400);
      if (p.unitPrice !== undefined) {
        const v = Number(p.unitPrice);
        if (!Number.isFinite(v) || v < 0 || v > 100000) throw new CommandError("unitPrice out of range", 400);
        target.unitPrice = round(v, 2);
      }
      if (typeof p.name === "string" && p.name.trim()) target.name = p.name.trim().slice(0, 32);
    }
    // Idle positions pick up a new price immediately; active sales keep their locked price.
    for (const id of positionIds) {
      const s = this.state[id];
      if (s.status !== STATUS.DISPENSING && s.status !== STATUS.PAUSED) s.unitPrice = this.priceFor(id);
    }
    this.dirty = true;
    log.info("Settings updated", { nominalFlowLpm: this.settings.nominalFlowLpm, products: this.settings.products });
    this.publish();
  }

  describe() {
    return { kind: this.kind, readOnly: this.readOnly, tickMs: runtime.tickMs, persistence: this.file.file };
  }
}

module.exports = { SimulationAdapter, CommandError };
