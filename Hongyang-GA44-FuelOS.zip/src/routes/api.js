"use strict";

const express = require("express");
const { positions: positionMeta, equipment, DATA_SOURCE } = require("../config");
const logger = require("../logger");

const log = logger.child("api");

/**
 * REST API. All reads come from the TelemetryStore; all writes go through
 * the active adapter (which rejects them in read-only physical mode).
 */
function createApiRouter({ store, adapter, broadcast, getClientCount, startedAt }) {
  const router = express.Router();

  const pos = req => String(req.params.id || "").toUpperCase();

  function run(res, fn) {
    try {
      const result = fn();
      broadcast();
      res.json({ ok: true, ...result, state: store.snapshot() });
    } catch (err) {
      const status = err.status || 500;
      if (status >= 500) log.error("Command failed", err);
      res.status(status).json({ ok: false, message: err.message, state: store.snapshot() });
    }
  }

  // ---------------------------------------------------------------- reads
  router.get("/state", (req, res) => res.json(store.snapshot()));

  router.get("/equipment", (req, res) =>
    res.json({ equipment, positions: positionMeta, dataSource: DATA_SOURCE, adapter: adapter.describe() }));

  router.get("/transactions", (req, res) => {
    const limit = Math.min(Number(req.query.limit) || 100, 500);
    const filter = String(req.query.position || "").toUpperCase();
    const list = store.transactions.filter(t => !filter || t.position === filter).slice(0, limit);
    res.json({ source: store.source, simulated: store.source === "simulation", count: list.length, transactions: list });
  });

  router.get("/diagnostics", (req, res) => res.json({
    startedAt,
    uptimeS: Math.round(process.uptime()),
    node: process.version,
    memoryMb: Math.round(process.memoryUsage().rss / 1048576),
    dataSource: store.source,
    adapter: adapter.describe(),
    connection: store.connection,
    socketClients: getClientCount(),
    telemetrySeq: store.seq,
    logs: logger.recent().slice(-120)
  }));

  // ------------------------------------------------- commands (simulation)
  router.post("/positions/:id/:action", (req, res) =>
    run(res, () => ({ status: adapter.command(pos(req), req.params.action, req.body || {}) })));

  router.post("/settings", (req, res) => run(res, () => {
    const b = req.body || {};
    adapter.updateSettings({
      nominalFlowLpm: b.nominalFlowLpm ?? b.flowRateLpm,         // legacy: flowRateLpm
      products: b.products,
      positionId: b.channel ? String(b.channel).toUpperCase() : undefined, // legacy: channel + price
      price: b.price
    });
    return {};
  }));

  // ---------------------------------------- legacy FuelOS endpoints (kept)
  router.post("/start/:id", (req, res) => run(res, () => {
    const id = pos(req);
    const p = store.positions[id];
    if (p && !p.nozzleLifted) adapter.command(id, "lift");
    return { status: adapter.command(id, "start", req.body || {}), message: "Simulation started" };
  }));
  router.post("/stop/:id", (req, res) => run(res, () => ({ status: adapter.command(pos(req), "stop") })));
  router.post("/reset-session/:id", (req, res) => run(res, () => ({ status: adapter.command(pos(req), "reset") })));

  router.use((req, res) => res.status(404).json({ ok: false, message: `No API route ${req.method} ${req.path}` }));
  return router;
}

module.exports = { createApiRouter };
