"use strict";

/**
 * Equipment identity and configuration for the Hongyang CMD1687SK-GA44.
 *
 * Every value is tagged with its provenance:
 *   CONFIRMED  – from the dispenser nameplate (owner supplied) or the
 *                manufacturer's A-Series product table
 *                (https://www.chinahongyang.com/fuel-dispensers/a-series/).
 *   ESTIMATE   – engineering estimate, NOT verified against the physical unit.
 *   SETTING    – operator-configurable simulation setting.
 */

const DATA_SOURCE = (process.env.DATA_SOURCE || "simulation").toLowerCase();

const equipment = {
  manufacturer: "Hongyang",                 // CONFIRMED (nameplate)
  series: "A Series",                       // CONFIRMED (manufacturer catalogue lists GA44 in A Series)
  model: "CMD1687SK-GA44",                  // CONFIRMED (nameplate)
  serial: "21051034",                       // CONFIRMED (nameplate)
  configuration: "GA44",                    // CONFIRMED
  operatingSides: ["A", "B"],               // CONFIRMED
  // Manufacturer A-Series table, row CMD1687SK-GA44 (CONFIRMED):
  hardware: {
    products: 2,
    pumps: 2,
    flowmeters: 4,
    nozzles: 4,
    mainboards: 2,
    keyboards: 4,
    displays: 4
  },
  // ESTIMATES – not published by the manufacturer for this model.
  estimates: {
    dimensionsMm: { width: 1060, depth: 520, heightToCanopy: 2520 },
    hoseHang: "High-hang from canopy (matches A-Series catalogue photo)",
    pumpAssignment:
      "One suction pump per product. Each pump feeds one flowmeter per side " +
      "(Pump 1 → A1 + B1, Pump 2 → A2 + B2). Verify against the hydraulic " +
      "schematic / nozzle-grade labels on the unit.",
    mainboardAssignment: "One mainboard per side (A-side: A1, A2 · B-side: B1, B2).",
    sharedPumpFlowFactor:
      "When both meters on one pump dispense together each receives ~80% of nominal flow."
  }
};

// ESTIMATE: position → product/pump/mainboard mapping (see equipment.estimates).
const positions = {
  A1: { side: "A", index: 1, product: "P1", pump: "PUMP-1", mainboard: "MB-A", meter: "FM-A1" },
  A2: { side: "A", index: 2, product: "P2", pump: "PUMP-2", mainboard: "MB-A", meter: "FM-A2" },
  B1: { side: "B", index: 1, product: "P1", pump: "PUMP-1", mainboard: "MB-B", meter: "FM-B1" },
  B2: { side: "B", index: 2, product: "P2", pump: "PUMP-2", mainboard: "MB-B", meter: "FM-B2" }
};

// Owner-supplied initial totalizer readings (used to seed the simulator only).
const initialTotalizers = { A1: 777.166, A2: 777.583, B1: 780.641, B2: 776.158 };

// SETTING – simulation defaults (overridable via Settings page / API).
const simulationDefaults = {
  currency: "LKR",
  nominalFlowLpm: 50,          // catalogue listing range for this model: 5–50 L/min
  minFlowLpm: 5,
  maxFlowLpm: 60,
  rampSeconds: 1.6,            // soft-start of solenoid valve (estimate)
  slowdownLitres: 0.5,         // pre-set slow-down zone (estimate)
  slowdownFactor: 0.3,
  sharedPumpFlowFactor: 0.8,
  products: {
    P1: { name: "Product 1", unitPrice: 300.0 },
    P2: { name: "Product 2", unitPrice: 300.0 }
  }
};

const runtime = {
  port: Number(process.env.PORT) || 3000,
  host: process.env.HOST || "0.0.0.0",
  tickMs: 250,
  staleAfterMs: Number(process.env.STALE_AFTER_MS) || 5000,
  dataDir: process.env.DATA_DIR || require("path").join(__dirname, "..", "data"),
  logLevel: process.env.LOG_LEVEL || "info"
};

// Physical-device settings. Nothing here is used unless DATA_SOURCE=physical,
// and even then the adapter is READ-ONLY and refuses to run without a
// documented protocol decoder (see docs/PHYSICAL_INTEGRATION.md).
const physical = {
  transport: process.env.PHYSICAL_TRANSPORT || "",        // "serial" | "tcp" (when documented)
  serialPath: process.env.PHYSICAL_SERIAL_PATH || "",       // e.g. /dev/ttyUSB0 via RS-485 converter
  baudRate: Number(process.env.PHYSICAL_BAUD) || 0,
  tcpHost: process.env.PHYSICAL_TCP_HOST || "",
  tcpPort: Number(process.env.PHYSICAL_TCP_PORT) || 0,
  protocol: process.env.PHYSICAL_PROTOCOL || ""             // name of a documented decoder module
};

module.exports = {
  DATA_SOURCE,
  equipment,
  positions,
  positionIds: Object.keys(positions),
  initialTotalizers,
  simulationDefaults,
  runtime,
  physical
};
