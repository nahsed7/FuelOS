"use strict";

const log = require("../logger").child("monitor");

/**
 * Watches the store for data freshness. If the active adapter stops
 * delivering telemetry for longer than `staleAfterMs`, every position is
 * marked OFFLINE so no view keeps showing old numbers as if they were live.
 */
function startConnectionMonitor(store, { staleAfterMs }) {
  let wasStale = false;
  const timer = setInterval(() => {
    const last = store.connection.lastDataAt ? Date.parse(store.connection.lastDataAt) : 0;
    const stale = !last || Date.now() - last > staleAfterMs;
    if (stale && !store.connection.stale) {
      if (!wasStale) log.warn(`No telemetry for >${staleAfterMs} ms — positions marked OFFLINE`);
      store.markStale();
    } else if (!stale && wasStale) {
      log.info("Telemetry resumed");
    }
    wasStale = stale;
  }, 1000);
  return () => clearInterval(timer);
}

module.exports = { startConnectionMonitor };
