"use strict";

const EventEmitter = require("events");
const { normalizePosition, SOURCE, STATUS } = require("./schema");
const { equipment, positions: positionMeta, positionIds } = require("../config");

/**
 * TelemetryStore — the single source of truth for dispenser state.
 *
 * Exactly one adapter (simulation OR physical) writes into the store. The
 * HTTP API, Socket.IO broadcast, dashboard and 3D twin all read from it, so
 * every view always shows the same data.
 */
class TelemetryStore extends EventEmitter {
  constructor(source) {
    super();
    if (!Object.values(SOURCE).includes(source)) throw new Error(`Unknown data source "${source}"`);
    this.source = source;
    this.seq = 0;
    this.positions = {};
    this.pumps = {};
    this.settings = {};
    this.transactions = [];
    this.connection = { state: "initialising", detail: "", lastDataAt: null, stale: false };
    for (const id of positionIds) {
      this.positions[id] = normalizePosition(id, { status: STATUS.OFFLINE }, positionMeta[id]);
    }
  }

  /** Adapter → store: replace position telemetry with freshly normalised data. */
  ingest(rawPositions, { pumps, settings } = {}) {
    for (const [id, raw] of Object.entries(rawPositions)) {
      if (!positionMeta[id]) continue;
      this.positions[id] = normalizePosition(id, raw, positionMeta[id]);
    }
    if (pumps) this.pumps = pumps;
    if (settings) this.settings = settings;
    this.connection.lastDataAt = new Date().toISOString();
    this.connection.stale = false;
    this.seq++;
    this.emit("change");
  }

  setConnection(state, detail = "") {
    if (this.connection.state === state && this.connection.detail === detail) return;
    this.connection = { ...this.connection, state, detail };
    this.seq++;
    this.emit("connection", this.connection);
    this.emit("change");
  }

  /** Connection monitor: no data for too long → every position is OFFLINE. */
  markStale() {
    if (this.connection.stale) return;
    this.connection.stale = true;
    for (const id of positionIds) {
      this.positions[id] = { ...this.positions[id], status: STATUS.OFFLINE, flowRate: 0 };
    }
    this.seq++;
    this.emit("change");
  }

  addTransaction(tx) {
    this.transactions.unshift(tx);
    if (this.transactions.length > 500) this.transactions.length = 500;
    this.emit("transaction", tx);
  }

  snapshot() {
    const simulated = this.source === SOURCE.SIMULATION;
    const legacyChannels = Object.fromEntries(
      Object.values(this.positions).map(p => [p.id, {
        pump: p.pump,
        totalizer: p.totalizer,
        volume: p.volume,
        price: p.unitPrice,
        amount: p.amount,
        active: p.status === STATUS.DISPENSING
      }])
    );

    return {
      seq: this.seq,
      timestamp: new Date().toISOString(),
      source: this.source,
      simulated,
      dataLabel: simulated ? "SIMULATED" : "PHYSICAL (READ-ONLY)",
      commandsEnabled: simulated,
      connection: this.connection,
      equipment,
      settings: this.settings,
      pumps: this.pumps,
      positions: this.positions,
      // Legacy fields kept so the original FuelOS client/API consumers keep working.
      brand: equipment.manufacturer,
      model: equipment.model,
      serial: equipment.serial,
      mode: simulated ? "SIMULATION ONLY" : "PHYSICAL READ-ONLY",
      flowRateLpm: this.settings.nominalFlowLpm,
      channels: legacyChannels
    };
  }
}

module.exports = { TelemetryStore };
