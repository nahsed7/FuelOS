"use strict";

/**
 * Canonical (normalised) telemetry schema shared by every adapter.
 * Adapters must convert their native data into these shapes before handing
 * them to the TelemetryStore; the frontend only ever sees this format.
 */

const STATUS = Object.freeze({
  IDLE: "idle",
  NOZZLE_REMOVED: "nozzle_removed",
  DISPENSING: "dispensing",
  PAUSED: "paused",
  COMPLETED: "completed",
  FAULT: "fault",
  OFFLINE: "offline"
});

const STATUS_VALUES = new Set(Object.values(STATUS));

const SOURCE = Object.freeze({
  SIMULATION: "simulation",
  PHYSICAL: "physical"
});

const round = (n, dp) => {
  const f = 10 ** dp;
  return Math.round((Number(n) || 0) * f) / f;
};

function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

/**
 * Normalise one dispensing position. Unknown/missing fields are filled with
 * safe defaults; values are rounded to the precision the dispenser displays.
 */
function normalizePosition(id, raw, meta) {
  const status = STATUS_VALUES.has(raw.status) ? raw.status : STATUS.OFFLINE;
  return {
    id,
    side: meta.side,
    product: meta.product,
    pump: meta.pump,
    mainboard: meta.mainboard,
    status,
    nozzleLifted: Boolean(raw.nozzleLifted),
    volume: round(raw.volume, 3),           // litres, current session
    amount: round(raw.amount, 2),           // currency, current session
    unitPrice: round(raw.unitPrice, 2),     // currency per litre
    flowRate: round(raw.flowRate, 2),       // L/min, instantaneous
    totalizer: round(raw.totalizer, 3),     // litres, electronic totalizer
    preset: raw.preset == null ? null : {
      type: raw.preset.type === "amount" ? "amount" : "volume",
      value: round(raw.preset.value, 2)
    },
    sessionId: raw.sessionId || null,
    sessionStartedAt: raw.sessionStartedAt || null,
    sessionDurationS: round(raw.sessionDurationS, 1),
    fault: raw.fault || null,
    lastUpdate: raw.lastUpdate || new Date().toISOString()
  };
}

module.exports = { STATUS, SOURCE, normalizePosition, round, num };
