"use strict";

const fs = require("fs");
const path = require("path");
const log = require("./logger").child("persistence");

/**
 * Tiny JSON-file persistence (atomic write via rename). Used by the
 * simulator so totalizers, prices and the transaction log survive restarts.
 */
class JsonFile {
  constructor(dir, name) {
    this.file = path.join(dir, name);
    fs.mkdirSync(dir, { recursive: true });
  }

  load() {
    try {
      return JSON.parse(fs.readFileSync(this.file, "utf8"));
    } catch (err) {
      if (err.code !== "ENOENT") log.warn(`Could not read ${this.file}; starting fresh`, err);
      return null;
    }
  }

  save(data) {
    const tmp = `${this.file}.tmp`;
    try {
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      log.error(`Failed to write ${this.file}`, err);
    }
  }
}

module.exports = { JsonFile };
