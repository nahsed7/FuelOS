"use strict";

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const RING_SIZE = 300;

const ring = [];
let threshold = LEVELS.info;
let sink = null;

function setLevel(level) {
  threshold = LEVELS[level] ?? LEVELS.info;
}

/** Optional subscriber (used to stream recent log lines to the Diagnostics page). */
function onEntry(fn) {
  sink = fn;
}

function write(level, scope, message, meta) {
  if (LEVELS[level] < threshold) return;
  const entry = { ts: new Date().toISOString(), level, scope, message };
  if (meta !== undefined) entry.meta = meta instanceof Error ? meta.message : meta;
  ring.push(entry);
  if (ring.length > RING_SIZE) ring.shift();

  const line = `${entry.ts} ${level.toUpperCase().padEnd(5)} [${scope}] ${message}`;
  const out = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
  meta === undefined ? out(line) : out(line, entry.meta);
  if (sink) sink(entry);
}

function child(scope) {
  return {
    debug: (m, meta) => write("debug", scope, m, meta),
    info: (m, meta) => write("info", scope, m, meta),
    warn: (m, meta) => write("warn", scope, m, meta),
    error: (m, meta) => write("error", scope, m, meta)
  };
}

module.exports = { child, setLevel, onEntry, recent: () => ring.slice() };
