# Physical integration — Hongyang CMD1687SK-GA44 (READ-ONLY)

**Status: NOT CONNECTED.** No hardware link is implemented. The manufacturer does
not publish this dispenser's communication protocol, so FuelOS does not claim one.

## Architecture
```
 [Simulation adapter]  ─┐                       ┌─> REST /api/*        ─┐
                        ├─> TelemetryStore ─────┤                        ├─> Dashboard + 3D twin
 [Physical adapter]    ─┘  (single source,      └─> Socket.IO "telemetry"┘
   └ documented decoder     normalised schema)
 Connection monitor: no data for STALE_AFTER_MS → all positions OFFLINE
```
- `src/adapters/simulation-adapter.js` — SIMULATED telemetry (default).
- `src/adapters/physical-adapter.js` — read-only scaffold. Every command → HTTP 403.
  Without a registered decoder it opens no port and reports `not_configured`.
- `src/telemetry/schema.js` — canonical schema all adapters must emit.
- `src/telemetry/connection-monitor.js` — stale-data detection.
- `src/logger.js` — logging (also shown on the Diagnostics page).
- Exactly one adapter runs per process (`DATA_SOURCE`), so simulated and physical data never mix.

## Safety rules (enforced)
Read-only. No start/stop, preset, price, relay, valve, motor or pump control. No calibration
writes. No bypass of safety systems. No reverse-engineered protocols — only manufacturer-
documented decoders. Installation only by a qualified dispenser technician with owner authorisation.

## Information still required
1. Hongyang protocol document for this unit's controller/mainboards (frame format, addressing, polling, status codes, totalizer read).
2. Physical interface on MB-A / MB-B (RS-485 / RS-232 / current loop / Ethernet) and connector pin-out.
3. Whether a forecourt controller / POS is already connected, and its documented API (often the safest read path).
4. Pump addresses and nozzle numbering configured on each mainboard.
5. Confirmed product-to-nozzle and pump-to-meter assignment (the current mapping is an estimate: Pump 1 → A1+B1, Pump 2 → A2+B2).
6. Isolation requirements for hazardous-area wiring (ATEX/IECEx barrier).

## Adding a decoder (once documentation exists)
Implement the `Decoder` interface described in `physical-adapter.js` and register it in `DECODERS`, then:
```
DATA_SOURCE=physical PHYSICAL_PROTOCOL=<name> PHYSICAL_TRANSPORT=serial PHYSICAL_SERIAL_PATH=/dev/ttyUSB0 PHYSICAL_BAUD=<doc> npm start
```
