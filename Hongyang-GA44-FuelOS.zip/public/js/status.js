// Shared status vocabulary: every status has a colour, a text label AND an
// icon, so colour is never the only indicator.
const ICONS = {
  check: '<path d="M4 8.5l2.5 2.5L12 5.5"/>',
  nozzle: '<path d="M3 5h7l3 3M10 5v6M5 5v8"/>',
  flow: '<path d="M2 6c2-2 4 2 6 0s4 2 6 0M2 10c2-2 4 2 6 0s4 2 6 0"/>',
  pause: '<path d="M6 4v8M10 4v8"/>',
  done: '<circle cx="8" cy="8" r="5"/><path d="M5.8 8.2l1.6 1.6 3-3.2"/>',
  fault: '<path d="M8 2.5l6 11H2z"/><path d="M8 7v3M8 11.6v.4"/>',
  offline: '<path d="M2 2l12 12M5 9.5a4 4 0 015.5-1M2.5 6.5a8 8 0 014.5-2M8 12.5v.2"/>',
  link: '<path d="M6.5 9.5l3-3M5 11a2.5 2.5 0 010-3.5l1.5-1.5M11 5a2.5 2.5 0 010 3.5L9.5 10"/>'
};

export const STATUS = {
  idle:           { label: "Available",     short: "IDLE",      color: "#3fb950", tone: "ok",      icon: "check" },
  nozzle_removed: { label: "Nozzle removed", short: "NOZZLE OUT", color: "#e3a008", tone: "warn",   icon: "nozzle" },
  dispensing:     { label: "Dispensing",    short: "DISPENSING", color: "#22c3e6", tone: "active",  icon: "flow" },
  paused:         { label: "Paused",        short: "PAUSED",    color: "#e3a008", tone: "warn",    icon: "pause" },
  completed:      { label: "Sale completed", short: "COMPLETED", color: "#57c785", tone: "ok",     icon: "done" },
  fault:          { label: "Fault",         short: "FAULT",     color: "#e5484d", tone: "fault",   icon: "fault" },
  offline:        { label: "Offline",       short: "OFFLINE",   color: "#7d838b", tone: "offline", icon: "offline" }
};

export const CONNECTION = {
  simulated:      { label: "Simulation engine", color: "#22c3e6", icon: "flow" },
  connected:      { label: "Connected",         color: "#3fb950", icon: "link" },
  connecting:     { label: "Connecting…",       color: "#e3a008", icon: "link" },
  disconnected:   { label: "Disconnected",      color: "#e5484d", icon: "offline" },
  not_configured: { label: "Not configured",    color: "#7d838b", icon: "offline" },
  initialising:   { label: "Initialising",      color: "#7d838b", icon: "link" }
};

export function icon(name, size = 14) {
  return `<svg class="ic" width="${size}" height="${size}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

export function statusMeta(status) {
  return STATUS[status] || STATUS.offline;
}

export function statusPill(status) {
  const s = statusMeta(status);
  return `<span class="pill tone-${s.tone}" style="--c:${s.color}">${icon(s.icon, 12)}<span>${s.label}</span></span>`;
}
