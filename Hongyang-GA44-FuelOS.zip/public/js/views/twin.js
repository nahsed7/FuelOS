import { PositionPanel, toast } from "../ui.js";
import { esc } from "../format.js";

export function twinView(ctx) {
  const host = document.getElementById("viewer");
  const panel = new PositionPanel(document.getElementById("posPanel"), ctx);
  const compPanel = document.getElementById("componentPanel");
  let viewer = null;
  let loading = null;

  async function ensureViewer() {
    if (viewer || loading) return loading;
    loading = (async () => {
      try {
        const probe = document.createElement("canvas");
        if (!(probe.getContext("webgl2") || probe.getContext("webgl"))) throw new Error("WebGL is not available in this browser.");
        const { TwinViewer } = await import("../twin/viewer.js");
        viewer = new TwinViewer(host, ctx.config, {
          onSelect: id => ctx.select(id),
          onNozzle: (id, action) => ctx.cmd(id, action),
          onKeypad: (id, key, submit) => {
            if (!submit) return;
            const preset = submit.value > 0 ? { type: submit.type, value: submit.value } : undefined;
            ctx.cmd(id, "start", preset ? { preset } : {});
          },
          onComponent: info => showComponent(info)
        });
        ctx.viewer = viewer;
        viewer.select(ctx.selected);
        if (ctx.client.state) viewer.setTelemetry(ctx.client.state);
        ctx.applyRenderPrefs?.();
      } catch (err) {
        console.error("3D viewer failed to start:", err);
        host.innerHTML = `<div class="viewer-error"><h3>3D renderer could not start</h3><p>${esc(err.message)}</p><p>The dashboard pages keep working without 3D.</p></div>`;
      }
    })();
    return loading;
  }

  function showComponent(info) {
    compPanel.hidden = false;
    compPanel.innerHTML = `<div class="card-head"><div><div class="eyebrow">Component</div><h2>${esc(info.name || info.id)}</h2></div>
      <button class="btn ghost" data-close aria-label="Close">✕</button></div>
      <p>${esc(info.text || "")}</p>
      <p>${info.est ? '<span class="tag est">Engineering estimate</span>' : '<span class="tag ok">Per manufacturer reference</span>'}
      ${info.side ? `<span class="tag">Side ${info.side}</span>` : ""}${info.pump ? `<span class="tag">${info.pump}</span>` : ""}${info.position ? `<span class="tag">${info.position}</span>` : ""}</p>`;
  }
  compPanel.addEventListener("click", e => { if (e.target.closest("[data-close]")) compPanel.hidden = true; });

  // Toolbar wiring.
  const page = document.getElementById("page-twin");
  page.addEventListener("click", e => {
    const b = e.target.closest("button");
    if (!b || !viewer && !b.dataset.pos && !b.dataset.side && b.id !== "openInfo") return;
    if (b.dataset.side) {
      const first = `${b.dataset.side}1`;
      ctx.select(ctx.selected?.startsWith(b.dataset.side) ? ctx.selected : first);
      viewer?.view(b.dataset.side);
    } else if (b.dataset.pos) {
      ctx.select(b.dataset.pos);
      viewer?.view("close");
    } else if (b.dataset.mode) {
      viewer.setMode(b.dataset.mode);
      page.querySelectorAll("[data-mode]").forEach(x => x.classList.toggle("on", x === b));
      if (b.dataset.mode !== "normal") toast("Technical view: internal layout (pumps, meters, pipework, mainboards) is an engineering estimate.", "info", 5000);
    } else if (b.dataset.cam) {
      viewer.view(b.dataset.cam);
    } else if (b.dataset.rot) {
      viewer.rotate(Number(b.dataset.rot));
    } else if (b.id === "autoRotate") {
      const on = b.getAttribute("aria-pressed") !== "true";
      b.setAttribute("aria-pressed", String(on));
      b.classList.toggle("on", on);
      viewer.setAutoRotate(on);
    } else if (b.id === "openInfo") {
      ctx.openInfo();
    }
  });

  ctx.inspectNozzle = id => {
    ctx.select(id);
    if (!viewer) return;
    if (!ctx.client.state?.positions[id]?.nozzleLifted) viewer.view("nozzle");
    else { viewer.resetNozzlePose(id); setTimeout(() => viewer.view("nozzle"), 350); }
  };

  return {
    async enter() {
      await ensureViewer();
      viewer?.setActive(true);
    },
    leave() { viewer?.setActive(false); },
    select(id) {
      if (panel.id !== id) panel.build(id);
      viewer?.select(id);
      page.querySelectorAll("[data-pos]").forEach(b => b.classList.toggle("on", b.dataset.pos === id));
      page.querySelectorAll("[data-side]").forEach(b => b.classList.toggle("on", id?.startsWith(b.dataset.side)));
      if (ctx.client.state) panel.update(ctx.client.state);
    },
    update(s) {
      viewer?.setTelemetry(s);
      panel.update(s);
      document.getElementById("viewerStamp").textContent = s.simulated ? "SIMULATED DATA" : `PHYSICAL · READ-ONLY · ${s.connection.state.toUpperCase()}`;
    },
    // Keeps the 3D model in sync even while another page is shown.
    background(s) { viewer?.setTelemetry(s); }
  };
}
