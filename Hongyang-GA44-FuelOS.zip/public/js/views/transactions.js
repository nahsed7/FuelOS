import { fmt, esc } from "../format.js";
import { toast } from "../ui.js";

const REASONS = {
  preset_reached: "Preset reached", operator_stop: "Stopped", nozzle_hung_up: "Nozzle hung up",
  fault: "Fault", offline: "Went offline", reset: "Reset"
};

export function transactionsView(ctx) {
  const tbody = document.querySelector("#txTable tbody");
  const empty = document.getElementById("txEmpty");
  const filter = document.getElementById("txFilter");
  let rows = [];

  async function load() {
    try {
      const r = await ctx.client.get(`transactions?limit=500${filter.value ? `&position=${filter.value}` : ""}`);
      rows = r.transactions;
      document.getElementById("txSource").textContent = r.simulated ? "SIMULATED" : "PHYSICAL";
      render();
    } catch (err) {
      toast(`Could not load transactions: ${err.message}`, "fault");
    }
  }

  function render() {
    tbody.innerHTML = rows.map(t => `<tr>
      <td>${fmt.dateTime(t.endedAt)}</td><td><b>${t.position}</b></td><td>${esc(t.productName)} <small class="muted">${t.product}</small></td>
      <td class="r mono">${fmt.num(t.volume, 3)}</td><td class="r mono">${fmt.num(t.unitPrice, 2)}</td>
      <td class="r mono">${fmt.money(t.amount, t.currency)}</td><td class="r mono">${fmt.duration(t.durationS)}</td>
      <td class="r mono">${fmt.num(t.totalizerEnd, 3)}</td><td>${REASONS[t.endReason] || esc(t.endReason)}</td>
      <td class="mono small">${esc(t.id)}</td></tr>`).join("");
    empty.hidden = rows.length > 0;
  }

  filter.addEventListener("change", load);
  document.getElementById("txExport").addEventListener("click", () => {
    if (!rows.length) return toast("Nothing to export yet.", "info");
    const cols = ["id", "position", "side", "product", "productName", "volume", "unitPrice", "amount", "currency", "startedAt", "endedAt", "durationS", "totalizerStart", "totalizerEnd", "endReason", "source"];
    const csv = [cols.join(","), ...rows.map(r => cols.map(c => JSON.stringify(r[c] ?? "")).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `fuelos-ga44-transactions-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  ctx.client.onTransaction(tx => {
    if (!filter.value || tx.position === filter.value) { rows.unshift(tx); if (ctx.page === "transactions") render(); }
  });

  return { enter: load, update() {} };
}
