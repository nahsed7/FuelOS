import { esc } from "../format.js";
import { CONNECTION, icon } from "../status.js";

const CONF = '<span class="tag ok">Confirmed</span>';
const EST = '<span class="tag est">Estimate</span>';

/** Equipment identity block (used by the Equipment page and the info dialog). */
export function equipmentSummary(info, state) {
  const e = info.equipment;
  const conn = CONNECTION[state?.connection?.state] || CONNECTION.initialising;
  return `<dl class="meta-list">
    <dt>Manufacturer</dt><dd>${esc(e.manufacturer)} ${CONF}</dd>
    <dt>Series</dt><dd>${esc(e.series)} ${CONF}</dd>
    <dt>Model</dt><dd class="mono">${esc(e.model)} ${CONF}</dd>
    <dt>Serial number</dt><dd class="mono">${esc(e.serial)} ${CONF}</dd>
    <dt>Configuration</dt><dd class="mono">${esc(e.configuration)} ${CONF}</dd>
    <dt>Operating sides</dt><dd>${e.operatingSides.length} (${e.operatingSides.join(", ")})</dd>
    <dt>Dispensing positions</dt><dd>${Object.keys(info.positions).length} (${Object.keys(info.positions).join(", ")})</dd>
    <dt>Data source</dt><dd>${esc(state?.dataLabel || info.dataSource)}</dd>
    <dt>Operating mode</dt><dd>${state?.simulated ? "Simulation — commands act on the simulator only" : "Physical device — read-only"}</dd>
    <dt>Connection</dt><dd><span class="pill" style="--c:${conn.color}">${icon(conn.icon, 12)}<span>${conn.label}</span></span></dd>
  </dl>`;
}

export function equipmentView(ctx) {
  const grid = document.getElementById("equipGrid");
  return {
    enter() { this.update(ctx.client.state); },
    update(s) {
      const info = ctx.config;
      const e = info.equipment, hw = e.hardware, est = e.estimates;
      const phys = info.adapter;
      grid.innerHTML = `
        <div class="card"><div class="card-head"><h2>Identity</h2></div>${equipmentSummary(info, s)}</div>
        <div class="card"><div class="card-head"><h2>GA44 hardware configuration</h2>${CONF}</div>
          <p class="muted small">Source: Hongyang A-Series product table, row CMD1687SK-GA44.</p>
          <div class="hw-grid">${Object.entries(hw).map(([k, v]) => `<div><b class="mono">${v}</b><span>${k}</span></div>`).join("")}</div>
          <p class="muted small">Four nozzles are served by <b>two</b> pumps (one per product) and four flowmeters — not four independent pump assemblies.</p>
        </div>
        <div class="card"><div class="card-head"><h2>Position mapping</h2>${EST}</div>
          <div class="table-wrap"><table class="table"><thead><tr><th>Position</th><th>Side</th><th>Product</th><th>Pump</th><th>Flowmeter</th><th>Mainboard</th></tr></thead><tbody>
          ${Object.entries(info.positions).map(([id, p]) => `<tr><td><b>${id}</b></td><td>${p.side}</td><td>${p.product}</td><td>${p.pump}</td><td>${p.meter}</td><td>${p.mainboard}</td></tr>`).join("")}
          </tbody></table></div>
          <p class="muted small">${esc(est.pumpAssignment)} ${esc(est.mainboardAssignment)}</p>
        </div>
        <div class="card"><div class="card-head"><h2>Engineering estimates</h2>${EST}</div>
          <dl class="meta-list">
            <dt>Dimensions</dt><dd>${est.dimensionsMm.width} × ${est.dimensionsMm.depth} × ${est.dimensionsMm.heightToCanopy} mm (W × D × H), scaled from catalogue photo</dd>
            <dt>Hose arrangement</dt><dd>${esc(est.hoseHang)}</dd>
            <dt>Shared pump</dt><dd>${esc(est.sharedPumpFlowFactor)}</dd>
          </dl>
        </div>
        <div class="card span-2"><div class="card-head"><h2>Physical device integration</h2><span class="tag ${phys.kind === "physical" ? "warn" : "sim"}">${phys.kind === "physical" ? "PHYSICAL MODE · READ-ONLY" : "NOT ACTIVE — SIMULATION MODE"}</span></div>
          <p>The physical adapter is a <b>read-only scaffold</b>. Hongyang does not publish the dispenser communication protocol, so no hardware link is implemented and none is claimed.
          In physical mode, positions stay <b>Offline</b> until a manufacturer-documented decoder is registered.</p>
          <div class="grid-2 tight">
            <div><h3>Still required</h3><ul class="checklist">
              <li>Manufacturer protocol document for the CMD1687SK-GA44 controller (frame format, addressing, polling, status codes)</li>
              <li>Physical interface on this unit's mainboards (RS-485 / RS-232 / current loop / Ethernet) and connector pin-out</li>
              <li>Whether the unit is already wired to a forecourt controller / POS — and if so, that controller's documented API</li>
              <li>Pump address and nozzle numbering configured on each mainboard (MB-A / MB-B)</li>
              <li>Confirmation of product-to-nozzle and pump-to-meter assignment (hydraulic schematic)</li>
              <li>Written authorisation from the station owner and a qualified dispenser technician for installation</li>
            </ul></div>
            <div><h3>Safety rules enforced in code</h3><ul class="checklist ok">
              <li>Read-only: every control command returns HTTP 403 in physical mode</li>
              <li>No start/stop, preset, price change, relay, valve, motor or pump control</li>
              <li>No calibration writes; no bypass of manufacturer safety systems</li>
              <li>Only documented decoders may be registered — no reverse-engineered protocol</li>
              <li>Simulation and physical data never mix: one adapter per server process</li>
            </ul></div>
          </div>
          <p class="muted small">Full architecture: <code>docs/PHYSICAL_INTEGRATION.md</code>. Current adapter: <code>${esc(phys.kind)}</code>${phys.kind === "physical" ? `, decoder: <code>${esc(phys.protocol || "none")}</code>` : ""}.</p>
        </div>`;
    }
  };
}
