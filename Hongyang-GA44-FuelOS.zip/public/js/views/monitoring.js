import { statusMeta, statusPill, icon } from "../status.js";
import { fmt, esc } from "../format.js";

const WINDOW_S = 120;

export function monitoringView(ctx) {
  const grid = document.getElementById("monGrid");
  const pumpsEl = document.getElementById("monPumps");
  const feed = document.getElementById("feed");
  const feedCount = document.getElementById("feedCount");
  const history = {};     // id → [{t, flow, vol}]
  const last = {};
  const events = [];
  let built = false;

  function build(s) {
    grid.innerHTML = Object.values(s.positions).map(p => `
      <article class="card mon-card" data-id="${p.id}">
        <div class="card-head"><h2>${p.id} <small class="muted">Side ${p.side} · ${p.product}</small></h2><div data-k="pill"></div></div>
        <div class="mon-read">
          <div><span>Volume</span><b class="mono" data-k="volume"></b><em>L</em></div>
          <div><span>Amount</span><b class="mono" data-k="amount"></b><em data-k="cur"></em></div>
          <div><span>Flow</span><b class="mono" data-k="flow"></b><em>L/min</em></div>
        </div>
        <canvas class="spark" width="560" height="110" aria-label="${p.id} flow rate, last ${WINDOW_S} seconds"></canvas>
        <div class="spark-legend"><span>Flow rate · last ${WINDOW_S}s</span><span data-k="max"></span></div>
        <dl class="meta-list compact">
          <dt>Unit price</dt><dd class="mono" data-k="price"></dd>
          <dt>Totalizer</dt><dd class="mono" data-k="tot"></dd>
          <dt>Session</dt><dd class="mono" data-k="dur"></dd>
          <dt>Session ID</dt><dd class="mono" data-k="sid"></dd>
        </dl>
        <div class="row end"><button class="btn ghost" data-open="${p.id}">Show in 3D →</button></div>
      </article>`).join("");
    built = true;
  }

  grid.addEventListener("click", e => {
    const b = e.target.closest("[data-open]");
    if (b) { ctx.select(b.dataset.open); ctx.navigate("twin"); }
  });

  function record(s) {
    const t = Date.parse(s.timestamp) / 1000;
    for (const p of Object.values(s.positions)) {
      const h = (history[p.id] ||= []);
      if (!h.length || t - h[h.length - 1].t >= 0.2) h.push({ t, flow: p.flowRate });
      while (h.length && t - h[0].t > WINDOW_S) h.shift();
      const prev = last[p.id];
      if (prev && prev !== p.status) {
        events.unshift({ at: s.timestamp, id: p.id, from: prev, to: p.status, vol: p.volume, amount: p.amount, cur: s.settings?.currency });
        if (events.length > 60) events.pop();
      }
      last[p.id] = p.status;
    }
  }

  function spark(canvas, h, color) {
    const g = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;
    g.clearRect(0, 0, W, H);
    g.strokeStyle = "rgba(255,255,255,0.06)";
    g.lineWidth = 1;
    for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(0, (H * i) / 4); g.lineTo(W, (H * i) / 4); g.stroke(); }
    if (h.length < 2) return 0;
    const max = Math.max(60, ...h.map(x => x.flow));
    const t1 = h[h.length - 1].t, t0 = t1 - WINDOW_S;
    g.beginPath();
    h.forEach((x, i) => {
      const px = ((x.t - t0) / WINDOW_S) * W, py = H - 4 - (x.flow / max) * (H - 10);
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    });
    g.strokeStyle = color; g.lineWidth = 2; g.stroke();
    g.lineTo(W, H); g.lineTo(((h[0].t - t0) / WINDOW_S) * W, H); g.closePath();
    const grd = g.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, color + "55"); grd.addColorStop(1, color + "00");
    g.fillStyle = grd; g.fill();
    return Math.max(...h.map(x => x.flow));
  }

  return {
    background(s) { record(s); },
    update(s) {
      if (!built) build(s);
      const cur = s.settings?.currency || "";
      for (const p of Object.values(s.positions)) {
        const card = grid.querySelector(`[data-id="${p.id}"]`);
        const k = n => card.querySelector(`[data-k="${n}"]`);
        const m = statusMeta(p.status);
        card.style.setProperty("--c", m.color);
        card.classList.toggle("selected", p.id === ctx.selected);
        k("pill").innerHTML = statusPill(p.status);
        k("volume").textContent = fmt.num(p.volume, 3);
        k("amount").textContent = fmt.num(p.amount, 2);
        k("cur").textContent = cur;
        k("flow").textContent = fmt.num(p.flowRate, 1);
        k("price").textContent = `${fmt.num(p.unitPrice, 2)} ${cur}/L`;
        k("tot").textContent = `${fmt.num(p.totalizer, 3)} L`;
        k("dur").textContent = fmt.duration(p.sessionDurationS);
        k("sid").textContent = p.sessionId || "—";
        const peak = spark(card.querySelector("canvas"), history[p.id] || [], "#22c3e6");
        k("max").textContent = `peak ${fmt.num(peak, 1)} L/min`;
      }
      pumpsEl.innerHTML = Object.values(s.pumps || {}).map(p => `
        <div class="pump-row ${p.running ? "running" : ""}"><div class="pump-icon" aria-hidden="true"></div>
        <div><b>${p.id}</b> · ${esc(p.productName)}<div class="muted small">Serves ${p.serves.join(" + ")} — shared-pump derating applies when both dispense</div></div>
        <span class="pill" style="--c:${p.running ? "#22c3e6" : "#7d838b"}">${icon(p.running ? "flow" : "pause", 12)}<span>${p.running ? "Running" : "Stopped"}</span></span></div>`).join("")
        || '<p class="muted">No pump data from the active source.</p>';
      feedCount.textContent = events.length;
      feed.innerHTML = events.map(ev => {
        const m = statusMeta(ev.to);
        return `<li style="--c:${m.color}"><time>${fmt.time(ev.at)}</time><b>${ev.id}</b> ${icon(m.icon, 12)} ${statusMeta(ev.from).short} → <span>${m.short}</span>
          ${ev.to === "completed" ? `<em class="mono">${fmt.num(ev.vol, 3)} L · ${fmt.money(ev.amount, ev.cur)}</em>` : ""}</li>`;
      }).join("") || '<li class="muted">Status changes will appear here.</li>';
    }
  };
}
