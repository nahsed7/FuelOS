import { fmt, esc } from "../format.js";
import { CONNECTION, icon } from "../status.js";

export function diagnosticsView(ctx) {
  const grid = document.getElementById("diagGrid");
  const logEl = document.getElementById("diagLog");
  let diag = null, timer = null;

  async function load() {
    try {
      diag = await ctx.client.get("diagnostics");
      logEl.textContent = diag.logs.map(l => `${l.ts.slice(11, 23)} ${l.level.toUpperCase().padEnd(5)} [${l.scope}] ${l.message}${l.meta ? ` ${JSON.stringify(l.meta)}` : ""}`).join("\n") || "(no log entries)";
      logEl.scrollTop = logEl.scrollHeight;
    } catch (err) {
      logEl.textContent = `Could not load diagnostics: ${err.message}`;
    }
    render();
  }
  document.getElementById("diagRefresh").addEventListener("click", load);

  function render() {
    const s = ctx.client.state, link = ctx.client.link;
    const conn = CONNECTION[s?.connection.state] || CONNECTION.initialising;
    const r = ctx.viewer?.stats();
    const card = (title, rows) => `<div class="card"><div class="card-head"><h2>${title}</h2></div><dl class="meta-list">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join("")}</dl></div>`;
    grid.innerHTML = [
      card("Data source", [
        ["Adapter", esc(diag?.adapter.kind || s?.source || "—")],
        ["Labelled as", esc(s?.dataLabel || "—")],
        ["Device link", `<span class="pill" style="--c:${conn.color}">${icon(conn.icon, 12)}<span>${conn.label}</span></span>`],
        ["Detail", esc(s?.connection.detail || "—")],
        ["Last data", s?.connection.lastDataAt ? fmt.time(s.connection.lastDataAt) : "never"],
        ["Stale", s?.connection.stale ? "YES — positions forced offline" : "no"]
      ]),
      card("Browser ↔ FuelOS backend", [
        ["Socket.IO", `${esc(link.state)}${link.detail ? ` (${esc(link.detail)})` : ""}`],
        ["Last message", fmt.ago(link.lastMessageAt)],
        ["Reconnect attempts", link.reconnects],
        ["HTTP latency", link.latencyMs == null ? "—" : `${link.latencyMs} ms`],
        ["Telemetry seq", s?.seq ?? "—"],
        ["Clients on server", diag?.socketClients ?? "—"]
      ]),
      card("Server & renderer", [
        ["Uptime", diag ? fmt.duration(diag.uptimeS) : "—"],
        ["Node.js", esc(diag?.node || "—")],
        ["Memory (RSS)", diag ? `${diag.memoryMb} MB` : "—"],
        ["3D frame rate", r ? `${r.fps} fps` : "3D not started"],
        ["Draw calls / triangles", r ? `${r.drawCalls} / ${r.triangles.toLocaleString()}` : "—"],
        ["GPU geometries / textures", r ? `${r.geometries} / ${r.textures}` : "—"]
      ])
    ].join("");
  }

  return {
    enter() { load(); timer = setInterval(load, 3000); },
    leave() { clearInterval(timer); },
    update() { render(); }
  };
}
