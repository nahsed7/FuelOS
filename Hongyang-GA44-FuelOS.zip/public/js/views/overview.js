import { positionTile } from "../ui.js";
import { fmt, esc } from "../format.js";
import { icon } from "../status.js";

export function overviewView(ctx) {
  const kpis = document.getElementById("kpis");
  const posEl = document.getElementById("ovPositions");
  const pumpsEl = document.getElementById("ovPumps");
  const unitEl = document.getElementById("ovUnit");
  let txs = [];

  posEl.addEventListener("click", e => {
    const b = e.target.closest("[data-select]");
    if (b) { ctx.select(b.dataset.select); ctx.navigate("twin"); }
  });

  async function loadTx() {
    try { txs = (await ctx.client.get("transactions?limit=500")).transactions; } catch { txs = []; }
  }
  ctx.client.onTransaction(tx => { txs.unshift(tx); });

  return {
    async enter() { await loadTx(); },
    update(s) {
      const cur = s.settings?.currency || "";
      const today = new Date().toDateString();
      const todays = txs.filter(t => new Date(t.endedAt).toDateString() === today);
      const vol = todays.reduce((a, t) => a + t.volume, 0);
      const amt = todays.reduce((a, t) => a + t.amount, 0);
      const ps = Object.values(s.positions);
      const active = ps.filter(p => p.status === "dispensing").length;
      const attention = ps.filter(p => ["fault", "offline"].includes(p.status)).length;
      const tag = s.simulated ? '<span class="tag sim">SIMULATED</span>' : "";
      kpis.innerHTML = [
        ["Dispensing now", `${active} / 4`, icon("flow"), "positions"],
        ["Sales today", todays.length, icon("check"), "completed"],
        ["Volume today", `${fmt.num(vol, 2)} L`, icon("flow"), "all positions"],
        ["Revenue today", fmt.money(amt, cur), icon("check"), "all positions"],
        ["Attention", attention, icon(attention ? "fault" : "check"), attention ? "fault / offline" : "all healthy"]
      ].map(([k, v, ic, sub]) => `<div class="kpi"><div class="kpi-k">${ic}${k}</div><div class="kpi-v mono">${v}</div><div class="kpi-s">${sub} ${tag}</div></div>`).join("");
      posEl.innerHTML = ps.map(p => positionTile(p, cur, p.id === ctx.selected)).join("");
      pumpsEl.innerHTML = Object.values(s.pumps || {}).map(p => `
        <div class="pump-row ${p.running ? "running" : ""}">
          <div class="pump-icon" aria-hidden="true"></div>
          <div><b>${p.id}</b> · ${esc(p.productName)} <small>(${p.product})</small><div class="muted small">Feeds ${p.serves.join(" + ")}</div></div>
          <span class="pill" style="--c:${p.running ? "#22c3e6" : "#7d838b"}">${icon(p.running ? "flow" : "pause", 12)}<span>${p.running ? "Running" : "Stopped"}</span></span>
        </div>`).join("") || '<p class="muted">No pump data from the active source.</p>';
      const e = s.equipment;
      unitEl.innerHTML = `<dl class="meta-list">
        <dt>Manufacturer</dt><dd>${e.manufacturer} · ${e.series}</dd>
        <dt>Model</dt><dd class="mono">${e.model}</dd>
        <dt>Serial</dt><dd class="mono">${e.serial}</dd>
        <dt>Data source</dt><dd>${s.dataLabel}</dd>
        <dt>Last update</dt><dd>${fmt.time(s.timestamp)}</dd></dl>`;
    }
  };
}
