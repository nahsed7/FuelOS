import { esc } from "../format.js";
import { toast } from "../ui.js";

const PREFS_KEY = "fuelos.render";

export function loadRenderPrefs() {
  try { return { shadows: true, pixelRatio: 1.75, labels: true, ...JSON.parse(localStorage.getItem(PREFS_KEY) || "{}") }; }
  catch { return { shadows: true, pixelRatio: 1.75, labels: true }; }
}

function saveRenderPrefs(p) {
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); } catch { /* storage unavailable */ }
}

export function settingsView(ctx) {
  const form = document.getElementById("simSettings");
  const productFields = document.getElementById("productFields");
  const prefs = loadRenderPrefs();
  const shadows = document.getElementById("optShadows");
  const ratio = document.getElementById("optPixelRatio");
  const labels = document.getElementById("optLabels");
  shadows.checked = prefs.shadows;
  ratio.value = String(prefs.pixelRatio);
  labels.checked = prefs.labels;

  ctx.applyRenderPrefs = () => {
    ctx.viewer?.setQuality({ shadows: prefs.shadows, pixelRatio: prefs.pixelRatio });
    document.body.classList.toggle("hide-3d-labels", !prefs.labels);
  };
  const changed = () => {
    Object.assign(prefs, { shadows: shadows.checked, pixelRatio: Number(ratio.value), labels: labels.checked });
    saveRenderPrefs(prefs);
    ctx.applyRenderPrefs();
    toast("Rendering preferences applied.", "ok", 2000);
  };
  [shadows, ratio, labels].forEach(el => el.addEventListener("change", changed));
  ctx.applyRenderPrefs();

  function fill(s) {
    const st = s.settings || {};
    form.elements.nominalFlowLpm.value = st.nominalFlowLpm ?? "";
    productFields.innerHTML = Object.entries(st.products || {}).map(([id, p]) => `
      <fieldset class="product-fs"><legend>${id} <small class="muted">(${Object.entries(ctx.config.positions).filter(([, x]) => x.product === id).map(([k]) => k).join(", ")})</small></legend>
        <label>Display name<input name="${id}.name" value="${esc(p.name)}" maxlength="32" required></label>
        <label>Unit price (${esc(st.currency)}/L)<input name="${id}.unitPrice" type="number" min="0" step="0.01" value="${p.unitPrice}" required></label>
      </fieldset>`).join("");
    const disabled = !s.commandsEnabled;
    form.querySelectorAll("input,button").forEach(el => { el.disabled = disabled; });
    document.getElementById("settingsNote").textContent = disabled
      ? "Physical mode is read-only: prices and flow are the dispenser's own and cannot be changed from FuelOS."
      : "Values apply to the simulator only. Prices are locked per sale: active sales keep the price they started with.";
  }

  form.addEventListener("submit", async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const products = {};
    for (const [k, v] of fd.entries()) {
      const [pid, field] = k.split(".");
      if (field) (products[pid] ||= {})[field] = field === "unitPrice" ? Number(v) : v;
    }
    const r = await ctx.client.command("settings", { nominalFlowLpm: Number(fd.get("nominalFlowLpm")), products });
    toast(r.ok ? "Simulation settings applied." : `Settings rejected: ${r.message}`, r.ok ? "ok" : "fault");
  });

  return {
    enter() {
      if (ctx.client.state) fill(ctx.client.state);
      const s = ctx.client.state;
      document.getElementById("sourceInfo").innerHTML = `<dl class="meta-list">
        <dt>Active source</dt><dd><b>${esc(s?.dataLabel || "—")}</b></dd>
        <dt>Selected by</dt><dd><code>DATA_SOURCE</code> environment variable at server start</dd>
        <dt>Simulation</dt><dd><code>npm start</code> (default)</dd>
        <dt>Physical (read-only)</dt><dd><code>DATA_SOURCE=physical npm start</code> — shows Offline until a documented decoder is configured</dd>
      </dl>`;
    },
    update() {}
  };
}
