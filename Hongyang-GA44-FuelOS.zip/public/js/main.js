// FuelOS front-end entry: router + shared context. Every page reads the same
// TelemetryClient, so the dashboard and the 3D twin always agree.
import { TelemetryClient } from "./telemetry-client.js";
import { toast } from "./ui.js";
import { CONNECTION, icon } from "./status.js";
import { overviewView } from "./views/overview.js";
import { twinView } from "./views/twin.js";
import { monitoringView } from "./views/monitoring.js";
import { transactionsView } from "./views/transactions.js";
import { equipmentView, equipmentSummary } from "./views/equipment.js";
import { diagnosticsView } from "./views/diagnostics.js";
import { settingsView } from "./views/settings.js";

const PAGES = ["overview", "twin", "monitoring", "transactions", "equipment", "diagnostics", "settings"];

async function loadConfig() {
  for (let attempt = 0; ; attempt++) {
    try {
      const r = await fetch("/api/equipment", { cache: "no-store" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return await r.json();
    } catch (err) {
      document.getElementById("linkState").innerHTML = `<span class="pill" style="--c:#e5484d">${icon("offline", 12)}<span>Backend unreachable — retrying</span></span>`;
      await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** attempt, 8000)));
    }
  }
}

async function boot() {
  const config = await loadConfig();
  const client = new TelemetryClient();

  const ctx = {
    config, client, page: null, selected: "A1", viewer: null,
    navigate: page => { location.hash = `#/${page}`; },
    select(id) {
      if (!config.positions[id]) return;
      ctx.selected = id;
      views.twin.select(id);
      if (client.state) views[ctx.page]?.update(client.state);
    },
    async cmd(id, action, body = {}) {
      if (client.state && !client.state.commandsEnabled) {
        toast("Read-only: physical mode never sends commands to the dispenser.", "fault");
        return false;
      }
      const r = await client.command(`positions/${id}/${action}`, body);
      if (!r.ok) toast(r.message || `${action} failed`, "fault");
      return r.ok;
    },
    openInfo() {
      document.getElementById("infoBody").innerHTML = equipmentSummary(config, client.state);
      document.getElementById("infoDialog").showModal();
    }
  };

  const views = {
    overview: overviewView(ctx),
    twin: twinView(ctx),
    monitoring: monitoringView(ctx),
    transactions: transactionsView(ctx),
    equipment: equipmentView(ctx),
    diagnostics: diagnosticsView(ctx),
    settings: settingsView(ctx)
  };
  views.twin.select(ctx.selected);

  // ---- Router -------------------------------------------------------------------
  async function route() {
    const name = (location.hash.match(/^#\/(\w+)/) || [])[1];
    const page = PAGES.includes(name) ? name : "overview";
    if (page === ctx.page) return;
    if (ctx.page) views[ctx.page].leave?.();
    ctx.page = page;
    document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === `page-${page}`));
    document.querySelectorAll("#nav a").forEach(a => a.setAttribute("aria-current", a.dataset.page === page ? "page" : "false"));
    const title = document.getElementById(`page-${page}`).dataset.title;
    document.getElementById("pageTitle").textContent = title;
    document.title = `FuelOS · ${title} · Hongyang GA44`;
    await views[page].enter?.();
    if (client.state && ctx.page === page) views[page].update(client.state);
  }
  window.addEventListener("hashchange", route);

  // ---- Telemetry fan-out --------------------------------------------------------
  client.subscribe(s => {
    views.monitoring.background(s);
    if (ctx.page !== "twin") views.twin.background(s);
    if (ctx.page) views[ctx.page].update(s);
    const badge = document.getElementById("sourceBadge");
    badge.textContent = s.simulated ? "SIMULATION MODE · SIMULATED DATA" : "PHYSICAL MODE · READ-ONLY";
    badge.className = `source-badge ${s.simulated ? "sim" : "phys"}`;
    renderLink();
  });
  client.onLink(renderLink);
  function renderLink() {
    const l = client.link, s = client.state;
    const dev = CONNECTION[s?.connection.state] || CONNECTION.initialising;
    const sock = { live: ["#3fb950", "link", "Live"], reconnecting: ["#e3a008", "link", "Reconnecting…"], offline: ["#e5484d", "offline", "Backend offline"], connecting: ["#7d838b", "link", "Connecting…"], error: ["#e5484d", "offline", "Socket error"] }[l.state] || ["#7d838b", "link", l.state];
    document.getElementById("linkState").innerHTML =
      `<span class="pill" style="--c:${sock[0]}" title="Browser ↔ FuelOS backend">${icon(sock[1], 12)}<span>${sock[2]}</span></span>
       <span class="pill" style="--c:${dev.color}" title="FuelOS ↔ telemetry source">${icon(dev.icon, 12)}<span>${dev.label}</span></span>`;
  }

  // Debug handle for the browser console (read-only use recommended).
  window.FuelOS = ctx;
  client.start();
  route();
}

boot().catch(err => {
  console.error("FuelOS failed to start:", err);
  document.getElementById("pages").innerHTML = `<div class="card"><h2>FuelOS failed to start</h2><p>${String(err.message)}</p></div>`;
});
