// Industrial automatic fuel nozzle + physically-motivated hose curve.
//
// Nozzle local frame: origin = hose swivel inlet, +X = toward spout tip,
// +Y = top of valve body, trigger and guard hang below (−Y).
import * as THREE from "three";

function extrudeProfile(points, depth, bevel, material, curveSegments = 10) {
  const shape = new THREE.Shape();
  points.forEach(([x, y], i) => (i ? shape.lineTo(x, y) : shape.moveTo(x, y)));
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments
  });
  geo.translate(0, 0, -depth / 2);
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, material);
  m.castShadow = true;
  return m;
}

function smoothProfile(pts, segments = 6) {
  // Catmull-Rom through the given outline for a cast-metal look.
  const curve = new THREE.CatmullRomCurve3(pts.map(([x, y]) => new THREE.Vector3(x, y, 0)), true, "centripetal");
  return curve.getPoints(pts.length * segments).map(v => [v.x, v.y]);
}

export const HOSE_ANCHOR = new THREE.Vector3(-0.062, 0, 0);
export const HOSE_ANCHOR_DIR = new THREE.Vector3(-1, -0.12, 0).normalize();

/**
 * Builds one nozzle. Returns { group, pickables, gripMaterial }.
 * `gripColor` follows the product colour coding.
 */
export function buildNozzle(mats, gripColor) {
  const group = new THREE.Group();
  const pickables = [];
  const gripMaterial = new THREE.MeshPhysicalMaterial({
    color: gripColor, roughness: 0.45, metalness: 0.0, clearcoat: 0.35, clearcoatRoughness: 0.5
  });

  // Cast aluminium valve body.
  const bodyPts = smoothProfile([
    [0.034, -0.02], [0.036, 0.024], [0.06, 0.04], [0.15, 0.041], [0.188, 0.03],
    [0.206, 0.012], [0.206, -0.012], [0.178, -0.03], [0.1, -0.027], [0.05, -0.025]
  ]);
  const body = extrudeProfile(bodyPts, 0.036, 0.006, mats.castAluminium, 4);
  body.name = "valve-body";
  group.add(body);

  // Moulded grip cover over the rear of the body (product colour).
  const grip = extrudeProfile(smoothProfile([
    [0.028, -0.024], [0.03, 0.03], [0.05, 0.05], [0.118, 0.052], [0.128, 0.03], [0.124, -0.028], [0.07, -0.032]
  ], 5), 0.046, 0.008, gripMaterial, 4);
  grip.name = "grip-cover";
  group.add(grip);

  // Grip texture ribs.
  for (let i = 0; i < 5; i++) {
    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.06, 0.064), mats.rubber);
    rib.position.set(0.045 + i * 0.016, 0.014, 0);
    group.add(rib);
  }

  // Trigger lever (pivot near the front, free end at the rear).
  const lever = extrudeProfile(smoothProfile([
    [0.168, -0.026], [0.172, -0.036], [0.12, -0.052], [0.055, -0.062], [0.045, -0.054], [0.11, -0.04]
  ], 5), 0.018, 0.003, mats.darkMetal, 4);
  lever.name = "trigger";
  group.add(lever);

  // Hold-open clip detail on the lever.
  const clip = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.008, 0.026), mats.chrome);
  clip.position.set(0.07, -0.058, 0);
  group.add(clip);

  // Trigger guard (bent bar).
  const guardCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.188, -0.022, 0), new THREE.Vector3(0.186, -0.07, 0),
    new THREE.Vector3(0.15, -0.088, 0), new THREE.Vector3(0.07, -0.09, 0),
    new THREE.Vector3(0.03, -0.075, 0), new THREE.Vector3(0.03, -0.03, 0)
  ]);
  const guard = new THREE.Mesh(new THREE.TubeGeometry(guardCurve, 40, 0.0055, 8, false), mats.castAluminium);
  guard.castShadow = true;
  guard.name = "trigger-guard";
  group.add(guard);

  // Spout nut + collar.
  const nut = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.022, 6), mats.chrome);
  nut.rotation.z = Math.PI / 2;
  nut.position.set(0.214, 0.002, 0);
  group.add(nut);

  // Spout: stainless tube with the characteristic downward bend.
  const spoutCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.22, 0.002, 0), new THREE.Vector3(0.29, 0.002, 0),
    new THREE.Vector3(0.335, -0.012, 0), new THREE.Vector3(0.39, -0.045, 0)
  ]);
  const spout = new THREE.Mesh(new THREE.TubeGeometry(spoutCurve, 32, 0.0108, 14, false), mats.stainless);
  spout.castShadow = true;
  spout.name = "spout";
  group.add(spout);
  // Spout tip ring + auto shut-off sensing hole band.
  const tip = new THREE.Mesh(new THREE.TorusGeometry(0.0108, 0.0022, 8, 18), mats.stainless);
  tip.position.copy(spoutCurve.getPoint(1));
  tip.lookAt(spoutCurve.getPoint(1).add(spoutCurve.getTangent(1)));
  group.add(tip);
  const spring = new THREE.Mesh(new THREE.CylinderGeometry(0.0125, 0.0125, 0.03, 14, 1, true), mats.darkMetal);
  spring.rotation.z = Math.PI / 2;
  spring.position.set(0.245, 0.002, 0);
  group.add(spring);

  // Hose swivel: knurled nut + ferrule.
  const swivel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.034, 12), mats.chrome);
  swivel.rotation.z = Math.PI / 2;
  swivel.position.set(0.014, -0.002, 0);
  swivel.name = "hose-swivel";
  group.add(swivel);
  const ferrule = new THREE.Mesh(new THREE.CylinderGeometry(0.0165, 0.015, 0.05, 16), mats.stainless);
  ferrule.rotation.z = Math.PI / 2 + 0.12;
  ferrule.position.set(-0.035, -0.004, 0);
  group.add(ferrule);

  group.traverse(o => {
    if (o.isMesh) {
      o.castShadow = true;
      pickables.push(o);
    }
  });
  return { group, pickables, gripMaterial };
}

/**
 * Hose between a fixed outlet and the moving nozzle swivel. The sag is
 * solved so that the hose keeps (approximately) its true length: slack
 * either hangs as a catenary-like loop or lies on the ground.
 */
export class Hose {
  constructor(material, { radius = 0.0135, length = 3.9, floorY = 0, outward }) {
    this.material = material;
    this.radius = radius;
    this.length = length;
    this.floorY = floorY + radius + 0.002;
    this.outward = outward.clone().normalize();
    this.mesh = new THREE.Mesh(new THREE.BufferGeometry(), material);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.mesh.name = "hose";
    this.lastKey = "";
    this.curve = null;
  }

  update(outlet, anchor, anchorDir) {
    const key = `${anchor.x.toFixed(4)},${anchor.y.toFixed(4)},${anchor.z.toFixed(4)},${anchorDir.x.toFixed(3)},${anchorDir.y.toFixed(3)}`;
    if (key === this.lastKey) return false;
    this.lastKey = key;

    const p0 = outlet.clone();
    const p1 = outlet.clone().add(new THREE.Vector3(0, -0.18, 0));
    const q0 = anchor.clone();
    const q1 = anchor.clone().addScaledVector(anchorDir, 0.14);
    const fixed = 0.18 + 0.14;
    const free = Math.max(0.2, this.length - fixed);

    // Horizontal location of the sag: between both ends, pushed outward.
    const mid = p1.clone().lerp(q1, 0.5).addScaledVector(this.outward, 0.22);
    const lenVia = y => {
      const m = new THREE.Vector3(mid.x, y, mid.z);
      return p1.distanceTo(m) + m.distanceTo(q1);
    };
    const top = Math.min(p1.y, q1.y);
    let points;
    if (lenVia(this.floorY) <= free) {
      // Slack lies on the ground as a loop.
      const excess = free - lenVia(this.floorY);
      const along = new THREE.Vector3().subVectors(q1, p1).setY(0);
      if (along.lengthSq() < 1e-6) along.copy(this.outward);
      along.normalize();
      const spread = Math.min(excess * 0.42, 0.9);
      const loopOut = this.outward.clone().multiplyScalar(Math.min(excess * 0.3, 0.6));
      const l1 = new THREE.Vector3(mid.x, this.floorY, mid.z).addScaledVector(along, -spread / 2).add(loopOut);
      const l2 = new THREE.Vector3(mid.x, this.floorY, mid.z).addScaledVector(along, spread / 2).add(loopOut);
      const u1 = p1.clone().lerp(l1, 0.6); u1.y = this.floorY + (p1.y - this.floorY) * 0.25;
      const u2 = q1.clone().lerp(l2, 0.6); u2.y = this.floorY + (q1.y - this.floorY) * 0.22;
      points = [p0, p1, u1, l1, l2, u2, q1, q0];
    } else {
      // Bisect the sag height that preserves hose length.
      let lo = this.floorY, hi = top;
      for (let i = 0; i < 24; i++) {
        const m = (lo + hi) / 2;
        lenVia(m) > free ? (lo = m) : (hi = m);
      }
      const low = new THREE.Vector3(mid.x, (lo + hi) / 2, mid.z);
      const a = p1.clone().lerp(low, 0.55); a.y = low.y + (p1.y - low.y) * 0.3;
      const b = q1.clone().lerp(low, 0.55); b.y = low.y + (q1.y - low.y) * 0.3;
      points = [p0, p1, a, low, b, q1, q0];
    }

    // Smooth, then clamp to the floor so the hose never sinks into the ground.
    const rough = new THREE.CatmullRomCurve3(points, false, "centripetal", 0.5);
    const samples = rough.getSpacedPoints(70).map(v => { v.y = Math.max(v.y, this.floorY); return v; });
    this.curve = new THREE.CatmullRomCurve3(samples, false, "centripetal");

    this.mesh.geometry.dispose();
    this.mesh.geometry = new THREE.TubeGeometry(this.curve, 140, this.radius, 10, false);
    return true;
  }
}
