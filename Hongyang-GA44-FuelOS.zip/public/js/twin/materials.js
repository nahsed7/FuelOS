// PBR material library for the dispenser and its surroundings.
import * as THREE from "three";
import { brushedRoughness, paintNoise, doorGraphic } from "./textures.js";

export function createMaterials() {
  const brushed = brushedRoughness();
  const noise = paintNoise();

  const m = {
    // Cabinet paints (A-Series: graphite "ship-type" sides, white door, white canopy).
    graphite: new THREE.MeshPhysicalMaterial({
      color: "#2b2e33", roughness: 0.52, metalness: 0.25, roughnessMap: noise, clearcoat: 0.25, clearcoatRoughness: 0.45
    }),
    graphiteDark: new THREE.MeshStandardMaterial({ color: "#1c1e22", roughness: 0.6, metalness: 0.2 }),
    whitePaint: new THREE.MeshPhysicalMaterial({
      color: "#eef0f2", roughness: 0.32, metalness: 0.0, roughnessMap: noise, clearcoat: 0.6, clearcoatRoughness: 0.2
    }),
    silverPaint: new THREE.MeshPhysicalMaterial({
      color: "#c9cdd2", roughness: 0.36, metalness: 0.65, clearcoat: 0.4, clearcoatRoughness: 0.25
    }),
    brushedAluminium: new THREE.MeshStandardMaterial({
      color: "#c4c8cc", metalness: 0.92, roughness: 0.38, roughnessMap: brushed
    }),
    castAluminium: new THREE.MeshStandardMaterial({ color: "#b3b7bb", metalness: 0.85, roughness: 0.42, roughnessMap: noise }),
    chrome: new THREE.MeshStandardMaterial({ color: "#e4e8ec", metalness: 1.0, roughness: 0.12 }),
    stainless: new THREE.MeshStandardMaterial({ color: "#c9ced3", metalness: 0.95, roughness: 0.24, roughnessMap: brushed }),
    darkMetal: new THREE.MeshStandardMaterial({ color: "#3a3d42", metalness: 0.8, roughness: 0.35 }),
    blackGlass: new THREE.MeshPhysicalMaterial({
      color: "#07080a", roughness: 0.08, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.04, reflectivity: 0.6
    }),
    blackPlastic: new THREE.MeshStandardMaterial({ color: "#121315", roughness: 0.7, metalness: 0.05 }),
    rubber: new THREE.MeshStandardMaterial({ color: "#0f1011", roughness: 0.82, metalness: 0.0 }),
    hose: new THREE.MeshPhysicalMaterial({
      color: "#121314", roughness: 0.55, metalness: 0.0, clearcoat: 0.25, clearcoatRoughness: 0.6, sheen: 0.3, sheenColor: new THREE.Color("#3a3d40")
    }),
    door: new THREE.MeshPhysicalMaterial({
      map: doorGraphic(), roughness: 0.28, metalness: 0.0, clearcoat: 0.7, clearcoatRoughness: 0.15
    }),
    lcdCover: new THREE.MeshPhysicalMaterial({
      color: "#ffffff", roughness: 0.03, metalness: 0, transparent: true, opacity: 0.12, depthWrite: false
    }),
    castIron: new THREE.MeshStandardMaterial({ color: "#4d5359", roughness: 0.75, metalness: 0.55, roughnessMap: noise }),
    motorBlue: new THREE.MeshStandardMaterial({ color: "#3c5f86", roughness: 0.5, metalness: 0.35 }),
    pcb: new THREE.MeshStandardMaterial({ color: "#1d6b3a", roughness: 0.6, metalness: 0.1 }),
    copperPipe: new THREE.MeshStandardMaterial({ color: "#9aa0a6", roughness: 0.35, metalness: 0.9 }),
    ghost: new THREE.MeshStandardMaterial({
      color: "#9fb0c2", roughness: 0.4, metalness: 0.1, transparent: true, opacity: 0.1, depthWrite: false
    }),
    product: {
      P1: "#1f8a3b",  // green grip (as shown on the A-Series catalogue unit)
      P2: "#d9a400"   // amber/yellow grip – distinguishes the second product
    }
  };

  // Shared emissive "flow" texture for pipes in the technical view.
  const c = document.createElement("canvas");
  c.width = 128; c.height = 8;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#0b3a44"; ctx.fillRect(0, 0, 128, 8);
  ctx.fillStyle = "#22c3e6"; ctx.fillRect(0, 0, 40, 8);
  const flowTex = new THREE.CanvasTexture(c);
  flowTex.wrapS = flowTex.wrapT = THREE.RepeatWrapping;
  flowTex.repeat.set(14, 1);
  m.flowTexture = flowTex;
  m.pipeActive = new THREE.MeshStandardMaterial({
    color: "#0f2a30", emissive: "#ffffff", emissiveMap: flowTex, emissiveIntensity: 1.4, roughness: 0.4, metalness: 0.4
  });
  return m;
}
