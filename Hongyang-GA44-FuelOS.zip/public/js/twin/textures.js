// Procedural canvas textures for the Hongyang A-Series reconstruction.
// Everything is generated at runtime, so there are no binary assets to ship.
import * as THREE from "three";

export function canvas(w, h) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")];
}

export function toTexture(c, { srgb = true, repeat = null, aniso = 8 } = {}) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  return t;
}

// Deterministic PRNG so textures look identical on every load.
function rng(seed = 1) {
  return () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
}

/** Brushed-metal roughness map (horizontal streaks). */
export function brushedRoughness() {
  const [c, g] = canvas(512, 512);
  const r = rng(7);
  g.fillStyle = "#6a6a6a";
  g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 2600; i++) {
    const y = r() * 512, v = 70 + r() * 90;
    g.strokeStyle = `rgba(${v},${v},${v},${0.25 + r() * 0.35})`;
    g.lineWidth = r() * 1.4 + 0.3;
    g.beginPath();
    const x = r() * 512;
    g.moveTo(x - 80 - r() * 300, y);
    g.lineTo(x + 80 + r() * 300, y + (r() - 0.5) * 1.5);
    g.stroke();
  }
  return toTexture(c, { srgb: false, repeat: [2, 2] });
}

/** Subtle orange-peel noise for powder-coated / painted steel. */
export function paintNoise() {
  const [c, g] = canvas(256, 256);
  const img = g.createImageData(256, 256);
  const r = rng(11);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = 118 + r() * 26;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return toTexture(c, { srgb: false, repeat: [4, 4] });
}

/** Forecourt concrete with expansion joints and staining. */
export function concrete() {
  const [c, g] = canvas(1024, 1024);
  const r = rng(23);
  g.fillStyle = "#6d6e6c";
  g.fillRect(0, 0, 1024, 1024);
  for (let i = 0; i < 26000; i++) {
    const v = 85 + r() * 60;
    g.fillStyle = `rgba(${v},${v},${v - 3},${0.25 + r() * 0.3})`;
    g.fillRect(r() * 1024, r() * 1024, 1 + r() * 2.5, 1 + r() * 2.5);
  }
  for (let i = 0; i < 18; i++) {
    const grd = g.createRadialGradient(0, 0, 0, 0, 0, 40 + r() * 140);
    grd.addColorStop(0, "rgba(40,40,38,0.18)");
    grd.addColorStop(1, "rgba(40,40,38,0)");
    g.save();
    g.translate(r() * 1024, r() * 1024);
    g.fillStyle = grd;
    g.fillRect(-200, -200, 400, 400);
    g.restore();
  }
  g.strokeStyle = "rgba(30,30,30,0.75)";
  g.lineWidth = 3;
  for (const p of [0, 512]) {
    g.beginPath(); g.moveTo(p, 0); g.lineTo(p, 1024); g.stroke();
    g.beginPath(); g.moveTo(0, p); g.lineTo(1024, p); g.stroke();
  }
  return toTexture(c, { repeat: [5, 5] });
}

/** Yellow/black safety chevrons for the island kerb. */
export function hazardStripes() {
  const [c, g] = canvas(256, 64);
  g.fillStyle = "#e8b300";
  g.fillRect(0, 0, 256, 64);
  g.fillStyle = "#151515";
  for (let x = -64; x < 320; x += 64) {
    g.beginPath();
    g.moveTo(x, 64); g.lineTo(x + 32, 64); g.lineTo(x + 64, 0); g.lineTo(x + 32, 0);
    g.closePath(); g.fill();
  }
  return toTexture(c, { repeat: [8, 1] });
}

/** The "[HONG YANG" logotype as used on the A-Series canopy and door. */
export function drawLogo(g, x, y, h, color = "#111") {
  g.save();
  g.translate(x, y);
  g.fillStyle = color;
  const t = h * 0.13;
  // Left bracket mark and right terminal bar.
  g.fillRect(0, 0, t, h);
  g.fillRect(0, 0, h * 0.55, t);
  g.font = `italic 800 ${h * 0.62}px "Arial Black", "Helvetica Neue", Arial, sans-serif`;
  g.textBaseline = "middle";
  const w = g.measureText("HONG YANG").width;
  g.fillText("HONG YANG", t * 2.4, h * 0.56);
  const end = t * 2.4 + w + t * 1.2;
  g.fillRect(end, h - t, h * 0.42, t);
  g.fillRect(end + h * 0.42 - t, h * 0.28, t, h * 0.72);
  g.restore();
  return end + h * 0.42;
}

/** Canopy fascia: white with logo, centred. */
export function canopyFascia(w = 1300, h = 360) {
  const [c, g] = canvas(1024, Math.round((1024 * h) / w));
  const grd = g.createLinearGradient(0, 0, 0, c.height);
  grd.addColorStop(0, "#f7f8f8");
  grd.addColorStop(1, "#e6e8ea");
  g.fillStyle = grd;
  g.fillRect(0, 0, c.width, c.height);
  const lh = c.height * 0.3;
  g.globalAlpha = 0;
  const lw = drawLogo(g, 0, 0, lh);
  g.globalAlpha = 1;
  drawLogo(g, (c.width - lw) / 2, c.height * 0.33, lh, "#151617");
  return toTexture(c);
}

/** Lower door: white panel with the grey flowing wave graphic + logo. */
export function doorGraphic() {
  const [c, g] = canvas(1024, 1024);
  g.fillStyle = "#f2f3f4";
  g.fillRect(0, 0, 1024, 1024);
  const waves = [
    [0.15, "rgba(120,124,130,0.22)", 160], [0.3, "rgba(150,154,160,0.20)", 120],
    [0.42, "rgba(95,100,108,0.18)", 200], [0.55, "rgba(170,174,180,0.25)", 90],
    [0.66, "rgba(110,115,122,0.16)", 150], [0.8, "rgba(140,144,150,0.2)", 110]
  ];
  for (const [fx, col, amp] of waves) {
    g.fillStyle = col;
    g.beginPath();
    const x0 = fx * 1024;
    g.moveTo(x0, -10);
    g.bezierCurveTo(x0 + amp, 250, x0 - amp * 1.2, 520, x0 + amp * 0.4, 760);
    g.bezierCurveTo(x0 + amp, 900, x0 + amp * 0.2, 1000, x0 + 40, 1040);
    g.lineTo(x0 + 120, 1040);
    g.bezierCurveTo(x0 + amp * 0.5, 980, x0 + amp * 1.3, 880, x0 + amp * 0.6, 740);
    g.bezierCurveTo(x0 - amp * 0.9, 520, x0 + amp * 1.3, 260, x0 + 70, -10);
    g.closePath();
    g.fill();
  }
  // Soft vertical sheen.
  const sh = g.createLinearGradient(0, 0, 1024, 0);
  sh.addColorStop(0, "rgba(255,255,255,0)");
  sh.addColorStop(0.45, "rgba(255,255,255,0.35)");
  sh.addColorStop(0.6, "rgba(255,255,255,0)");
  g.fillStyle = sh;
  g.fillRect(0, 0, 1024, 1024);
  drawLogo(g, 640, 900, 52, "#1a1b1c");
  return toTexture(c);
}

/** Black glass head print: SALE/LITER/PRICE legends, safety pictograms, side tag. */
export function headGlass(side, labels) {
  const [c, g] = canvas(1024, 1456);
  const grd = g.createLinearGradient(0, 0, 0, 1456);
  grd.addColorStop(0, "#0d0e10");
  grd.addColorStop(1, "#060607");
  g.fillStyle = grd;
  g.fillRect(0, 0, 1024, 1456);
  g.fillStyle = "#e9ecef";
  g.font = "600 34px Arial, sans-serif";
  g.textAlign = "center";
  // Legends sit between the two LCD windows (layout must match dispenser.js).
  for (const [txt, y] of [["SALE", 205], ["LITER", 290], ["PRICE", 375]]) g.fillText(txt, 512, y);
  // Position numbers above each LCD.
  g.font = "800 46px Arial, sans-serif";
  g.fillStyle = "#cfd3d7";
  g.fillText(labels[0], 250, 92);
  g.fillText(labels[1], 774, 92);
  // Safety pictograms.
  const icon = (x, y, draw, caption) => {
    g.save();
    g.translate(x, y);
    g.strokeStyle = "#e9ecef"; g.lineWidth = 6;
    g.beginPath(); g.arc(0, 0, 38, 0, Math.PI * 2); g.stroke();
    draw();
    g.strokeStyle = "#e5484d"; g.lineWidth = 7;
    g.beginPath(); g.moveTo(-27, -27); g.lineTo(27, 27); g.stroke();
    g.restore();
    g.fillStyle = "#cfd3d7"; g.font = "700 18px Arial"; g.fillText(caption, x, y + 66);
  };
  icon(420, 560, () => { g.fillStyle = "#e9ecef"; g.fillRect(-10, -20, 20, 38); }, "NO MOBILE");
  icon(604, 560, () => { g.fillStyle = "#e9ecef"; g.fillRect(-22, -4, 40, 9); }, "NO SMOKING");
  // Side identification.
  g.fillStyle = "#3a3e44";
  g.fillRect(452, 1270, 120, 120);
  g.fillStyle = "#f2f3f4";
  g.font = "900 88px Arial";
  g.fillText(side, 512, 1362);
  g.font = "700 20px Arial";
  g.fillStyle = "#8b929b";
  g.fillText("SIDE", 512, 1260);
  return toTexture(c);
}

/** Aluminium nameplate. Only confirmed identity data is printed. */
export function nameplate(eq) {
  const [c, g] = canvas(640, 400);
  const grd = g.createLinearGradient(0, 0, 640, 400);
  grd.addColorStop(0, "#d9dcdf");
  grd.addColorStop(1, "#b9bdc2");
  g.fillStyle = grd;
  g.fillRect(0, 0, 640, 400);
  g.strokeStyle = "#7c8187"; g.lineWidth = 6; g.strokeRect(10, 10, 620, 380);
  drawLogo(g, 34, 30, 46, "#1b1c1e");
  g.fillStyle = "#1b1c1e";
  g.font = "700 26px Arial"; g.fillText("FUEL DISPENSER", 34, 120);
  g.font = "600 24px 'Courier New', monospace";
  const rows = [["MODEL", eq.model], ["SERIAL No.", eq.serial], ["CONFIG.", `${eq.configuration} · 2 SIDES · 4 NOZZLES`], ["SERIES", eq.series]];
  rows.forEach(([k, v], i) => { g.fillText(k, 34, 175 + i * 46); g.fillText(v, 230, 175 + i * 46); });
  g.font = "italic 16px Arial"; g.fillStyle = "#4a4f55";
  g.fillText("Digital-twin reproduction of identity data", 34, 372);
  // Rivets
  g.fillStyle = "#8d9298";
  for (const [x, y] of [[26, 26], [614, 26], [26, 374], [614, 374]]) { g.beginPath(); g.arc(x, y, 8, 0, 7); g.fill(); }
  return toTexture(c);
}

// ---------------------------------------------------------------- LCD
const SEG = { // 7-segment map a b c d e f g
  "0": "abcdef", "1": "bc", "2": "abged", "3": "abgcd", "4": "fgbc", "5": "afgcd", "6": "afgedc",
  "7": "abc", "8": "abcdefg", "9": "abcfgd", "-": "g", "E": "afged", "r": "eg", " ": "", "P": "abfge", "L": "fed", "o": "gcde", "F": "afge"
};

function drawSeg(g, ch, x, y, w, h, on, ghost) {
  const t = w * 0.17, segs = SEG[ch] ?? "";
  const shape = {
    a: [x + t, y, w - 2 * t, t], d: [x + t, y + h - t, w - 2 * t, t], g: [x + t, y + h / 2 - t / 2, w - 2 * t, t],
    f: [x, y + t, t, h / 2 - t], b: [x + w - t, y + t, t, h / 2 - t],
    e: [x, y + h / 2, t, h / 2 - t], c: [x + w - t, y + h / 2, t, h / 2 - t]
  };
  for (const k of "abcdefg") {
    const [sx, sy, sw, sh] = shape[k];
    g.fillStyle = segs.includes(k) ? on : ghost;
    // Slight italic skew like real LCD digits.
    g.beginPath();
    const sk = 0.08;
    g.moveTo(sx + (h - (sy - y)) * sk, sy);
    g.lineTo(sx + sw + (h - (sy - y)) * sk, sy);
    g.lineTo(sx + sw + (h - (sy + sh - y)) * sk, sy + sh);
    g.lineTo(sx + (h - (sy + sh - y)) * sk, sy + sh);
    g.closePath();
    g.fill();
  }
}

/** Draw a right-aligned 7-segment number string into a region. */
export function drawDigits(g, text, right, y, digitW, digitH, cells, on, ghost) {
  const chars = [];
  for (const ch of text) {
    if (ch === ".") chars.length && (chars[chars.length - 1].dot = true);
    else chars.push({ ch, dot: false });
  }
  while (chars.length < cells) chars.unshift({ ch: " ", dot: false });
  const gap = digitW * 0.32;
  let x = right - cells * (digitW + gap);
  for (const { ch, dot } of chars.slice(-cells)) {
    drawSeg(g, ch, x, y, digitW, digitH, on, ghost);
    g.fillStyle = dot ? on : ghost;
    g.fillRect(x + digitW + gap * 0.2, y + digitH - digitW * 0.17, digitW * 0.17, digitW * 0.17);
    x += digitW + gap;
  }
}
