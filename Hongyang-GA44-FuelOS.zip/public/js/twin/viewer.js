// TwinViewer – renderer, scene, camera system, picking and nozzle interaction
// for the Hongyang CMD1687SK-GA44 digital twin. Rendering only: it never
// talks to the backend directly; it raises callbacks and receives telemetry.
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { CSS2DRenderer, CSS2DObject } from "three/addons/renderers/CSS2DRenderer.js";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { createMaterials } from "./materials.js";
import { concrete, hazardStripes, canvas, toTexture } from "./textures.js";
import { buildDispenser, DIM } from "./dispenser.js";
import { HOSE_ANCHOR, HOSE_ANCHOR_DIR } from "./nozzle.js";
import { statusMeta } from "../status.js";

const ISLAND_H = 0.15;
const ease = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export const COMPONENTS = {
  canopy: { name: "Canopy & fascia", text: "Illuminated canopy carrying the HONG YANG fascia on both faces and the four high-hang hose outlets.", est: false },
  column: { name: "Support column", text: "Chamfered graphite column; carries the product pipework from the hydraulic bay up to the canopy (routing estimated).", est: true },
  "side-wing": { name: "Ship-type side wing", text: "Angular prow-shaped side structure characteristic of the A-Series; contains the nozzle boot recesses.", est: false },
  "display-head": { name: "Display head", text: "Black-glass electronic head: per side two LCD price displays and two membrane keypads (GA44: 4 displays, 4 keyboards).", est: false },
  door: { name: "Hydraulic bay door", text: "Lockable lower access door with the A-Series wave graphic.", est: false },
  plinth: { name: "Base plinth", text: "Anchoring base frame on the pump island.", est: true },
  "hydraulic-bay": { name: "Hydraulic compartment", text: "Houses pumps, flowmeters and valves.", est: true },
  nameplate: { name: "Identification plate", text: "Manufacturer, model, serial and configuration of this unit.", est: false },
  pump: { name: "Pump unit", text: "Suction pump + motor. GA44 has 2 pumps (one per product). Assignment to positions is an estimate.", est: true },
  flowmeter: { name: "Flowmeter + pulser", text: "One of 4 flowmeters (one per nozzle). Pulser output feeds the mainboard.", est: true },
  pipe: { name: "Product pipe", text: "Pump → meter → column → canopy outlet. Routing is a schematic estimate.", est: true },
  mainboard: { name: "Mainboard", text: "GA44 has 2 mainboards; one per side is assumed.", est: true }
};

export class TwinViewer {
  constructor(host, config, callbacks = {}) {
    this.host = host;
    this.config = config;
    this.cb = callbacks;
    this.selected = null;
    this.hovered = null;
    this.mode = "normal";
    this.modeT = { technical: 0, exploded: 0 };
    this.active = true;
    this.telemetry = null;
    this.nozzleState = {};
    this.frames = 0; this.fps = 0; this.fpsT = performance.now();
    this.tween = null;
    this.timer = new THREE.Timer();

    this.initRenderer();
    this.initScene();
    this.mats = createMaterials();
    this.model = buildDispenser(this.mats, config);
    this.model.root.position.y = ISLAND_H;
    this.scene.add(this.model.root);
    this.collectPickables();
    this.initLabels();
    this.initNozzles();
    this.initEvents();
    this.view("overview", false);
    this.renderer.setAnimationLoop(() => this.frame());
  }

  // ------------------------------------------------------------------ setup
  initRenderer() {
    const r = this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.05;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFShadowMap;
    this.host.appendChild(r.domElement);
    r.domElement.setAttribute("aria-label", "Interactive 3D model of the Hongyang CMD1687SK-GA44 dispenser");

    this.labelRenderer = new CSS2DRenderer();
    this.labelRenderer.domElement.className = "twin-labels";
    this.host.appendChild(this.labelRenderer.domElement);

    this.camera = new THREE.PerspectiveCamera(36, 1, 0.05, 120);
    this.controls = new OrbitControls(this.camera, r.domElement);
    Object.assign(this.controls, {
      enableDamping: true, dampingFactor: 0.08, minDistance: 0.45, maxDistance: 12,
      maxPolarAngle: Math.PI * 0.495, screenSpacePanning: true, autoRotateSpeed: 0.8
    });
    this.controls.addEventListener("start", () => { this.tween = null; });

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.host);
    this.resize();
  }

  initScene() {
    const scene = this.scene = new THREE.Scene();
    const [bc, bg] = canvas(16, 512);
    const grd = bg.createLinearGradient(0, 0, 0, 512);
    grd.addColorStop(0, "#23272c"); grd.addColorStop(0.55, "#3a3f45"); grd.addColorStop(1, "#2a2d31");
    bg.fillStyle = grd; bg.fillRect(0, 0, 16, 512);
    scene.background = toTexture(bc);
    scene.fog = new THREE.Fog("#33373c", 10, 30);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 1.05;
    pmrem.dispose();

    scene.add(new THREE.HemisphereLight("#e6ecf2", "#3a3631", 0.95));
    const key = this.keyLight = new THREE.DirectionalLight("#fff4e6", 2.8);
    key.position.set(3.2, 6.5, 4.5);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -2.6, right: 2.6, top: 3.4, bottom: -1.2, near: 1, far: 16 });
    key.shadow.bias = -0.0003;
    key.shadow.normalBias = 0.02;
    key.shadow.radius = 3;
    scene.add(key);
    const rim = new THREE.DirectionalLight("#b8c9ff", 1.4);
    rim.position.set(-4, 3.5, -4);
    scene.add(rim);
    const fill = new THREE.DirectionalLight("#ffffff", 0.7);
    fill.position.set(-3, 2, 3);
    scene.add(fill);

    // Forecourt slab.
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(60, 60),
      new THREE.MeshStandardMaterial({ map: concrete(), roughness: 0.92, metalness: 0 }));
    ground.material.map.repeat.set(12, 12);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Pump island with painted safety kerb and crash-protection bollards.
    const islandMat = new THREE.MeshStandardMaterial({ color: "#8b8d8c", roughness: 0.85, map: concrete() });
    islandMat.map.repeat.set(1.5, 0.7);
    const island = new THREE.Mesh(new RoundedBoxGeometry(3.4, ISLAND_H, 1.6, 2, 0.03), islandMat);
    island.position.y = ISLAND_H / 2;
    island.receiveShadow = island.castShadow = true;
    scene.add(island);
    const hz = hazardStripes();
    const kerbMat = new THREE.MeshStandardMaterial({ map: hz, roughness: 0.7 });
    for (const [w, x, z, ry] of [[3.4, 0, 0.802, 0], [3.4, 0, -0.802, Math.PI], [1.6, 1.702, 0, Math.PI / 2], [1.6, -1.702, 0, -Math.PI / 2]]) {
      const k = new THREE.Mesh(new THREE.PlaneGeometry(w, ISLAND_H - 0.01), kerbMat);
      k.position.set(x, ISLAND_H / 2, z);
      k.rotation.y = ry;
      scene.add(k);
    }
    const yellow = new THREE.MeshStandardMaterial({ color: "#e8b300", roughness: 0.45, metalness: 0.2 });
    const black = new THREE.MeshStandardMaterial({ color: "#151515", roughness: 0.5 });
    for (const x of [-1.45, 1.45]) {
      const b = new THREE.Group();
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.95, 24), yellow);
      post.position.y = 0.475;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.0605, 0.0605, 0.08, 24), black);
      band.position.y = 0.72;
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.06, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), yellow);
      cap.position.y = 0.95;
      b.add(post, band, cap);
      b.traverse(o => { o.castShadow = o.isMesh; });
      b.position.set(x, ISLAND_H, 0);
      scene.add(b);
    }

    // Soft contact shadow (cheap ambient-occlusion substitute).
    const [sc, sg] = canvas(256, 256);
    const rg = sg.createRadialGradient(128, 128, 10, 128, 128, 128);
    rg.addColorStop(0, "rgba(0,0,0,0.55)"); rg.addColorStop(0.6, "rgba(0,0,0,0.25)"); rg.addColorStop(1, "rgba(0,0,0,0)");
    sg.fillStyle = rg; sg.fillRect(0, 0, 256, 256);
    const ao = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.0),
      new THREE.MeshBasicMaterial({ map: toTexture(sc), transparent: true, depthWrite: false }));
    ao.rotation.x = -Math.PI / 2;
    ao.position.y = ISLAND_H + 0.002;
    scene.add(ao);
  }

  collectPickables() {
    this.pickables = [];
    this.model.root.traverse(o => { if (o.isMesh && o.userData.pick) this.pickables.push(o); });
  }

  initLabels() {
    this.labels = {};
    for (const [id, p] of Object.entries(this.model.positions)) {
      const el = document.createElement("button");
      el.className = "tw-label";
      el.type = "button";
      el.innerHTML = `<i></i><b>${id}</b><span></span>`;
      el.addEventListener("pointerdown", e => e.stopPropagation());
      el.addEventListener("click", () => this.cb.onSelect?.(id));
      const obj = new CSS2DObject(el);
      obj.position.copy(p.labelAnchor);
      p.face.add(obj);
      this.labels[id] = { el, obj };
    }
    // Technical labels for internal components.
    this.techLabels = [];
    const addTech = (parent, pos, html) => {
      const el = document.createElement("div");
      el.className = "tw-tech";
      el.innerHTML = html;
      const o = new CSS2DObject(el);
      o.position.copy(pos);
      o.visible = false;
      parent.add(o);
      this.techLabels.push(o);
    };
    const serves = {};
    for (const [id, p] of Object.entries(this.config.positions)) (serves[p.pump] ||= []).push(id);
    for (const [pumpId, pump] of Object.entries(this.model.pumps)) {
      const product = Object.values(this.config.positions).find(p => p.pump === pumpId).product;
      addTech(pump.group, new THREE.Vector3(0, 0.33, 0), `<b>${pumpId}</b> · ${product}<br>→ ${serves[pumpId].join(" + ")} <em>est.</em>`);
    }
    addTech(this.model.internals, new THREE.Vector3(0, 1.7, 0.2), "<b>MB-A</b> mainboard <em>est.</em>");
    addTech(this.model.internals, new THREE.Vector3(0, 1.7, -0.2), "<b>MB-B</b> mainboard <em>est.</em>");
    for (const [id, p] of Object.entries(this.model.positions)) {
      addTech(p.face, new THREE.Vector3(p.sx * 0.15, 0.78, 0.12), `FM-${id}`);
    }
  }

  initNozzles() {
    for (const [id, p] of Object.entries(this.model.positions)) {
      this.nozzleState[id] = {
        mode: "holstered", t: 0, from: null, to: null,
        liftedPos: p.liftedHome.clone(), squeeze: 0
      };
      p.nozzle.group.position.copy(p.holsterPose.pos);
      p.nozzle.group.quaternion.copy(p.holsterPose.quat);
      this.updateHose(id);
    }
  }

  // ------------------------------------------------------------ nozzle pose
  liftedQuat(id, pos) {
    const p = this.model.positions[id];
    const away = new THREE.Vector3(pos.x - p.sx * DIM.holsterX, 0, pos.z - DIM.halfDepth);
    if (away.lengthSq() < 1e-4) away.set(0, 0, 1);
    away.normalize();
    const X = new THREE.Vector3(away.x * 0.85, -0.5, away.z * 0.85).normalize();
    return this.basis(X, new THREE.Vector3(0, 1, 0));
  }

  basis(X, yHint) {
    const Y = yHint.clone().addScaledVector(X, -yHint.dot(X)).normalize();
    const Z = new THREE.Vector3().crossVectors(X, Y);
    return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(X, Y, Z));
  }

  updateHose(id) {
    const p = this.model.positions[id];
    const g = p.nozzle.group;
    g.updateMatrix();
    const anchor = HOSE_ANCHOR.clone().applyMatrix4(g.matrix);
    const dir = HOSE_ANCHOR_DIR.clone().applyQuaternion(g.quaternion);
    if (p.hose.update(p.outletPoint, anchor, dir) && p.hose.curve) {
      // Breakaway coupling sits ~0.35 m down the hose from the outlet.
      const c = p.hose.curve, u = Math.min(0.35 / DIM.hoseLength, 0.2);
      p.breakaway.position.copy(c.getPointAt(u));
      p.breakaway.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), c.getTangentAt(u));
    }
  }

  animateNozzles(dt) {
    for (const [id, st] of Object.entries(this.nozzleState)) {
      const p = this.model.positions[id];
      const g = p.nozzle.group;
      const tele = this.telemetry?.positions?.[id];
      const wantLifted = Boolean(tele?.nozzleLifted);

      if (wantLifted && (st.mode === "holstered" || st.mode === "returning")) {
        st.mode = "lifting"; st.t = 0;
        st.from = { pos: g.position.clone(), quat: g.quaternion.clone() };
      } else if (!wantLifted && (st.mode === "lifted" || st.mode === "lifting")) {
        st.mode = "returning"; st.t = 0;
        st.from = { pos: g.position.clone(), quat: g.quaternion.clone() };
        if (this.drag?.id === id) this.endDrag();
      }

      let moved = false;
      if (st.mode === "lifting" || st.mode === "returning") {
        st.t = Math.min(1, st.t + dt / 0.75);
        const e = ease(st.t);
        const toPos = st.mode === "lifting" ? st.liftedPos : p.holsterPose.pos;
        const toQuat = st.mode === "lifting" ? this.liftedQuat(id, st.liftedPos) : p.holsterPose.quat;
        g.position.lerpVectors(st.from.pos, toPos, e);
        g.position.y += Math.sin(Math.PI * e) * 0.1;               // lift arc out of the boot
        g.position.z += Math.sin(Math.PI * e) * 0.05;
        g.quaternion.slerpQuaternions(st.from.quat, toQuat, e);
        if (st.t >= 1) st.mode = st.mode === "lifting" ? "lifted" : "holstered";
        moved = true;
      } else if (st.mode === "lifted" && !g.position.equals(st.liftedPos)) {
        g.position.lerp(st.liftedPos, Math.min(1, dt * 14));
        g.quaternion.slerp(this.liftedQuat(id, g.position), Math.min(1, dt * 10));
        if (g.position.distanceToSquared(st.liftedPos) < 1e-8) g.position.copy(st.liftedPos);
        moved = true;
      }
      // Trigger squeeze while dispensing.
      const squeezeTarget = tele?.status === "dispensing" ? 1 : 0;
      st.squeeze += (squeezeTarget - st.squeeze) * Math.min(1, dt * 8);
      const trigger = g.getObjectByName("trigger");
      if (trigger) trigger.position.y = st.squeeze * 0.012;
      if (moved) this.updateHose(id);
    }
  }

  // ------------------------------------------------------------- telemetry
  setTelemetry(snapshot) {
    this.telemetry = snapshot;
    for (const [id, p] of Object.entries(this.model.positions)) {
      const t = snapshot.positions?.[id];
      if (!t) continue;
      const meta = statusMeta(t.status);
      p.ledMat.emissive.set(meta.color);
      p.lcd.paint(t, Math.floor(Date.now() / 500) % 2 === 0);
      const lab = this.labels[id];
      lab.el.style.setProperty("--c", meta.color);
      lab.el.querySelector("span").textContent = meta.short;
      lab.el.dataset.status = t.status;
    }
    // Pump activity drives belt rotation & pipe flow in the technical view.
    for (const [id, pipe] of Object.entries(this.model.pipes)) {
      const on = snapshot.positions?.[id]?.status === "dispensing";
      pipe.material = on ? this.mats.pipeActive : this.mats.copperPipe;
    }
  }

  // -------------------------------------------------------------- selection
  select(id) {
    this.selected = id;
    for (const [pid, l] of Object.entries(this.labels)) l.el.classList.toggle("selected", pid === id);
  }

  // ----------------------------------------------------------------- camera
  presetFor(name) {
    const y0 = ISLAND_H;
    const sel = this.selected && this.model.positions[this.selected];
    const presets = {
      overview: [new THREE.Vector3(2.15, 1.85, 2.95), new THREE.Vector3(0, y0 + 1.18, 0)],
      A: [new THREE.Vector3(0, 1.6, 3.5), new THREE.Vector3(0, y0 + 1.2, 0)],
      B: [new THREE.Vector3(0, 1.6, -3.5), new THREE.Vector3(0, y0 + 1.2, 0)],
      left: [new THREE.Vector3(-3.5, 1.6, 0.01), new THREE.Vector3(0, y0 + 1.2, 0)],
      right: [new THREE.Vector3(3.5, 1.6, 0.01), new THREE.Vector3(0, y0 + 1.2, 0)],
      top: [new THREE.Vector3(0.01, 5.2, 0.5), new THREE.Vector3(0, y0 + 1, 0)]
    };
    if (sel && (name === "close" || name === "nozzle")) {
      sel.face.updateMatrixWorld();
      if (name === "close") {
        const target = sel.face.localToWorld(sel.focus.clone().add(new THREE.Vector3(0, 0, 0)));
        const pos = sel.face.localToWorld(sel.focus.clone().add(new THREE.Vector3(sel.sx * 0.35, 0.12, 1.25)));
        return [pos, target];
      }
      const n = sel.nozzle.group.getWorldPosition(new THREE.Vector3());
      const off = sel.face.localToWorld(new THREE.Vector3(sel.sx * 0.3, 0.12, DIM.halfDepth + 0.55))
        .sub(sel.face.localToWorld(new THREE.Vector3(0, 0, DIM.halfDepth)));
      return [n.clone().add(off), n];
    }
    return presets[name] || presets.overview;
  }

  view(name, animate = true) {
    const [pos, target] = this.presetFor(name);
    if (!animate) {
      this.camera.position.copy(pos);
      this.controls.target.copy(target);
      this.controls.update();
      return;
    }
    // Interpolate in spherical coordinates around the target so transitions
    // orbit around the dispenser instead of cutting through it.
    const fromT = this.controls.target.clone();
    const fromS = new THREE.Spherical().setFromVector3(this.camera.position.clone().sub(fromT));
    const toS = new THREE.Spherical().setFromVector3(pos.clone().sub(target));
    let dTheta = toS.theta - fromS.theta;
    if (dTheta > Math.PI) dTheta -= 2 * Math.PI;
    if (dTheta < -Math.PI) dTheta += 2 * Math.PI;
    this.tween = { t: 0, fromT, toT: target, fromS, toS, dTheta };
  }

  stepTween(dt) {
    const tw = this.tween;
    if (!tw) return;
    tw.t = Math.min(1, tw.t + dt / 1.1);
    const e = ease(tw.t);
    const s = new THREE.Spherical(
      THREE.MathUtils.lerp(tw.fromS.radius, tw.toS.radius, e),
      THREE.MathUtils.lerp(tw.fromS.phi, tw.toS.phi, e),
      tw.fromS.theta + tw.dTheta * e
    );
    this.controls.target.lerpVectors(tw.fromT, tw.toT, e);
    this.camera.position.setFromSpherical(s).add(this.controls.target);
    if (tw.t >= 1) this.tween = null;
  }

  rotate(deg) {
    const t = this.controls.target;
    const offset = this.camera.position.clone().sub(t).applyAxisAngle(new THREE.Vector3(0, 1, 0), THREE.MathUtils.degToRad(deg));
    const [pos, target] = [t.clone().add(offset), t.clone()];
    const fromS = new THREE.Spherical().setFromVector3(this.camera.position.clone().sub(t));
    const toS = new THREE.Spherical().setFromVector3(pos.clone().sub(target));
    this.tween = { t: 0, fromT: t.clone(), toT: target, fromS, toS, dTheta: THREE.MathUtils.degToRad(deg) };
  }

  setAutoRotate(on) { this.controls.autoRotate = on; }

  // ------------------------------------------------------------------ modes
  setMode(mode) {
    this.mode = mode;
    const technical = mode === "technical" || mode === "exploded";
    this.model.internals.visible = true;
    for (const m of this.model.shell) {
      m.userData.baseMaterial ??= m.material;
      m.material = technical ? this.mats.ghost : m.userData.baseMaterial;
      m.castShadow = !technical;
    }
    for (const l of this.techLabels) l.visible = technical;
    this.host.classList.toggle("mode-technical", technical);
  }

  stepModes(dt) {
    const target = { technical: this.mode !== "normal" ? 1 : 0, exploded: this.mode === "exploded" ? 1 : 0 };
    for (const k of ["technical", "exploded"]) {
      this.modeT[k] += (target[k] - this.modeT[k]) * Math.min(1, dt * 5);
    }
    const e = this.modeT.exploded;
    for (const { obj, base, offset } of this.model.explodables) obj.position.copy(base).addScaledVector(offset, e);
    this.model.internals.visible = this.modeT.technical > 0.02;
    // Rotate the belts of running pumps.
    const running = this.telemetry?.pumps || {};
    for (const [id, p] of Object.entries(this.model.pumps)) if (running[id]?.running) p.belt.rotation.x += dt * 12;
    if (this.mats.flowTexture) this.mats.flowTexture.offset.x -= dt * 1.6;
  }

  setQuality({ shadows, pixelRatio }) {
    if (shadows !== undefined) {
      this.renderer.shadowMap.enabled = shadows;
      this.keyLight.castShadow = shadows;
      this.scene.traverse(o => { if (o.material) [].concat(o.material).forEach(m => { m.needsUpdate = true; }); });
    }
    if (pixelRatio) {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, pixelRatio));
      this.resize();
    }
  }

  // ----------------------------------------------------------------- events
  ndc(e) {
    const r = this.renderer.domElement.getBoundingClientRect();
    return new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  }

  pick(e) {
    this.raycaster ??= new THREE.Raycaster();
    this.raycaster.setFromCamera(this.ndc(e), this.camera);
    const hits = this.raycaster.intersectObjects(this.pickables.filter(o => o.material !== this.mats.ghost && isVisible(o)), false);
    return hits[0] || null;
  }

  initEvents() {
    const el = this.renderer.domElement;
    this.tooltip = document.createElement("div");
    this.tooltip.className = "tw-tooltip";
    this.host.appendChild(this.tooltip);

    el.addEventListener("pointerdown", e => {
      if (e.button !== 0) return;
      this.down = { x: e.clientX, y: e.clientY, hit: this.pick(e) };
      const pick = this.down.hit?.object.userData.pick;
      if (pick?.type === "position" && pick.part === "nozzle" && this.nozzleState[pick.id].mode === "lifted") {
        this.beginDrag(pick.id, e);
      }
    });
    el.addEventListener("pointermove", e => {
      if (this.drag) return this.moveDrag(e);
      this.pendingHover = e;
    });
    el.addEventListener("pointerup", e => {
      const d = this.down;
      this.down = null;
      const wasDragging = this.drag?.moved;
      if (this.drag) this.endDrag();
      if (!d || wasDragging || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 5) return;
      this.click(d.hit);
    });
    el.addEventListener("dblclick", e => {
      const pick = this.pick(e)?.object.userData.pick;
      if (pick?.type === "position" && pick.part === "nozzle" && this.nozzleState[pick.id].mode === "lifted") {
        this.cb.onNozzle?.(pick.id, "hang");
      }
    });
    el.addEventListener("pointerleave", () => { this.pendingHover = null; this.setHover(null); });
  }

  click(hit) {
    if (!hit) return;
    const pick = hit.object.userData.pick;
    if (pick.type === "component") {
      const info = COMPONENTS[pick.id];
      this.cb.onComponent?.({ ...pick, ...info });
      return;
    }
    const id = pick.id;
    this.cb.onSelect?.(id);
    const st = this.nozzleState[id];
    if (pick.part === "nozzle" && st.mode === "holstered") this.cb.onNozzle?.(id, "lift");
    else if (pick.part === "holster" && st.mode === "lifted") this.cb.onNozzle?.(id, "hang");
    else if (pick.part === "keypad") {
      const key = hit.object.userData.keypad?.keyAt(hit.uv);
      if (key) {
        const res = hit.object.userData.keypad.press(key);
        this.cb.onKeypad?.(id, key, res?.submit || null);
      }
    }
  }

  hoverText(pick) {
    if (!pick) return "";
    if (pick.type === "component") return COMPONENTS[pick.id]?.name || pick.id;
    const st = this.nozzleState[pick.id];
    const product = this.config.positions[pick.id].product;
    return {
      nozzle: st.mode === "holstered" ? `${pick.id} nozzle (${product}) — click to lift` : `${pick.id} nozzle — drag to move · double-click to return`,
      holster: st.mode === "lifted" ? `${pick.id} nozzle boot — click to return nozzle` : `${pick.id} nozzle boot`,
      display: `${pick.id} price display`,
      keypad: `${pick.id} keypad — enter preset, OK to authorise`,
      status: `${pick.id} status lamp`,
      hose: `${pick.id} hose (high-hang, ~${DIM.hoseLength} m est.)`
    }[pick.part] || pick.id;
  }

  setHover(hit, e) {
    const pick = hit?.object.userData.pick || null;
    const key = pick ? `${pick.type}:${pick.id}:${pick.part || ""}` : "";
    if (key !== this.hoverKey) {
      this.hoverKey = key;
      this.hovered = pick?.type === "position" ? pick.id : null;
      this.renderer.domElement.style.cursor = pick ? (this.drag ? "grabbing" : "pointer") : "";
      this.tooltip.textContent = this.hoverText(pick);
    }
    this.tooltip.classList.toggle("show", Boolean(pick));
    if (pick && e) {
      const r = this.host.getBoundingClientRect();
      this.tooltip.style.transform = `translate(${e.clientX - r.left + 14}px, ${e.clientY - r.top + 14}px)`;
    }
  }

  beginDrag(id, e) {
    const p = this.model.positions[id];
    const g = p.nozzle.group;
    const world = g.getWorldPosition(new THREE.Vector3());
    const normal = this.camera.getWorldDirection(new THREE.Vector3()).negate();
    this.drag = { id, plane: new THREE.Plane().setFromNormalAndCoplanarPoint(normal, world), moved: false, start: { x: e.clientX, y: e.clientY } };
    this.controls.enabled = false;
    this.renderer.domElement.setPointerCapture?.(e.pointerId);
    this.renderer.domElement.style.cursor = "grabbing";
  }

  moveDrag(e) {
    const d = this.drag;
    if (Math.hypot(e.clientX - d.start.x, e.clientY - d.start.y) > 4) d.moved = true;
    if (!d.moved) return;
    this.raycaster.setFromCamera(this.ndc(e), this.camera);
    const hit = new THREE.Vector3();
    if (!this.raycaster.ray.intersectPlane(d.plane, hit)) return;
    const p = this.model.positions[d.id];
    const local = p.face.worldToLocal(hit);
    // Constrained working envelope in front of the position.
    local.x = THREE.MathUtils.clamp(local.x, p.sx * DIM.holsterX - 1.0, p.sx * DIM.holsterX + 1.0);
    local.y = THREE.MathUtils.clamp(local.y, 0.4, 1.6);
    local.z = THREE.MathUtils.clamp(local.z, DIM.halfDepth + 0.3, DIM.halfDepth + 1.9);
    // Hose reach limit from the canopy outlet.
    const maxReach = DIM.hoseLength - 0.5;
    const off = local.clone().sub(p.outletPoint);
    if (off.length() > maxReach) local.copy(p.outletPoint).addScaledVector(off.normalize(), maxReach);
    this.nozzleState[d.id].liftedPos.copy(local);
  }

  endDrag() {
    this.drag = null;
    this.controls.enabled = true;
    this.renderer.domElement.style.cursor = "";
  }

  /** Return a lifted nozzle to its default hand-held position (visual only). */
  resetNozzlePose(id) {
    this.nozzleState[id].liftedPos.copy(this.model.positions[id].liftedHome);
  }

  // ------------------------------------------------------------------ loop
  resize() {
    const w = Math.max(this.host.clientWidth, 1), h = Math.max(this.host.clientHeight, 1);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.labelRenderer.setSize(w, h);
  }

  setActive(active) {
    this.active = active;
    if (active) { this.timer.update(); this.resize(); }
  }

  frame() {
    if (!this.active) return;
    this.timer.update();
    const dt = Math.min(this.timer.getDelta(), 0.1);
    if (this.pendingHover && !this.drag) {
      this.setHover(this.pick(this.pendingHover), this.pendingHover);
      this.pendingHover = null;
    }
    this.stepTween(dt);
    this.stepModes(dt);
    this.animateNozzles(dt);

    // Dim labels of the side facing away from the camera.
    const camDir = this.camera.position.clone().setY(0);
    for (const [id, p] of Object.entries(this.model.positions)) {
      const facing = new THREE.Vector3(0, 0, 1).applyQuaternion(p.face.quaternion).dot(camDir) > 0;
      this.labels[id].el.classList.toggle("behind", !facing);
    }

    // Selection / hover highlight + blinking status lamps.
    const now = performance.now() / 1000;
    for (const [id, p] of Object.entries(this.model.positions)) {
      const status = this.telemetry?.positions?.[id]?.status;
      const sel = id === this.selected, hov = id === this.hovered;
      const target = sel ? 0.65 + 0.35 * Math.sin(now * 4) : hov ? 0.4 : 0;
      const m = p.highlight.userData.material;
      m.opacity += (target - m.opacity) * Math.min(1, dt * 10);
      p.highlight.visible = m.opacity > 0.01;
      const blink = status === "fault" ? (Math.sin(now * 8) > 0 ? 3 : 0.2) : status === "dispensing" ? 1.8 + Math.sin(now * 6) : 2.2;
      p.ledMat.emissiveIntensity = status === "offline" ? 0.05 : blink;
    }

    this.controls.update(dt);
    this.renderer.render(this.scene, this.camera);
    this.labelRenderer.render(this.scene, this.camera);

    this.frames++;
    if (performance.now() - this.fpsT > 1000) {
      this.fps = Math.round((this.frames * 1000) / (performance.now() - this.fpsT));
      this.frames = 0;
      this.fpsT = performance.now();
    }
  }

  stats() {
    const i = this.renderer.info;
    return { fps: this.fps, drawCalls: i.render.calls, triangles: i.render.triangles, geometries: i.memory.geometries, textures: i.memory.textures };
  }
}

function isVisible(o) {
  for (let n = o; n; n = n.parent) if (!n.visible) return false;
  return true;
}
