// Geometry for the Hongyang A-Series CMD1687SK-GA44 (two sides, four nozzles).
//
// Reference: manufacturer A-Series catalogue photo (chinahongyang.com).
// Form language reproduced: white canopy with logo on two chamfered graphite
// columns, "ship-type" (prow-shaped) graphite side wings, black-glass display
// head, white lower door with wave graphic, high-hang hoses from canopy corners,
// nozzle boots in the recess beside the head.
// All dimensions are ENGINEERING ESTIMATES scaled from that photo (metres).
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { canopyFascia, headGlass, nameplate } from "./textures.js";
import { LcdDisplay, Keypad } from "./displays.js";
import { buildNozzle, Hose, HOSE_ANCHOR, HOSE_ANCHOR_DIR } from "./nozzle.js";

// ---- Key dimensions (estimates) --------------------------------------------
export const DIM = {
  frontHalf: 0.43,     // half-width of the flat A/B faces
  apexHalf: 0.53,      // half-width at the prow apex of the side wings
  apexDepth: 0.03,
  halfDepth: 0.26,
  doorTop: 0.99,
  wingTop: 1.56,
  headHalf: 0.285,
  headTop: 1.8,
  columnX: 0.385,
  canopyBottom: 2.16,
  canopyTop: 2.52,
  holsterX: 0.357,
  outletX: 0.58,
  hoseLength: 3.9
};
const D = DIM;

function plan(points) {
  // Plan polygon in (x, z) → THREE.Shape (shape-y = world z after rotation).
  const s = new THREE.Shape();
  points.forEach(([x, z], i) => (i ? s.lineTo(x, z) : s.moveTo(x, z)));
  s.closePath();
  return s;
}

function extrudeVertical(shape, y0, y1, material, bevel = 0.008) {
  const h = y1 - y0 - 2 * bevel;
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: h, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments: 6
  });
  geo.rotateX(Math.PI / 2);          // shape (x, s, d) → (x, -d, s)
  geo.translate(0, y1 - bevel, 0);
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, material);
  mesh.castShadow = mesh.receiveShadow = true;
  return mesh;
}

function rbox(w, h, d, r, material, segments = 3) {
  const mesh = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, segments, Math.min(r, w / 2, h / 2, d / 2)), material);
  mesh.castShadow = mesh.receiveShadow = true;
  return mesh;
}

function basisQuat(xAxis, yHint) {
  const X = xAxis.clone().normalize();
  const Y = yHint.clone().addScaledVector(X, -yHint.dot(X)).normalize();
  const Z = new THREE.Vector3().crossVectors(X, Y);
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(X, Y, Z));
}

function tag(obj, pick) {
  obj.traverse(o => { if (o.isMesh) o.userData.pick = pick; });
  return obj;
}

/**
 * Builds the full dispenser. `config` = { equipment, positions } from the API.
 */
export function buildDispenser(mats, config) {
  const root = new THREE.Group();
  root.name = "Hongyang-CMD1687SK-GA44";
  const shell = [];          // meshes that turn translucent in technical view
  const explodables = [];    // {obj, offset}
  const positions = {};
  const addShell = (...meshes) => meshes.forEach(m => m.traverse(o => o.isMesh && shell.push(o)));
  const explode = (obj, x, y, z) => { explodables.push({ obj, base: obj.position.clone(), offset: new THREE.Vector3(x, y, z) }); };

  const fullPlan = plan([
    [-D.frontHalf, D.halfDepth], [D.frontHalf, D.halfDepth], [D.apexHalf, D.apexDepth], [D.apexHalf, -D.apexDepth],
    [D.frontHalf, -D.halfDepth], [-D.frontHalf, -D.halfDepth], [-D.apexHalf, -D.apexDepth], [-D.apexHalf, D.apexDepth]
  ]);

  // ---- Plinth & base frame ---------------------------------------------------
  const plinthShape = plan([
    [-0.41, 0.245], [0.41, 0.245], [0.5, 0.03], [0.5, -0.03], [0.41, -0.245], [-0.41, -0.245], [-0.5, -0.03], [-0.5, 0.03]
  ]);
  const plinth = tag(extrudeVertical(plinthShape, 0, 0.075, mats.blackPlastic, 0.004), { type: "component", id: "plinth" });
  root.add(plinth);

  const core = tag(extrudeVertical(plan([[-D.headHalf + 0.005, D.halfDepth - 0.01], [D.headHalf - 0.005, D.halfDepth - 0.01],
    [D.headHalf - 0.005, -D.halfDepth + 0.01], [-D.headHalf + 0.005, -D.halfDepth + 0.01]]), 0.075, D.doorTop + 0.01, mats.graphiteDark, 0.004),
  { type: "component", id: "hydraulic-bay" });
  root.add(core);
  addShell(core);

  // ---- "Ship-type" side wings (graphite) ----------------------------------------
  const wings = {};
  for (const sx of [-1, 1]) {
    const pts = [[D.headHalf, D.halfDepth], [D.frontHalf, D.halfDepth], [D.apexHalf, D.apexDepth], [D.apexHalf, -D.apexDepth],
      [D.frontHalf, -D.halfDepth], [D.headHalf, -D.halfDepth]].map(([x, z]) => [x * sx, z]);
    const wingGroup = new THREE.Group();
    const wing = extrudeVertical(plan(sx < 0 ? pts.reverse() : pts), 0.075, D.wingTop, mats.graphite, 0.012);
    wingGroup.add(wing);
    // Top cap: angled chamfer strip in darker graphite.
    const cap = extrudeVertical(plan(pts.map(([x, z]) => [x * 0.985, z * 0.94])), D.wingTop - 0.004, D.wingTop + 0.018, mats.graphiteDark, 0.006);
    wingGroup.add(cap);

    // Ventilation louvres on the four prow facets (lower hydraulic compartment).
    const slat = new THREE.BoxGeometry(0.15, 0.011, 0.012);
    const louvres = new THREE.InstancedMesh(slat, mats.blackPlastic, 4 * 7);
    let n = 0;
    for (const sz of [-1, 1]) {
      const a = new THREE.Vector3(D.frontHalf * sx, 0, D.halfDepth * sz);
      const b = new THREE.Vector3(D.apexHalf * sx, 0, D.apexDepth * sz);
      const along = b.clone().sub(a);
      const mid = a.clone().add(b).multiplyScalar(0.5);
      const normal = new THREE.Vector3(along.z, 0, -along.x).normalize();
      if (normal.dot(mid.clone().setY(0)) < 0) normal.negate();
      const rotY = Math.atan2(-along.z, along.x);
      for (const row of [0, 1]) {
        for (let i = 0; i < (row ? 3 : 4); i++) {
          const m4 = new THREE.Matrix4().compose(
            mid.clone().addScaledVector(normal, 0.009).setY(0.15 + i * 0.03 + row * 0.62 + (row ? 0.0 : 0)),
            new THREE.Quaternion().setFromEuler(new THREE.Euler(0, rotY, 0)),
            new THREE.Vector3(1, 1, 1));
          if (n < 28) louvres.setMatrixAt(n++, m4);
        }
      }
    }
    louvres.count = n;
    louvres.castShadow = true;
    wingGroup.add(louvres);

    // Panel screws along the wing front strips.
    const screwGeo = new THREE.CylinderGeometry(0.0055, 0.0055, 0.004, 10);
    screwGeo.rotateX(Math.PI / 2);
    const screws = new THREE.InstancedMesh(screwGeo, mats.chrome, 8);
    let k = 0;
    for (const sz of [-1, 1]) for (const y of [1.035, 1.525]) for (const dx of [0.3, 0.415]) {
      screws.setMatrixAt(k++, new THREE.Matrix4().makeTranslation(dx * sx, y, (D.halfDepth + 0.009) * sz));
    }
    wingGroup.add(screws);
    tag(wingGroup, { type: "component", id: "side-wing" });
    root.add(wingGroup);
    addShell(wing, cap);
    explode(wingGroup, sx * 0.42, 0, 0);
    wings[sx] = wingGroup;
  }

  // Manufacturer / model identification plate on the A-side left prow facet.
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.094), new THREE.MeshStandardMaterial({
    map: nameplate(config.equipment), metalness: 0.7, roughness: 0.35
  }));
  // Orient the plate along the facet normal (pointing outward).
  {
    const a = new THREE.Vector3(-D.frontHalf, 1.22, D.halfDepth), b = new THREE.Vector3(-D.apexHalf, 1.22, D.apexDepth);
    const mid = a.clone().add(b).multiplyScalar(0.5);
    const along = b.clone().sub(a);
    const normal = new THREE.Vector3(along.z, 0, -along.x).normalize();
    if (normal.x > 0) normal.negate();
    plate.position.copy(mid).addScaledVector(normal, 0.014);
    plate.lookAt(plate.position.clone().add(normal));
  }
  tag(plate, { type: "component", id: "nameplate" });
  wings[-1].add(plate);

  // ---- Display head (centre block) -------------------------------------------
  const head = new THREE.Group();
  const headBody = rbox(D.headHalf * 2, D.headTop - D.doorTop, D.halfDepth * 2 - 0.02, 0.018, mats.silverPaint);
  headBody.position.y = (D.headTop + D.doorTop) / 2;
  head.add(headBody);
  const headCap = rbox(D.headHalf * 2 + 0.01, 0.03, D.halfDepth * 2, 0.012, mats.graphiteDark);
  headCap.position.y = D.headTop;
  head.add(headCap);
  tag(head, { type: "component", id: "display-head" });
  root.add(head);
  addShell(headBody, headCap);

  // ---- Columns -----------------------------------------------------------------
  for (const sx of [-1, 1]) {
    const c = 0.032, w = 0.095, d = 0.12;
    const colShape = plan([[-w + c, d], [w - c, d], [w, d - c], [w, -d + c], [w - c, -d], [-w + c, -d], [-w, -d + c], [-w, d - c]]);
    const col = extrudeVertical(colShape, D.wingTop, D.canopyBottom + 0.02, mats.graphite, 0.006);
    col.position.x = sx * D.columnX;
    tag(col, { type: "component", id: "column" });
    root.add(col);
    addShell(col);
    explode(col, 0, 0.35, 0);
  }

  // ---- Canopy --------------------------------------------------------------------
  const canopy = new THREE.Group();
  const canopyH = D.canopyTop - D.canopyBottom;
  const canopyBody = rbox(1.3, canopyH, 0.66, 0.03, mats.whitePaint, 4);
  canopyBody.position.y = (D.canopyTop + D.canopyBottom) / 2;
  canopy.add(canopyBody);
  const fasciaTex = canopyFascia();
  for (const sz of [1, -1]) {
    const f = new THREE.Mesh(new THREE.PlaneGeometry(1.24, canopyH - 0.05), new THREE.MeshPhysicalMaterial({
      map: fasciaTex, roughness: 0.3, clearcoat: 0.6, clearcoatRoughness: 0.2
    }));
    f.position.set(0, canopyBody.position.y, sz * 0.3305);
    f.rotation.y = sz > 0 ? 0 : Math.PI;
    canopy.add(f);
  }
  const under = new THREE.Mesh(new THREE.PlaneGeometry(1.22, 0.58), mats.graphiteDark);
  under.rotation.x = Math.PI / 2;
  under.position.y = D.canopyBottom - 0.001;
  canopy.add(under);
  const trim = rbox(1.304, 0.014, 0.664, 0.006, mats.brushedAluminium);
  trim.position.y = D.canopyBottom + 0.02;
  canopy.add(trim);
  tag(canopy, { type: "component", id: "canopy" });
  root.add(canopy);
  addShell(canopyBody, under);
  explode(canopy, 0, 0.7, 0);

  // ---- Sides A (+z) and B (−z) -----------------------------------------------------
  const sides = {};
  for (const side of config.equipment.operatingSides) {
    const face = new THREE.Group();
    face.name = `side-${side}`;
    face.rotation.y = side === "A" ? 0 : Math.PI;
    root.add(face);
    sides[side] = face;
    const ids = Object.entries(config.positions).filter(([, p]) => p.side === side)
      .sort((a, b) => a[1].index - b[1].index).map(([id]) => id);

    // Lower door with wave graphic.
    const door = new THREE.Group();
    const doorPanel = rbox(0.85, D.doorTop - 0.105, 0.014, 0.006, mats.door);
    doorPanel.position.set(0, (D.doorTop + 0.105) / 2, D.halfDepth + 0.007);
    door.add(doorPanel);
    const doorTrim = rbox(0.86, 0.014, 0.03, 0.005, mats.brushedAluminium);
    doorTrim.position.set(0, D.doorTop + 0.002, D.halfDepth + 0.004);
    door.add(doorTrim);
    const lock = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, 0.012, 20), mats.chrome);
    lock.rotation.x = Math.PI / 2;
    lock.position.set(0.355, D.doorTop - 0.07, D.halfDepth + 0.018);
    door.add(lock);
    const keyway = new THREE.Mesh(new THREE.BoxGeometry(0.003, 0.012, 0.002), mats.blackPlastic);
    keyway.position.set(0.355, D.doorTop - 0.07, D.halfDepth + 0.0245);
    door.add(keyway);
    tag(door, { type: "component", id: "door", side });
    face.add(door);
    addShell(doorPanel);
    explode(door, 0, 0, 0.45);

    // Head glass with printed legends.
    const glass = new THREE.Group();
    const glassW = 0.5, glassH = 0.711, glassY = 1.4, gz = D.halfDepth - 0.006;
    const glassBack = rbox(glassW + 0.02, glassH + 0.02, 0.012, 0.006, mats.blackGlass);
    glassBack.position.set(0, glassY, gz);
    glass.add(glassBack);
    const print = new THREE.Mesh(new THREE.PlaneGeometry(glassW, glassH), new THREE.MeshPhysicalMaterial({
      map: headGlass(side, ids.map(id => id)), roughness: 0.06, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.03
    }));
    print.position.set(0, glassY, gz + 0.0065);
    glass.add(print);
    // Side lock on the head glass.
    const hl = lock.clone();
    hl.position.set(0, glassY - 0.3, gz + 0.012);
    glass.add(hl);
    tag(glass, { type: "component", id: "display-head", side });
    face.add(glass);
    explode(glass, 0, 0, 0.3);

    ids.forEach((id, i) => {
      const meta = config.positions[id];
      const sx = i === 0 ? -1 : 1;
      const pos = { id, side, sx, face, meta };
      const pickPos = part => ({ type: "position", id, part });
      const zg = gz + 0.0075;

      // LCD window + bezel + cover glass.
      const lcd = new LcdDisplay(id);
      const lcdW = 0.166, lcdH = 0.137, lcdX = sx * 0.128, lcdY = glassY + 0.219;
      const bezel = rbox(lcdW + 0.016, lcdH + 0.016, 0.006, 0.004, mats.brushedAluminium);
      bezel.position.set(lcdX, lcdY, zg);
      const lcdMesh = new THREE.Mesh(new THREE.PlaneGeometry(lcdW, lcdH), new THREE.MeshBasicMaterial({ map: lcd.texture, toneMapped: false }));
      lcdMesh.position.set(lcdX, lcdY, zg + 0.0035);
      const cover = new THREE.Mesh(new THREE.PlaneGeometry(lcdW, lcdH), mats.lcdCover);
      cover.position.set(lcdX, lcdY, zg + 0.0045);
      cover.raycast = () => {};
      tag(bezel, pickPos("display")); tag(lcdMesh, pickPos("display"));
      glass.add(bezel, lcdMesh, cover);

      // Status LED bar above the LCD.
      const ledMat = new THREE.MeshStandardMaterial({ color: "#111", emissive: "#3fb950", emissiveIntensity: 2.2, roughness: 0.3 });
      const led = rbox(0.11, 0.012, 0.006, 0.003, ledMat);
      led.castShadow = false;
      led.position.set(lcdX, lcdY + lcdH / 2 + 0.045, zg + 0.002);
      tag(led, pickPos("status"));
      glass.add(led);

      // Membrane keypad.
      const keypad = new Keypad(id);
      const kpW = 0.125, kpH = 0.195, kpX = sx * 0.128, kpY = glassY - 0.101;
      const kpBezel = rbox(kpW + 0.014, kpH + 0.014, 0.008, 0.004, mats.brushedAluminium);
      kpBezel.position.set(kpX, kpY, zg);
      const kpMesh = new THREE.Mesh(new THREE.PlaneGeometry(kpW, kpH), new THREE.MeshStandardMaterial({
        map: keypad.texture, roughness: 0.45, metalness: 0.0, emissive: "#ffffff", emissiveMap: keypad.texture, emissiveIntensity: 0.12
      }));
      kpMesh.position.set(kpX, kpY, zg + 0.0045);
      tag(kpBezel, pickPos("keypad")); tag(kpMesh, pickPos("keypad"));
      kpMesh.userData.keypad = keypad;
      glass.add(kpBezel, kpMesh);

      // Nozzle boot (holster) in the wing recess beside the head.
      const hx = sx * D.holsterX;
      const holster = new THREE.Group();
      const recess = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.42), mats.blackPlastic);
      recess.position.set(hx, 1.27, D.halfDepth + 0.0015);
      holster.add(recess);
      const boot = rbox(0.1, 0.15, 0.075, 0.02, mats.blackPlastic);
      boot.position.set(hx, 1.34, D.halfDepth + 0.035);
      holster.add(boot);
      const bootLip = rbox(0.104, 0.02, 0.08, 0.008, new THREE.MeshStandardMaterial({ color: mats.product[meta.product], roughness: 0.5 }));
      bootLip.position.set(hx, 1.27, D.halfDepth + 0.037);
      holster.add(bootLip);
      const nozzleSwitch = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.006, 0.03), mats.chrome);
      nozzleSwitch.position.set(hx, 1.258, D.halfDepth + 0.06);
      holster.add(nozzleSwitch);
      tag(holster, pickPos("holster"));
      face.add(holster);

      // Selection highlight frame around the recess + display.
      const highlight = new THREE.Group();
      const hlMat = new THREE.LineBasicMaterial({ color: "#22c3e6", transparent: true, opacity: 0, toneMapped: false });
      for (const [w, h, x, y] of [[0.15, 0.48, hx, 1.27], [lcdW + 0.04, lcdH + 0.08, lcdX, lcdY + 0.012]]) {
        const edges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(w, h)), hlMat);
        edges.position.set(x, y, D.halfDepth + 0.02);
        highlight.add(edges);
      }
      highlight.userData.material = hlMat;
      face.add(highlight);

      // Hose outlet fitting under the canopy corner.
      const ox = sx * D.outletX, oz = 0.24;
      const outlet = new THREE.Group();
      const elbow = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.05, 16), mats.chrome);
      elbow.position.set(ox, D.canopyBottom - 0.025, oz);
      const swivel = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.021, 0.05, 12), mats.stainless);
      swivel.position.set(ox, D.canopyBottom - 0.075, oz);
      outlet.add(elbow, swivel);
      tag(outlet, pickPos("hose"));
      face.add(outlet);
      const outletPoint = new THREE.Vector3(ox, D.canopyBottom - 0.1, oz);

      // Breakaway coupling (positioned along the hose each update).
      const breakaway = new THREE.Group();
      const ba1 = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.07, 14), mats.stainless);
      const ba2 = new THREE.Mesh(new THREE.CylinderGeometry(0.023, 0.023, 0.018, 6), mats.chrome);
      breakaway.add(ba1, ba2);
      tag(breakaway, pickPos("hose"));
      face.add(breakaway);

      // Nozzle + hose.
      const nozzle = buildNozzle(mats, mats.product[meta.product]);
      tag(nozzle.group, pickPos("nozzle"));
      face.add(nozzle.group);
      const hose = new Hose(mats.hose, {
        length: D.hoseLength, floorY: 0, outward: new THREE.Vector3(sx * 0.6, 0, 1)
      });
      tag(hose.mesh, pickPos("hose"));
      face.add(hose.mesh);

      // Holster pose: spout up into the boot, trigger guard facing outward.
      const H = new THREE.Vector3(hx, 1.31, D.halfDepth + 0.04);
      const hX = new THREE.Vector3(0, 0.9, -0.42).normalize();
      const holsterPose = {
        pos: H.clone().addScaledVector(hX, -0.3),
        quat: basisQuat(hX, new THREE.Vector3(0, 0, -1))
      };
      const liftedHome = new THREE.Vector3(hx + sx * 0.22, 1.05, D.halfDepth + 0.7);

      Object.assign(pos, {
        lcd, keypad, led, ledMat, highlight, nozzle, hose, outletPoint, breakaway, holsterPose, liftedHome,
        labelAnchor: new THREE.Vector3(hx, 1.62, D.halfDepth + 0.08),
        focus: new THREE.Vector3(sx * 0.2, 1.3, D.halfDepth)
      });
      positions[id] = pos;
    });
  }

  // ---- Internal hydraulics (technical / exploded view) – ESTIMATED layout -------
  const internals = new THREE.Group();
  internals.name = "internals";
  internals.visible = false;
  root.add(internals);
  const pumps = {};
  const pumpIds = [...new Set(Object.values(config.positions).map(p => p.pump))].sort();
  pumpIds.forEach((pumpId, i) => {
    const g = new THREE.Group();
    const x = i === 0 ? -0.17 : 0.17;
    g.position.set(x, 0.0, 0);
    const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.17, 24), mats.motorBlue);
    motor.rotation.z = Math.PI / 2;
    motor.position.set(0, 0.17, 0.09);
    const fins = new THREE.Mesh(new THREE.CylinderGeometry(0.069, 0.069, 0.13, 24, 1, true), mats.darkMetal);
    fins.rotation.z = Math.PI / 2;
    fins.position.copy(motor.position);
    const pumpBody = rbox(0.14, 0.13, 0.13, 0.015, mats.castIron);
    pumpBody.position.set(0, 0.17, -0.08);
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.008, 6, 32), mats.rubber);
    belt.scale.set(1, 1, 1);
    belt.rotation.y = Math.PI / 2;
    belt.position.set(-0.08 * Math.sign(x), 0.17, 0.005);
    belt.scale.set(1, 0.55, 1);
    g.add(motor, fins, pumpBody, belt);
    tag(g, { type: "component", id: "pump", pump: pumpId });
    internals.add(g);
    pumps[pumpId] = { group: g, belt, x };
  });

  // Flowmeters (one per position) + pipe runs to the canopy outlets.
  root.updateMatrixWorld(true);
  const pipes = {};
  for (const [id, p] of Object.entries(positions)) {
    const toRoot = v => v.clone().applyMatrix4(p.face.matrix);
    const pump = pumps[p.meta.pump];
    const meterPos = toRoot(new THREE.Vector3(p.sx * 0.15, 0.55, 0.12));
    const meter = new THREE.Group();
    const mBody = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.09, 20), mats.castAluminium);
    const pulser = rbox(0.06, 0.05, 0.05, 0.008, mats.blackPlastic);
    pulser.position.y = 0.07;
    const pled = new THREE.Mesh(new THREE.SphereGeometry(0.006), new THREE.MeshBasicMaterial({ color: "#3fb950" }));
    pled.position.set(0, 0.07, 0.027);
    meter.add(mBody, pulser, pled);
    meter.position.copy(meterPos);
    meter.quaternion.copy(p.face.quaternion);
    tag(meter, { type: "component", id: "flowmeter", position: id });
    internals.add(meter);

    const colTop = toRoot(new THREE.Vector3(p.sx * D.columnX, 2.27, 0.05));
    const pts = [
      new THREE.Vector3(pump.x, 0.2, 0),
      new THREE.Vector3(pump.x * 0.6 + meterPos.x * 0.4, 0.38, meterPos.z * 0.5),
      meterPos.clone().setY(0.5),
      meterPos.clone().setY(0.66),
      toRoot(new THREE.Vector3(p.sx * D.columnX, 1.0, 0.05)),
      toRoot(new THREE.Vector3(p.sx * D.columnX, 2.1, 0.05)),
      colTop,
      toRoot(new THREE.Vector3(p.sx * D.outletX, 2.27, 0.24)),
      toRoot(p.outletPoint.clone().setY(D.canopyBottom - 0.02))
    ];
    const curve = new THREE.CatmullRomCurve3(pts, false, "catmullrom", 0.08);
    const pipe = new THREE.Mesh(new THREE.TubeGeometry(curve, 160, 0.011, 8, false), mats.copperPipe);
    tag(pipe, { type: "component", id: "pipe", position: id });
    internals.add(pipe);
    pipes[id] = pipe;
  }

  // Two mainboards (one per side – estimate) in the display head.
  for (const side of config.equipment.operatingSides) {
    const mb = rbox(0.3, 0.2, 0.012, 0.004, mats.pcb);
    mb.position.set(0, 1.5, side === "A" ? 0.17 : -0.17);
    const chips = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.008), mats.blackPlastic);
    chips.position.set(0.05, 1.52, side === "A" ? 0.18 : -0.18);
    tag(mb, { type: "component", id: "mainboard", side });
    internals.add(mb, chips);
  }

  explode(internals, 0, 0, 0);
  return { root, shell, explodables, positions, sides, internals, pumps, pipes };
}
