// Dynamic per-position LCD and keypad faces, painted onto canvas textures.
import { canvas, toTexture, drawDigits } from "./textures.js";

const LCD_W = 512, LCD_H = 420;

/** One backlit LCD price computer display (SALE / LITER / PRICE). */
export class LcdDisplay {
  constructor(id) {
    this.id = id;
    [this.canvas, this.g] = canvas(LCD_W, LCD_H);
    this.texture = toTexture(this.canvas, { aniso: 4 });
    this.key = "";
    this.paint(null, false);
  }

  paint(p, blink) {
    const status = p?.status ?? "offline";
    const key = p ? `${status}|${p.amount}|${p.volume}|${p.unitPrice}|${p.fault?.code}|${blink}` : "none";
    if (key === this.key) return;
    this.key = key;

    const g = this.g;
    const off = status === "offline";
    const bg = g.createLinearGradient(0, 0, 0, LCD_H);
    if (off) {
      bg.addColorStop(0, "#2a2f2d"); bg.addColorStop(1, "#1f2321");
    } else {
      bg.addColorStop(0, "#dfeee9"); bg.addColorStop(1, "#c4dad3");
    }
    g.fillStyle = bg;
    g.fillRect(0, 0, LCD_W, LCD_H);

    const on = off ? "#2f3532" : "#141917";
    const ghost = off ? "#2c312f" : "rgba(20,25,23,0.07)";
    const rows = [
      [p ? p.amount.toFixed(2) : "", 28, 7],
      [p ? p.volume.toFixed(2) : "", 158, 7],
      [p ? p.unitPrice.toFixed(2) : "", 288, 6]
    ];
    if (status === "fault") {
      rows[0][0] = "Err"; rows[1][0] = String(p.fault?.code || "").replace(/\D/g, "").slice(-4) || "0";
    }
    for (const [txt, y, cells] of rows) {
      drawDigits(g, off ? "" : txt, 480, y, cells === 6 ? 40 : 46, cells === 6 ? 84 : 98, cells, on, ghost);
    }
    if (!off) {
      // Annunciators along the bottom edge (status icons as on real LCD glass).
      g.font = "700 22px Arial";
      g.fillStyle = on;
      g.fillText(this.id, 16, 402);
      const ann = {
        nozzle_removed: "NOZZLE", dispensing: blink ? "▶ FUEL" : "  FUEL", paused: "PAUSE",
        completed: "END", fault: "ERROR", idle: ""
      }[status] || "";
      g.fillText(ann, 80, 402);
      if (p.preset) g.fillText(`PRESET ${p.preset.type === "amount" ? "$" : "L"}`, 300, 402);
    }
    this.texture.needsUpdate = true;
  }
}

// Membrane keypad layout (4 × 4), shared by painter and hit-testing.
export const KEYPAD_KEYS = [
  ["1", "2", "3", "L"],
  ["4", "5", "6", "$"],
  ["7", "8", "9", "C"],
  [".", "0", "00", "OK"]
];
const KP_W = 256, KP_H = 400;
const GRID = { x: 18, y: 120, w: 220, h: 262 };

export class Keypad {
  constructor(id) {
    this.id = id;
    [this.canvas, this.g] = canvas(KP_W, KP_H);
    this.texture = toTexture(this.canvas, { aniso: 4 });
    this.entry = "";
    this.mode = "volume";
    this.pressed = null;
    this.paint();
  }

  /** Map a UV hit on the keypad face to a key label (or null). */
  keyAt(uv) {
    const x = uv.x * KP_W, y = (1 - uv.y) * KP_H;
    const col = Math.floor(((x - GRID.x) / GRID.w) * 4);
    const row = Math.floor(((y - GRID.y) / GRID.h) * 4);
    if (col < 0 || col > 3 || row < 0 || row > 3) return null;
    return KEYPAD_KEYS[row][col];
  }

  paint() {
    const g = this.g;
    g.fillStyle = "#2b2f34";
    g.fillRect(0, 0, KP_W, KP_H);
    // Preset mini LCD
    g.fillStyle = "#cfe3dc";
    g.fillRect(18, 18, 220, 84);
    g.fillStyle = "#13201b";
    g.font = "700 18px Arial";
    g.fillText(this.mode === "amount" ? "PRESET $" : "PRESET L", 26, 42);
    g.font = "700 40px 'Courier New', monospace";
    g.textAlign = "right";
    g.fillText(this.entry || "0", 230, 92);
    g.textAlign = "left";

    const kw = GRID.w / 4, kh = GRID.h / 4;
    KEYPAD_KEYS.forEach((row, r) => row.forEach((k, c) => {
      const x = GRID.x + c * kw + 4, y = GRID.y + r * kh + 4;
      const fn = /[L$COK]/.test(k) && k !== "0";
      const isPressed = this.pressed === k;
      g.fillStyle = isPressed ? "#e3a008" : fn ? (k === "OK" ? "#2f8f4e" : k === "C" ? "#b9393d" : "#5b6168") : "#d9dcdf";
      roundRect(g, x, y, kw - 8, kh - 8, 8);
      g.fill();
      g.fillStyle = fn || isPressed ? "#ffffff" : "#1b1d20";
      g.font = `800 ${k.length > 1 ? 20 : 26}px Arial`;
      g.textAlign = "center";
      g.fillText(k, x + (kw - 8) / 2, y + (kh - 8) / 2 + 9);
      g.textAlign = "left";
    }));
    this.texture.needsUpdate = true;
  }

  /**
   * Apply a key. Returns {submit: {type, value}} on OK, else null.
   */
  press(k) {
    this.pressed = k;
    clearTimeout(this.releaseTimer);
    this.releaseTimer = setTimeout(() => { this.pressed = null; this.paint(); }, 160);
    let out = null;
    if (k === "C") this.entry = "";
    else if (k === "L") this.mode = "volume";
    else if (k === "$") this.mode = "amount";
    else if (k === "OK") { out = { submit: { type: this.mode, value: Number(this.entry) || 0 } }; this.entry = ""; }
    else if (k === "." && this.entry.includes(".")) { /* ignore */ }
    else if (this.entry.length < 7) this.entry += k;
    this.paint();
    return out;
  }
}

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}
