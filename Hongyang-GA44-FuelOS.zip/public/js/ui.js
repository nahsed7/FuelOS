// Shared UI building blocks.
import { statusMeta, statusPill, icon } from "./status.js";
import { fmt, esc } from "./format.js";

export function toast(message, tone = "info", ms = 3800) {
  const host = document.getElementById("toasts");
  const el = document.createElement("div");
  el.className = `toast tone-${tone}`;
  el.innerHTML = `${icon(tone === "fault" ? "fault" : tone === "ok" ? "check" : "link")}<span>${esc(message)}</span>`;
  host.appendChild(el);
  setTimeout(() => el.classList.add("out"), ms);
  setTimeout(() => el.remove(), ms + 400);
}

/** Which simulator commands make sense in the current state. */
export function allowed(p, commandsEnabled) {
  if (!commandsEnabled || !p) return {};
  const s = p.status;
  const usable = s !== "fault" && s !== "offline";
  return {
    lift: usable && !p.nozzleLifted,
    hang: p.nozzleLifted,
    start: usable && p.nozzleLifted && (s === "nozzle_removed" || s === "completed"),
    pause: s === "dispensing",
    resume: s === "paused",
    stop: s === "dispensing" || s === "paused",
    fault: usable,
    "clear-fault": s === "fault",
    offline: s !== "offline",
    online: s === "offline",
    reset: true
  };
}

/** Compact position tile (overview). */
export function positionTile(p, cur, selected) {
  const m = statusMeta(p.status);
  return `<button class="pos-tile${selected ? " selected" : ""}" data-select="${p.id}" style="--c:${m.color}">
    <div class="pos-tile-head"><b>${p.id}</b>${statusPill(p.status)}</div>
    <div class="big mono">${fmt.vol(p.volume)} <small>L</small></div>
    <div class="kv"><span>Amount</span><b class="mono">${fmt.money(p.amount, cur)}</b></div>
    <div class="kv"><span>Flow</span><b class="mono">${fmt.num(p.flowRate, 1)} L/min</b></div>
    <div class="kv"><span>Totalizer</span><b class="mono">${fmt.num(p.totalizer, 3)} L</b></div>
  </button>`;
}

/**
 * Detailed position panel with controls. Built once per position, then
 * updated in place (so inputs keep focus/typed values between updates).
 */
export class PositionPanel {
  constructor(host, ctx) {
    this.host = host;
    this.ctx = ctx;
    this.id = null;
    host.addEventListener("click", e => this.onClick(e));
    host.addEventListener("submit", e => { e.preventDefault(); this.authorise(); });
  }

  build(id) {
    this.id = id;
    const meta = this.ctx.config.positions[id];
    this.host.innerHTML = `
      <div class="card-head">
        <div>
          <div class="eyebrow">Selected position · Side ${meta.side}</div>
          <h2 class="pos-title">${id} <small data-f="product"></small></h2>
        </div>
        <div data-f="pill"></div>
      </div>
      <div class="sim-ribbon" data-f="ribbon"></div>
      <div class="readouts">
        <div class="ro wide"><span>Volume</span><b class="mono" data-f="volume">—</b><em>L</em></div>
        <div class="ro wide"><span>Amount</span><b class="mono" data-f="amount">—</b><em data-f="cur"></em></div>
        <div class="ro"><span>Flow rate</span><b class="mono" data-f="flow">—</b><em>L/min</em></div>
        <div class="ro"><span>Unit price</span><b class="mono" data-f="price">—</b><em data-f="cur2"></em></div>
        <div class="ro"><span>Totalizer</span><b class="mono" data-f="totalizer">—</b><em>L</em></div>
        <div class="ro"><span>Session</span><b class="mono" data-f="duration">—</b><em>mm:ss</em></div>
      </div>
      <dl class="meta-list">
        <dt>Session ID</dt><dd class="mono" data-f="session">—</dd>
        <dt>Preset</dt><dd data-f="preset">—</dd>
        <dt>Nozzle</dt><dd data-f="nozzle">—</dd>
        <dt>Hydraulics</dt><dd>${meta.pump} · ${meta.meter} · ${meta.mainboard} <span class="tag est">est.</span></dd>
        <dt>Connection</dt><dd data-f="conn">—</dd>
      </dl>
      <div class="ctl-group">
        <div class="ctl-title">Nozzle</div>
        <div class="row gap wrap">
          <button class="btn" data-cmd="lift">${icon("nozzle")} Lift nozzle</button>
          <button class="btn" data-cmd="hang">Return to holster</button>
          <button class="btn ghost" data-act="inspect">Inspect nozzle</button>
        </div>
      </div>
      <form class="ctl-group">
        <div class="ctl-title">Sale</div>
        <div class="row gap wrap">
          <div class="seg small" role="group" aria-label="Preset type">
            <button type="button" data-ptype="volume" class="on">Litres</button><button type="button" data-ptype="amount">Amount</button>
          </div>
          <input class="preset-input" type="number" min="0" step="0.01" placeholder="Preset (optional)" aria-label="Preset value" data-f="presetInput">
        </div>
        <div class="row gap wrap">
          <button class="btn primary" type="submit" data-cmd-submit="start">Authorise &amp; start</button>
          <button class="btn" type="button" data-cmd="pause">Pause</button>
          <button class="btn" type="button" data-cmd="resume">Resume</button>
          <button class="btn danger" type="button" data-cmd="stop">Stop</button>
        </div>
      </form>
      <details class="ctl-group">
        <summary class="ctl-title">Simulation tools</summary>
        <div class="row gap wrap">
          <button class="btn" data-cmd="fault">Inject fault</button>
          <button class="btn" data-cmd="clear-fault">Clear fault</button>
          <button class="btn" data-cmd="offline">Set offline</button>
          <button class="btn" data-cmd="online">Set online</button>
          <button class="btn ghost" data-cmd="reset">Reset session</button>
        </div>
      </details>
      <p class="hint" data-f="hint"></p>`;
    this.presetType = "volume";
    this.fields = {};
    this.host.querySelectorAll("[data-f]").forEach(el => { this.fields[el.dataset.f] = el; });
  }

  update(state) {
    if (!this.id) return;
    const p = state.positions[this.id];
    const f = this.fields;
    const cur = state.settings?.currency || "";
    const product = state.settings?.products?.[p.product];
    f.product.textContent = `${product?.name || p.product} · ${p.product}`;
    f.pill.innerHTML = statusPill(p.status);
    f.ribbon.textContent = state.simulated
      ? "SIMULATED — generated by the FuelOS simulator, not measured by the physical dispenser"
      : "PHYSICAL · READ-ONLY";
    f.ribbon.className = `sim-ribbon ${state.simulated ? "sim" : "phys"}`;
    const offline = p.status === "offline" && !state.simulated;
    f.volume.textContent = offline ? "—" : fmt.num(p.volume, 3);
    f.amount.textContent = offline ? "—" : fmt.num(p.amount, 2);
    f.flow.textContent = offline ? "—" : fmt.num(p.flowRate, 1);
    f.price.textContent = offline ? "—" : fmt.num(p.unitPrice, 2);
    f.totalizer.textContent = offline ? "—" : fmt.num(p.totalizer, 3);
    f.duration.textContent = fmt.duration(p.sessionDurationS);
    f.cur.textContent = cur; f.cur2.textContent = `${cur}/L`;
    f.session.textContent = p.sessionId || "—";
    f.preset.textContent = p.preset ? (p.preset.type === "amount" ? fmt.money(p.preset.value, cur) : `${fmt.num(p.preset.value, 2)} L`) : "None (fill until stopped)";
    f.nozzle.innerHTML = p.nozzleLifted ? `${icon("nozzle")} Removed from holster` : `${icon("check")} In holster`;
    f.conn.textContent = `${state.connection.state}${state.connection.detail ? ` — ${state.connection.detail}` : ""}`;

    const can = allowed(p, state.commandsEnabled);
    this.host.querySelectorAll("[data-cmd],[data-cmd-submit]").forEach(b => {
      const c = b.dataset.cmd || b.dataset.cmdSubmit;
      b.disabled = !can[c] || this.busy;
    });
    f.hint.textContent = !state.commandsEnabled
      ? "Physical mode is READ-ONLY: FuelOS never sends start/stop, preset, price or any control command to the dispenser."
      : p.status === "fault" ? `Fault ${p.fault?.code || ""}: clear the fault to continue.`
      : !p.nozzleLifted && (p.status === "idle" || p.status === "completed") ? "Lift the nozzle (button, or click the nozzle in the 3D view) to begin."
      : p.status === "nozzle_removed" ? "Enter an optional preset, then authorise. The 3D keypad works too (L / $ then OK)."
      : "";
  }

  onClick(e) {
    const ptype = e.target.closest("[data-ptype]");
    if (ptype) {
      this.presetType = ptype.dataset.ptype;
      this.host.querySelectorAll("[data-ptype]").forEach(b => b.classList.toggle("on", b === ptype));
      return;
    }
    const act = e.target.closest("[data-act]");
    if (act?.dataset.act === "inspect") return this.ctx.inspectNozzle?.(this.id);
    const btn = e.target.closest("[data-cmd]");
    if (btn) this.run(btn.dataset.cmd);
  }

  authorise() {
    const v = Number(this.fields.presetInput.value);
    const body = v > 0 ? { preset: { type: this.presetType, value: v } } : {};
    this.run("start", body).then(ok => { if (ok) this.fields.presetInput.value = ""; });
  }

  async run(action, body) {
    this.busy = true;
    const ok = await this.ctx.cmd(this.id, action, body);
    this.busy = false;
    if (this.ctx.client.state) this.update(this.ctx.client.state);
    return ok;
  }
}
