export const fmt = {
  vol: (v, dp = 2) => (v == null ? "—" : `${Number(v).toFixed(dp)}`),
  money: (v, cur = "LKR") => (v == null ? "—" : `${cur} ${Number(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`),
  num: (v, dp = 2) => (v == null ? "—" : Number(v).toLocaleString("en-US", { minimumFractionDigits: dp, maximumFractionDigits: dp })),
  duration: s => {
    if (!s) return "00:00";
    const m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  },
  time: iso => (iso ? new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—"),
  dateTime: iso => (iso ? new Date(iso).toLocaleString([], { dateStyle: "short", timeStyle: "medium" }) : "—"),
  ago: ms => {
    if (!ms) return "never";
    const s = Math.round((Date.now() - ms) / 1000);
    return s < 2 ? "just now" : s < 60 ? `${s}s ago` : `${Math.round(s / 60)}m ago`;
  }
};

export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
