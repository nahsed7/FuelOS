// Single client-side telemetry source for every FuelOS view (dashboard + 3D).
// Socket.IO "telemetry" stream from the existing backend; REST /api/state as
// fallback while the socket is down. Commands go through REST.

export class TelemetryClient {
  constructor() {
    this.state = null;
    this.listeners = new Set();
    this.txListeners = new Set();
    this.link = { state: "connecting", since: Date.now(), reconnects: 0, lastMessageAt: 0, latencyMs: null };
    this.linkListeners = new Set();
  }

  start() {
    if (!window.io) {
      this.setLink("error", "Socket.IO client library failed to load");
      this.poll();
      return;
    }
    const socket = this.socket = window.io({
      reconnection: true, reconnectionDelay: 800, reconnectionDelayMax: 6000, timeout: 8000
    });
    socket.on("connect", () => { this.setLink("live"); this.stopPolling(); });
    socket.on("disconnect", reason => { this.setLink("reconnecting", reason); this.poll(); });
    socket.on("connect_error", err => { this.setLink("reconnecting", err.message); this.poll(); });
    socket.io.on("reconnect_attempt", () => { this.link.reconnects++; this.emitLink(); });
    socket.on("telemetry", s => this.accept(s));
    socket.on("transaction", tx => this.txListeners.forEach(fn => fn(tx)));
    this.measureLatency();
    this.refresh();
  }

  async refresh() {
    try {
      const r = await fetch("/api/state", { cache: "no-store" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      this.accept(await r.json());
      return true;
    } catch (err) {
      if (this.link.state !== "live") this.setLink("offline", err.message);
      return false;
    }
  }

  poll() {
    if (this.pollTimer) return;
    this.pollTimer = setInterval(() => this.refresh(), 2000);
  }

  stopPolling() {
    clearInterval(this.pollTimer);
    this.pollTimer = null;
  }

  measureLatency() {
    setInterval(async () => {
      const t = performance.now();
      try {
        const r = await fetch("/api/state", { method: "HEAD", cache: "no-store" });
        if (r.ok) { this.link.latencyMs = Math.round(performance.now() - t); this.emitLink(); }
      } catch { /* link state handled by socket events */ }
    }, 5000);
  }

  accept(snapshot) {
    if (!snapshot?.positions) return;
    if (this.state && snapshot.seq < this.state.seq && snapshot.timestamp < this.state.timestamp) return;
    this.state = snapshot;
    this.link.lastMessageAt = Date.now();
    this.listeners.forEach(fn => fn(snapshot));
  }

  setLink(state, detail = "") {
    if (this.link.state !== state) this.link.since = Date.now();
    Object.assign(this.link, { state, detail });
    this.emitLink();
  }

  emitLink() { this.linkListeners.forEach(fn => fn(this.link)); }
  subscribe(fn) { this.listeners.add(fn); if (this.state) fn(this.state); return () => this.listeners.delete(fn); }
  onLink(fn) { this.linkListeners.add(fn); fn(this.link); }
  onTransaction(fn) { this.txListeners.add(fn); }

  /** POST a command; resolves {ok, message}. Never throws. */
  async command(path, body = {}) {
    try {
      const r = await fetch(`/api/${path}`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
      });
      const j = await r.json().catch(() => ({}));
      if (j.state) this.accept(j.state);
      return { ok: r.ok && j.ok !== false, message: j.message || (r.ok ? "" : `HTTP ${r.status}`) };
    } catch (err) {
      return { ok: false, message: `Network error: ${err.message}` };
    }
  }

  async get(path) {
    const r = await fetch(`/api/${path}`, { cache: "no-store" });
    if (!r.ok) throw new Error(`GET /api/${path} → HTTP ${r.status}`);
    return r.json();
  }
}
