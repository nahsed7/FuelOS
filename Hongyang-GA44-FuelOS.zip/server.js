"use strict";

const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const config = require("./src/config");
const logger = require("./src/logger");
const { TelemetryStore } = require("./src/telemetry/store");
const { createAdapter } = require("./src/adapters");
const { startConnectionMonitor } = require("./src/telemetry/connection-monitor");
const { createApiRouter } = require("./src/routes/api");

logger.setLevel(config.runtime.logLevel);
const log = logger.child("server");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { pingInterval: 10000, pingTimeout: 8000 });

const store = new TelemetryStore(config.DATA_SOURCE);
const adapter = createAdapter(config.DATA_SOURCE, store);
const startedAt = new Date().toISOString();

// --- Broadcast: one throttled "telemetry" stream for every client ------------
let lastSentSeq = -1;
function broadcast() {
  if (store.seq === lastSentSeq) return;
  lastSentSeq = store.seq;
  io.emit("telemetry", store.snapshot());
}
store.on("change", () => {
  // Coalesce bursts of changes into one emit per event-loop turn.
  if (!broadcast.pending) {
    broadcast.pending = true;
    setImmediate(() => { broadcast.pending = false; broadcast(); });
  }
});
store.on("transaction", tx => io.emit("transaction", tx));
store.on("connection", c => log.info(`Data source connection: ${c.state}${c.detail ? ` — ${c.detail}` : ""}`));

// --- HTTP ---------------------------------------------------------------------
app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
// Only the vendor libraries the browser needs are exposed (not all of node_modules).
app.use("/vendor/three", express.static(path.join(__dirname, "node_modules/three"), { fallthrough: false }));
app.use("/api", createApiRouter({
  store, adapter, broadcast,
  getClientCount: () => io.engine.clientsCount,
  startedAt
}));
app.use(express.static(path.join(__dirname, "public")));
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") return res.status(400).json({ ok: false, message: "Invalid JSON body" });
  if (err.status === 404 || err.statusCode === 404) return res.status(404).end();
  log.error(`Unhandled error on ${req.method} ${req.url}`, err);
  res.status(500).json({ ok: false, message: "Internal server error" });
});

io.on("connection", socket => {
  log.debug(`Client connected ${socket.id} (${io.engine.clientsCount} total)`);
  socket.emit("telemetry", store.snapshot());
  socket.on("disconnect", reason => log.debug(`Client ${socket.id} disconnected: ${reason}`));
});

// --- Start --------------------------------------------------------------------
startConnectionMonitor(store, { staleAfterMs: config.runtime.staleAfterMs });
Promise.resolve(adapter.start()).catch(err => log.error("Adapter failed to start", err));

server.on("error", err => {
  log.error(err.code === "EADDRINUSE" ? `Port ${config.runtime.port} is already in use` : "Server error", err);
  process.exit(1);
});
server.listen(config.runtime.port, config.runtime.host, () => {
  log.info(`FuelOS · Hongyang ${config.equipment.model} running at http://localhost:${config.runtime.port}`);
  log.info(`Data source: ${config.DATA_SOURCE.toUpperCase()}${config.DATA_SOURCE === "simulation" ? " (all telemetry is SIMULATED)" : " (READ-ONLY)"}`);
});

function shutdown(signal) {
  log.info(`${signal} received, shutting down`);
  Promise.resolve(adapter.stop()).finally(() => {
    io.close();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 2000).unref();
  });
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
