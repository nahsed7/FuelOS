# FuelOS · Hongyang CMD1687SK-GA44 digital twin

Interactive 3D digital twin and live monitoring for a Hongyang A-Series CMD1687SK-GA44
(serial 21051034; sides A/B; positions A1, A2, B1, B2). All data is **SIMULATED** unless
you run in physical mode, which is read-only and currently not connected (see docs/PHYSICAL_INTEGRATION.md).

## Run
```
npm install
npm start                 # http://localhost:3000  (simulation mode)
DATA_SOURCE=physical npm start   # read-only physical mode (shows Offline: no documented decoder yet)
```
Env: `PORT`, `DATA_DIR` (simulator persistence, default ./data), `LOG_LEVEL`, `STALE_AFTER_MS`.

## Pages
Overview · 3D Dispenser · Live Monitoring · Transactions · Equipment · Diagnostics · Settings.

## API
`GET /api/state | /api/equipment | /api/transactions | /api/diagnostics`
`POST /api/positions/:id/(lift|hang|start|pause|resume|stop|reset|fault|clear-fault|offline|online)` (body `{preset:{type:"volume"|"amount",value}}` for start)
`POST /api/settings` — `{nominalFlowLpm, products:{P1:{name,unitPrice}}}`
Legacy kept: `POST /api/start/:id`, `/api/stop/:id`, `/api/reset-session/:id`, `/api/settings {flowRateLpm, channel, price}`; Socket.IO event `telemetry`.

## Provenance
Confirmed: identity (nameplate), GA44 = 2 products, 2 pumps, 4 flowmeters, 4 nozzles, 2 mainboards,
4 keyboards, 4 displays (Hongyang A-Series table). Estimated: dimensions (scaled from catalogue photo),
internal layout, pump/mainboard assignment, hose length, shared-pump derating.
